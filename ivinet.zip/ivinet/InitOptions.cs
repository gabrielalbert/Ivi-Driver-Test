///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// IVI inherent options storage class.
    /// </summary>
    internal class InitOptions : ICloneable
    {
        /// <summary>
        /// If True, the driver queries the instrument status at the end of each method or property that performs I/O 
        /// to the instrument.  If an error is reported, use ErrorQuery to retrieve error messages one at a time from
        /// the instrument.
        /// </summary>
        public bool QueryInstrumentStatusEnabled { get; set; }

        /// <summary>
        /// Drivers may choose to always cache some instrument settings, never cache others, and optionally cache 
        /// others, to avoid unecessary I/O  to the instrument.  If True, the driver caches optionally cached 
        /// instrument settings.
        /// </summary>
        public bool CachingEnabled { get; set; }

        /// <summary>
        /// If true, interchange checking is enabled.  The .NET driver doesnot actually use this, but IVI-C and IVI-COM
        /// wrappers do.
        /// </summary>
        public bool InterchangeCheckingEnabled { get; set; }

        /// <summary>
        /// Drivers may choose to always validate some property/parameter values, never validate others, and optionally
        /// validate others, to avoid sending invalid commands to the instrument.  If True, the driver performs optional validations.
        /// </summary>
        public bool RangeCheckingEnabled { get; set; }

        /// <summary>
        /// If true, coercion recording is enabled.  The .NET driver does not actually use this, but IVI-C and IVI-COM
        /// wrappers do.
        /// </summary>
        public bool CoercionRecordingEnabled { get; set; }

        /// <summary>
        /// If True, the driver does not perform I/O to the instrument, and returns simulated values for output parameters.
        /// </summary>
        public bool SimulationEnabled { get; set; }

        /// <summary>
        /// Set every option to its IVI-defined default value.
        /// </summary>
        public void InitializeToIviDefinedDefaults()
        {
            this.CachingEnabled = true;
            this.InterchangeCheckingEnabled = false;
            this.QueryInstrumentStatusEnabled = false;
            this.RangeCheckingEnabled = true;
            this.CoercionRecordingEnabled = false;
            this.SimulationEnabled = false;
        }

        #region ICloneable Members

        public object Clone()
        {
            return this.MemberwiseClone();
        }

        #endregion
    }
}
