///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reflection;
using System.Text.RegularExpressions;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Driver information that is session independent and static.
    /// </summary>
    public class DriverInfo
    {
        /// <summary>
        /// This constructor is marked private to prevent external construction.  Valid instances of this class are 
        /// obtained by calling the static Load method.
        /// </summary>
        private DriverInfo() { }

        // key = instrument class, value = list of supported capability groups from that class
        //
        private Dictionary<string, List<string>> InstrumentClasses { get; } = new Dictionary<string, List<string>>();

        // key = family (or empty), value = list of models in family
        //
        private Dictionary<string, List<string>> SupportedFamiliesAndModels { get; } = new Dictionary<string, List<string>>();

        // key = family (or empty), value = Regex for validating model names
        //
        private Dictionary<string, Regex> ModelValidationExpressions { get; } = new Dictionary<string, Regex>();

        internal string DefaultModelForSimulation { get; private set; }

        internal string DriverIdentifier { get; private set; }

        internal string DriverVendor { get; private set; }

        internal string DriverDescription { get; private set; }

        internal string DriverRevision { get; private set; }

        /// <summary>
        /// The software module name of the driver, in the format: 
        /// &lt;namespace&gt; v&lt;threeDigitVersion&gt; Fx&lt;framework major version&gt;&lt;framework minor version&gt;
        /// <para>
        /// Example: Acme.AcmeSpecAn v2.5.0 Fx20
        /// </para>
        /// </summary>
        internal string SoftwareModuleName { get; private set; }

        internal int SpecificationMinorVersion { get; private set; }

        internal int SpecificationMajorVersion { get; private set; }

        internal bool InterchangeCheckSupported { get; private set; }

        internal bool ResetSupported { get; private set; }

        internal bool SelfTestSupported { get; private set; }

        internal bool RevisionQuerySupported { get; private set; }

        internal bool IdQuerySupported { get; private set; }

        /// <summary>
        /// Gets the list of all supported capability groups across all instrument classes implemented by the driver.
        /// </summary>
        internal IEnumerable<string> CapabilityGroups
        {
            get
            {
                foreach (var instrClass in this.InstrumentClasses)
                {
                    foreach (var group in instrClass.Value)
                    {
                        yield return group;
                    }
                }
            }
        }

        internal bool IsModelSupported(string model)
        {
            if (model == null) throw new ArgumentNullException(nameof(model));

            // The model may be a member of a family that is using regular-expression-based model validation.
            //
            foreach (var validationExpression in this.ModelValidationExpressions.Values)
            {
                if (validationExpression.IsMatch(model))
                {
                    return true;
                }
            }

            // The model may be a member of a family is using simple string-based model validation.
            //
            foreach (var modelList in this.SupportedFamiliesAndModels.Values)
            {
                if (modelList.Contains(model))
                {
                    return true;
                }
            }

            return false;
        }

        internal bool IsModelInFamily(string model, string family)
        {
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (family == null) throw new ArgumentNullException(nameof(family));

            if (this.SupportedFamiliesAndModels.TryGetValue(family, out var models))
            {
                if (this.ModelValidationExpressions.TryGetValue(family, out var validationExpression))
                {
                    // This family uses regular-expression-based model validation.
                    //
                    return validationExpression.IsMatch(model);
                }

                return models.Contains(model);
            }

            return false;
        }

        internal IEnumerable<string> GetAllSupportedModels()
        {
            foreach (var modelList in this.SupportedFamiliesAndModels.Values)
            {
                foreach (var model in modelList)
                {
                    yield return model;
                }
            }
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal static DriverInfo Load(Driver mainDriverClass)
        {
            var asm = mainDriverClass.GetType().Assembly;

            var versionAttr = LoadAndValidateAttribute<AssemblyFileVersionAttribute>(asm, throwIfNotPresent: true);
            var companyAttr = LoadAndValidateAttribute<AssemblyCompanyAttribute>(asm, throwIfNotPresent: true);
            var descriptionAttr = LoadAndValidateAttribute<AssemblyDescriptionAttribute>(asm, throwIfNotPresent: true);
            var capabilitiesAttr = LoadAndValidateAttribute<DriverCapabilitiesAttribute>(asm, throwIfNotPresent: true);

            var info = new DriverInfo
            {
                DriverIdentifier = mainDriverClass.GetType().Name,
                DriverVendor = companyAttr.Company.Trim(),
                DriverDescription = descriptionAttr.Description.Trim(),
                DriverRevision = TextUtility.RemoveWhiteSpace(versionAttr.Version),

                IdQuerySupported = (capabilitiesAttr.DriverCapabilities & Capabilities.IdQuery) == Capabilities.IdQuery,
                InterchangeCheckSupported = (capabilitiesAttr.DriverCapabilities & Capabilities.InterchangeCheck) == Capabilities.InterchangeCheck,
                ResetSupported = (capabilitiesAttr.DriverCapabilities & Capabilities.Reset) == Capabilities.Reset,
                RevisionQuerySupported = (capabilitiesAttr.DriverCapabilities & Capabilities.RevisionQuery) == Capabilities.RevisionQuery,
                SelfTestSupported = (capabilitiesAttr.DriverCapabilities & Capabilities.SelfTest) == Capabilities.SelfTest
            };

            info.SoftwareModuleName = GetSoftwareModuleName(mainDriverClass.GetType());

            LoadInstrumentModels(info, asm);

            LoadSupportedInstrumentClasses(info, asm);

            return info;
        }

        private static string GetSoftwareModuleName(Type mainDriverClassType)
        {
            // As per IVI-3.17, the format of the software module entry name is:
            //
            //  Acme.Acme4301 v2.5.0 Fx30   
            //
            // The format of the assembly name is:
            //
            //  Acme.Acme4301.Fx30
            //
            // So, we can parse the assembly name and use it to compose the software module name.
            //
            var assemblyName = mainDriverClassType.Assembly.GetName();
            var assemblyNameParts = assemblyName.Name.Split('.');

            if (assemblyNameParts.Length != 3)
            {
                throw new InvalidOperationException(NclStrings.InvalidDriverAssemblyName(assemblyName.Name));
            }

            var fxShortName = assemblyNameParts[2];
            var driverVersion = assemblyName.Version;

            return String.Format(CultureInfo.InvariantCulture, "{0} v{1}.{2}.{3} {4}",
                mainDriverClassType.Namespace, driverVersion.Major, driverVersion.Minor, driverVersion.Build, fxShortName);
        }

        private static void LoadInstrumentModels(DriverInfo info, Assembly asm)
        {
            foreach (var type in asm.GetTypes())
            {
                var attrs = type.GetCustomAttributes(typeof(InstrumentFamiliesAttribute), inherit: false);

                if (attrs.Length > 0)
                {
                    // Each family and its members are declared in the class by fields in the following format:
                    //
                    //		internal static readonly string[] Family1Members = new[] { Models.ModelA, Models.ModelB };
                    //
                    foreach (var fieldInfo in type.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                    {
                        const string fieldNameSuffix = "Members";

                        if (fieldInfo.FieldType == typeof(string[]) &&
                            fieldInfo.Name.Length > fieldNameSuffix.Length &&
                            fieldInfo.Name.EndsWith(fieldNameSuffix, StringComparison.OrdinalIgnoreCase))
                        {
                            if (fieldInfo.GetValue(null) is string[] models)
                            {
                                var familyName = fieldInfo.Name.Substring(0, fieldInfo.Name.Length - fieldNameSuffix.Length);
                                info.SupportedFamiliesAndModels.Add(familyName, new List<string>(models));
                            }
                        }
                    }
                }
                else if (info.DefaultModelForSimulation == null)
                {
                    attrs = type.GetCustomAttributes(typeof(InstrumentModelsAttribute), false);

                    if (attrs.Length > 0)
                    {
                        var modelsAttr = (InstrumentModelsAttribute)attrs[0];

                        if (!String.IsNullOrEmpty(modelsAttr.DefaultModelForSimulation))
                        {
                            info.DefaultModelForSimulation = modelsAttr.DefaultModelForSimulation;
                        }
                    }
                }
            }

            if (info.SupportedFamiliesAndModels.Count == 0)
            {
                throw new InvalidOperationException(NclStrings.NoInstrumentModelDeclarationsFound);
            }
        }

        private static void LoadSupportedInstrumentClasses(DriverInfo info, Assembly asm)
        {
            var attrs = Utility.ToArray(LoadAndValidateAttributes<SupportedInstrumentClassAttribute>(asm, false));

            foreach (var attr in attrs)
            {
                if (attrs.Length == 1 || attr.IsPrimaryInstrumentClass)
                {
                    info.SpecificationMajorVersion = attr.MajorVersion;
                    info.SpecificationMinorVersion = attr.MinorVersion;
                }

                var groups = new List<string>();

                foreach (var group in attr.CapabilityGroups)
                {
                    // Automatically add the instrument class prefix if it is not present.
                    //
                    if (!group.StartsWith(attr.InstrumentClassName, StringComparison.OrdinalIgnoreCase))
                    {
                        groups.Add(attr.InstrumentClassName + group);
                    }
                    else
                    {
                        groups.Add(group);
                    }
                }

                info.InstrumentClasses.Add(attr.InstrumentClassName, groups);
            }
        }

        private static IEnumerable<TAttr> LoadAndValidateAttributes<TAttr>(Assembly asm, bool throwIfNotPresent)
            where TAttr : Attribute
        {
            var attrs = (TAttr[])asm.GetCustomAttributes(typeof(TAttr), inherit: false);

            if (attrs == null && throwIfNotPresent)
            {
                throw new DriverAttributeValidationException<TAttr>($"assembly {asm.GetName().Name}", "The required attribute could not be found.");
            }

            foreach (var attr in attrs)
            {
                if (attr is NimbusAttribute driverAttr)
                {
                    driverAttr.Validate();
                }

                yield return attr;
            }
        }

        private static TAttr LoadAndValidateAttribute<TAttr>(Assembly asm, bool throwIfNotPresent)
            where TAttr : Attribute
        {
            // This method retrieves only the first attribute and asserts if more than one attribute is found.
            //
            var attrs = LoadAndValidateAttributes<TAttr>(asm, throwIfNotPresent);
            var attrEnumerator = attrs.GetEnumerator();

            if (attrEnumerator.MoveNext())
            {
                var attr = attrEnumerator.Current;

                // Make sure there is only one attribute in the result set.
                //
                Debug.Assert(!attrEnumerator.MoveNext(), "Only a single attribute was expected.");

                return attr;
            }

            return default;
        }
    }
}
