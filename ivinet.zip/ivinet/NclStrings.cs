﻿namespace MindWorks.Nimbus
{
    internal static class NclStrings
    {
        internal static string OperationNotSupported(string typeName, string methodName)
        {
            return $"Operation not supported.\nOperation: {typeName}.{methodName}";
        }

        internal static string OperationNotSupportedForModel(string typeName, string methodName, string model)
        {
            return $"Operation not supported for instrument model {model}.\nOperation: {typeName}.{methodName}";
        }

        internal static string FailedToCreateVisaSession(string resourceDescriptor)
        {
            return $"Failed to create VISA session.\nResource: {resourceDescriptor}";
        }

        internal static string IdnQueryParseError(string response)
        {
            return $"Failed to parse the response to the* IDN? query.The response is expected to be a comma-separated list of 4 items in the following format:\n" +
$"<manufacturer>,<model>,<serial>,<firmware>\nReceived: {response}.";
        }

        internal const string CouldNotPerformErrorQuery =
            "Could not perform error query.";

        internal const string CouldNotPerformSelfTest =
            "Could not perform self test.";

        internal const string SelfTestPassed =
            "Self test passed.";

        internal const string ErrorQueryNoError =
            "No error.";

        internal static string ErrorQueryParseError(string response)
        {
            return $"Failed to parse the response to the SYST:ERR? query.\n" +
$"The response is expected to be a comma-separated list of 2 items in the following format:\n" +
$"<error integer code>,<error message>\n" +
$"Received: {response}.";
        }

        internal static string SelfTestParseError(string response)
        {
            return $"Failed to parse the response to the* TST? query.\n" +
$"The response is expected to be a comma-separated list of 2 items in the following format:\n" +
$"<result integer code>,<result message>\n" +
$"Received: {response}.";
        }

        internal static string CoercionEvent(string typeName, object originalValue, object coercedValue)
        {
            return $"{typeName}: Coerced from {originalValue} to {coercedValue}.";
        }

        internal static string CouldNotCreateCacheKeyForMethod(string typeName, string methodName)
        {
            return $"Could not create cache key for method {typeName}.{methodName}.  Cache keys can only be created for properties.";
        }

        internal static string CouldNotCreateCacheKeyForProperty(string typeName, string methodName)
        {
            return $"Could not create cache key for property {typeName}.{methodName}.";
        }

        internal static string CacheKeySyntaxError(string cacheKey)
        {
            return $"Cache key is in an invalid format. {cacheKey}";
        }

        internal const string OperationRequiresSingleEntryCacheKey =
            "Invalid cache key.The current operation requires a cache key that specifies only a single entry.";

        internal static string CouldNotFindRepCapClass(string interfaceName)
        {
            return $"Could not locate repeated capability class implementing repeated capability interface {interfaceName}.";
        }

        internal static string InvalidUseOfRepCapCollectionWithCache(string interfaceName)
        {
            return $"Internal error:  CacheKeyPrefix was called incorrectly repeated capability collection interface {interfaceName}.";
        }

        internal static string CouldNotFindRepCapCollectionClass(string interfaceName)
        {
            return $"Could not locate child repeated capability class implementing repeated capability collection interface {interfaceName}.";
        }

        internal static string CouldNotCreateRepCap(string repCap, string physicalName)
        {
            return $"Could not create instance of repeated capability {repCap} for physical name {physicalName}.";
        }

        internal static string AttributeValidationFailed(string attribute, string target)
        {
            return $"Validation of driver attribute {attribute} on {target} failed.";
        }

        internal static string AttributeValidationFailedWithDetails(string attribute, string target, string details)
        {
            return $"Validation of driver attribute {attribute}on {target}failed.\n{details}";
        }

        internal static string PhysicalNamesAttributeAppliedToWrongClass(string className)
        {
            return $"The PhysicalNames attribute cannot be applied to class {className}.  It can only be applied to classes that derive from RepCap.";
        }

        internal static string SyntaxErrorInPhysicalNamesAttribute(string className)
        {
            return $"Syntax error in PhysicalNames attribute on class {className}.";
        }

        internal static string InvalidRangeInPhysicalNamesAttribute(string className)
        {
            return $"Invalid range in PhysicalNames attribute on class {className}.";
        }

        internal static string EmptyPhysicalNamesListInPhysicalNamesAttribute(string className, string collectionClass)
        {
            return $"The PhysicalNames attribute on class {className} specifies an empty physical name list.This is valid only if the GetDynamicRepCapNames method has been overridden on the corresponding repeated capability collection class ({collectionClass}).";
        }

        internal static string RepeatedCapabilityAttributeCannotHaveEmptyRepCapName(string target)
        {
            return $"The RepeatedCapability attribute applied to {target} cannot have an empty repeated capability name.";
        }

        internal static string SyntaxErrorInPhysicalNamesListInRepeatedCapabilityAttribute(string repCap, string target)
        {
            return $"Syntax error in physical names list passed to RepeatedCapability attribute for repeated capability {repCap} applied to {target}.";
        }

        internal static string InvalidRangeInRepeatedCapabilityAttribute(string repCap, string target)
        {
            return $"Invalid range in physical names list passed to RepeatedCapability attribute for repeated capability {repCap} applied to {target}.";
        }

        internal static string EmptyPhysicalNamesListInRepeatedCapabilityAttribute(string repCap, string target)
        {
            return $"The RepeatedCapability attribute for repeated capability {repCap} applied to {target} specifies an empty physical name list.This is valid only if the GetDynamicRepCapNames method has been overridden on the {target} class.";
        }

        internal static string NestedPhysicalNamesMustHaveDepthTwo(string repCap, int depth)
        {
            return $"The PhysicalNames attribute for repeated capability {repCap} specifies a nested physical name with an invalid depth ({depth}).  Nested physical names must have a depth of two.";
        }

        internal static string CannotSpecifyParentOnSelectorStyleRepeatedCapabilityAttribute(string param1, string param2, string param3)
        {
            return $"The RepeatedCapability attribute applied to class {param1} for repeated capability {param2} specifies a parent of {param3}.  Selector style repeated capabilities cannot have parent repeated capabilities.";
        }

        internal const string InstrumentModelsAttributeMustSpecifyDefaultModel =
            "The InstrumentModels attribute must specify the DefaultModelForSimulation.";

        internal const string OneInstrumentModelsAttributeMustSpecifyDefaultModel =
            "One InstrumentModels attribute must specify the DefaultModelForSimulation.";

        internal const string OnlyOneInstrumentModelsAttributeCanSpecifyDefaultModel =
            "Only one InstrumentModels attribute can specify the default model for simulation.";

        internal const string DefaultModelMustBeInInstrumentModelsList =
            "The DefaultModelForSimulation must be set to one of the models listed in the InstrumentModels attribute.";

        internal const string DuplicateModelsInInstrumentModelsAttributes =
            "The InstrumentModels attributes contain duplicate model names.";

        internal const string DuplicateFamiliesInInstrumentModelsAttributes =
            "The InstrumentModels attributes contain duplicate family names.";

        internal const string FamilyCannotBeSetToModel =
            "The Family cannot be set to one of the specified models.";

        internal static string ValidationExpressionInvalid(string exceptionMessage)
        {
            return $"The ValidationExpression specified on the InstrumentModels attributes is not valid.\nArgument Exception: {exceptionMessage}";
        }

        internal const string MustSpecifyPrimaryInstrumentClass =
            "One SupportedInstrumentClass attribute must specify the primary instrument class.";

        internal const string OnlyOneSupportedInstrumentClassAttributeCanSpecifyPrimary =
            "Only one SupportedInstrumentClass attribute can specify the primary instrument class.";

        internal const string DuplicateInstrumentClassNames =
            "The SupportedInstrumentClass attribute contains duplicate instrument class names.";

        internal const string DriverSessionAndCapabilitiesAttributesRequireConsistentInterchangeChecking =
            "Update the DriverCapabilities attribute to indicate interchange checking is supported, or remove interchange checking from the DriverSession attribute.";

        internal static string DriverSessionAndCapabilitiesAttributesSpecifyInconsistentInterchangeChecking(string driverSessionInterchangeCheck, string driverCapabilitiesInterchangeCheck)
        {
            return $"The DriverSession and DriverCapabilities attributes specify inconsistent interchange checking features (DriverSession.InterchangeCheck = {driverSessionInterchangeCheck}, but DriverCapabilities.InterchangeCheck is {driverCapabilitiesInterchangeCheck}).";
        }

        internal static string ConfigurableInitialSettingAttributeValueOverflowMessage(string target, double value, double maxValue)
        {
            return $"A ConfigurableInitialSetting attribute applied to {target} has an unsigned integer value ({value}) that exceeds the maximum supported value of {maxValue} for signed integers required by the IVI config store.";
        }

        internal static string ConfigurableInitialSettingAttributeValueOverflowResolution(double maxResolution)
        {
            return $"Specify a value less than or equal to {maxResolution}.";
        }

        internal static string ConfigurableInitialSettingAttributeDuplicateKeyNameMessage(string keyName)
        {
            return $"More than one ConfigurableInitialSetting attribute specifies the same key name ({keyName}).";
        }

        internal const string ConfigurableInitialSettingAttributeDuplicateKeyNameResolution =
            "Ensure that unique key names are used.";

        internal static string ConfigurableInitialSettingAttributeValueTypeUnsupportedMessage(string target, string type)
        {
            return $"A ConfigurableInitialSetting attribute applied to {target} specifies a value whose type ({type}) is not supported.";
        }

        internal static string ConfigurableInitialSettingAttributeValueTypeUnsupportedResolution(string allowedTypes)
        {
            return $"Values specified via ConfigurableInitialSetting attribute must be one of the followed types: {allowedTypes}.";
        }

        internal const string ConfigurableInitialSettingAttributeKeyNameEmptyMessage =
            "Key names used with ConfigurableInitialSetting attribute cannot be empty or null.";

        internal const string ConfigurableInitialSettingAttributeKeyNameEmptyResolution =
            "Remove or correct the ConfigurableInitialSetting attribute that has an empty or null key name.";

        internal const string SelectorNameRequired =
            "The repeated capability selector name is required.";

        internal const string SingleRepeatedCapbilityIdentifierRequired =
            "Only a single repeated capability identifier can be specified for the current operation.";

        internal const string CannotReadMutipleRepCaps =
            "The active repeated capability selector cannot specify more than one physical name when performing a get operation.";

        internal static string ParentRepeatedCapabilityNotFound(string repCap, string parent)
        {
            return $"The RepeatedCapability attribute for repeated capability {repCap} specifies non-existent parent {parent}.";
        }

        internal static string RepeatedCapabilityNotDefined(string repCap)
        {
            return $"Repeated capability {repCap} is not defined.";
        }

        internal static string RepeatedCapabilityNotDefinedAsParameterStyle(string repCap)
        {
            return $"Repeated capability {repCap} is not defined as a parameter-style repeated capability.It is defined as a selector-style repeated capability.";
        }

        internal static string RepeatedCapabilityNotDefinedAsSelectorStyle(string repCap)
        {
            return $"Repeated capability {repCap} is not defined as a selector-style repeated capability.It is defined as a parameter-style repeated capability.";
        }

        internal static string NestedPhysicalNameSpecifiedOnNonNestedRepCap(string repCap)
        {
            return $"The PhysicalNames attribute for repeated capability {repCap} specifies a nested physical name for a non-nested repeated capability.";
        }

        internal static string InvalidParentPhysicalNameSpecifiedOnNestedRepCap(string repCap, string physicalName, string parentRepCap)
        {
            return $"The PhysicalNames attribute for nested repeated capability {repCap} specifies a parent physical name of {physicalName}, which does not exist for the parent repeated capability {parentRepCap}.";
        }

        internal static string DuplicatePhysicalNamesAttribute(string target)
        {
            return $"The PhysicalNames attribute appears more than once on class {target}.";
        }

        internal static string MissingPhysicalNamesAttribute(string target)
        {
            return $"The PhysicalNames attribute cannot be found on class {target}.";
        }

        internal static string RangeCheckEmptyAllowedValuesMessage(string attribute, string typeName, string memberName)
        {
            return $"The {attribute} attribute applied to {typeName}.{memberName} contains no allowed values.";
        }

        internal const string RangeCheckEmptyAllowedValuesResolution =
            "At least one value must be specified for the AllowedValues property.";

        internal static string RangeCheckDuplicateAllowedValuesMessage(string attribute, string typeName, string memberName)
        {
            return $"The {attribute} attribute applied to {typeName}.{memberName} contains duplicate allowed values.";
        }

        internal const string RangeCheckDuplicateAllowedValuesResolution =
            "Each item listed in AllowedValues must be unique.";

        internal static string RangeCheckMinNotLessThanMaxMessage(string typeName, string memberName, double minValue, double maxValue)
        {
            return $"The RangeCheckMinMax attribute applied to {typeName}.{memberName} has a Min value of {minValue} that is not less than the specified Max value of {maxValue}.";
        }

        internal const string RangeCheckMinNotLessThanMaxResolution =
            "The value specified for Min must be less than the value specified for Max.";

        internal static string RangeCheckDiscreteNaNMessage(string typeName, string memberName)
        {
            return $"The RangeCheckDiscrete attribute applied to {typeName}.{memberName} contains a value that is not a valid floating point number(NaN).";
        }

        internal const string RangeCheckDiscreteNaNResolution =
            "Correct or remove the invalid floating point value.";

        internal static string NestedRepeatedCapabilitiesMustHaveParentMessage(string target, string repCap)
        {
            return $"The RepeatedCapability attribute applied to {target} for nested repeated capability {repCap} does not specify the parent repeated capability name.";
        }

        internal static string NestedRepeatedCapabilitiesMustHaveParentResolution(string parentRepCapName, string repCapName)
        {
            return $"Use the : notation to fully qualify the repeated capability name to include the name of its parent repeated capability.\nFor example, {parentRepCapName}:{repCapName}.";
        }

        internal static string NestedRepeatedCapabilitiesInvalidParentMessage(string target, string repCap, string parentRepCap)
        {
            return $"The RepeatedCapability attribute applied to {target} for nested repeated capability {repCap} specifies an invalid parent repeated capability name of {parentRepCap}.";
        }

        internal const string NestedRepeatedCapabilitiesInvalidParentResolution =
            "Correct the repeated capability name so that a valid parent repeated capability name is specified.";

        internal static string PropertyDoesNotExist(string property, string typeName)
        {
            return $"The specific property ({property}) does not exist on type {typeName}.";
        }

        internal const string SyntaxErrorInCacheKey =
            "Syntax error in cache key.";

        internal static string SyntaxErrorInRepCapSelector(string selector)
        {
            return $"Syntax error in repeated capability selector '{selector}'.";
        }

        internal const string SimulationDefaultValueShouldBeSpecified =
            "The Default value for the Simulation attribute should be specified when the mode is ConstantValue or LastValueSet.";

        internal const string IndexPropertyNotAvailable =
            "The Index property is only available on repeated capabilities.";

        internal const string PhysicalNamePropertyNotAvailable =
            "The PhysicalName property is only available on repeated capabilities.";

        internal const string VirtualNamePropertyNotAvailable =
            "The VirtualName property is only available on repeated capabilities.";

        internal const string NoInstrumentModelDeclarationsFound =
            "No instrument model declarations could be located for the driver.";

        internal static string IOFunctionMustBeManuallyImplemented(string memberName)
        {
            return $"{memberName} must be manually implemented when not using VISA.NET.";
        }

        internal static string OperationNotAvailableInSimulationMode(string operation)
        {
            return $"The '{operation}' operation is not available while in simulation mode.";
        }

        internal static string InvalidDriverAssemblyName(string assemblyName)
        {
            return $"Driver assembly name '{assemblyName}' is not in the expected format.";
        }
    }
}
