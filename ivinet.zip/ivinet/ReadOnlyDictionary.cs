﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// This type is for internal use of the Nimbus Class Library and is not intended to be called directly from driver
    /// developer code.
    /// </summary>
    public sealed class ReadOnlyDictionary<TKey, TValue> : IEnumerable<KeyValuePair<TKey, TValue>>, IEnumerable
    {
        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public ReadOnlyDictionary()
        {
            this.Dictionary = new Dictionary<TKey, TValue>();
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public ReadOnlyDictionary(IDictionary<TKey, TValue> dictionary)
            : this(dictionary, comparer: null)
        {
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public ReadOnlyDictionary(IDictionary<TKey, TValue> dictionary, IEqualityComparer<TKey> comparer)
        {
            this.Dictionary = new Dictionary<TKey, TValue>(dictionary, comparer);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public ReadOnlyDictionary(IEqualityComparer<TKey> comparer)
        {
            this.Dictionary = new Dictionary<TKey, TValue>(comparer);
        }

        private Dictionary<TKey, TValue> Dictionary { get; set; }

        internal int Count => this.Dictionary.Count;

        internal ICollection<TKey> Keys => this.Dictionary.Keys;

        internal ICollection<TValue> Values => this.Dictionary.Values;

        internal TValue this[TKey key] => this.Dictionary[key];

        internal bool TryGetValue(TKey key, out TValue value)
        {
            return this.Dictionary.TryGetValue(key, out value);
        }

        internal bool ContainsKey(TKey key)
        {
            return this.Dictionary.ContainsKey(key);
        }

        internal bool ContainsValue(TValue value)
        {
            return this.Dictionary.ContainsValue(value);
        }

        #region IEnumerable<KeyValuePair<TKey,TValue>> Members

        IEnumerator<KeyValuePair<TKey, TValue>> IEnumerable<KeyValuePair<TKey, TValue>>.GetEnumerator()
        {
            return (this.Dictionary as IEnumerable<KeyValuePair<TKey, TValue>>).GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (this.Dictionary as IEnumerable).GetEnumerator();
        }

        #endregion
    }
}
