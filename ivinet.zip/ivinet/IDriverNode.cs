﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.Driver;
using System;
using System.Reflection;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Represents a node in the driver object model hierarchy.
    /// </summary>
    internal interface IDriverNode
    {
        IIviDriverLock AcquireLock();

        IIviDriverLock AcquireLock(PrecisionTimeSpan maxTime);

        string CacheKeyPrefix { get; }

        bool CacheContainsValue(object value);

        void CheckDisposed();

        DriverInfo DriverInfo { get; }

        bool GetCacheValue<T>(out T value);

        bool GetCacheValue<T>(string key, out T value);

        bool GetCacheValue(out object value);

        object GetDefaultValueForSimulation(Type targetType, string defaultValue);

        bool InstrumentInFamily(string family);

        bool InstrumentIsModel(string model);

        void InvalidateAllCacheEntries();

        void InvalidateCacheEntry(string key);

        DriverNode Parent { get; }

        void PollInstrumentErrors();

#if NCL_VISANET

        Ivi.Visa.IVisaSession VisaSession { get; }

        bool IsMessageBasedIOSession { get; }

        bool IsRegisterBasedIOSession { get; }

        Ivi.Visa.IMessageBasedSession IO { get; }

        Ivi.Visa.IRegisterBasedSession RegisterIO { get; }

        string ConvertEnumToString(Enum member);

        Enum ConvertStringToEnum<TEnum>(string data);

        bool TryConvertEnumToString(Enum member, out string result);

        bool TryConvertStringToEnum<TEnum>(string data, out Enum member);

#endif  // NCL_VISANET

        Driver Root { get; }

        SessionInfo Session { get; }

        void SendWarningEvent(WarningEventArgs args);

        void SendCoercionEvent(object originalValue, object coercedValue);

        void SendInterchangeEvent(InterchangeCheckWarningEventArgs args);

        void UpdateCacheValue(object value);

        void UpdateCacheValue(string key, object value);


        #region RangeCheckDiscreteAttribute operations: SByte
        sbyte CoerceUp(MethodBase member, sbyte value, sbyte[] allowedValues);

        sbyte CoerceDown(MethodBase member, sbyte value, sbyte[] allowedValues);

        bool IsOneOf(MethodBase member, sbyte value, sbyte[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: Byte
        byte CoerceUp(MethodBase member, byte value, byte[] allowedValues);

        byte CoerceDown(MethodBase member, byte value, byte[] allowedValues);

        bool IsOneOf(MethodBase member, byte value, byte[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int16
        short CoerceUp(MethodBase member, short value, short[] allowedValues);

        short CoerceDown(MethodBase member, short value, short[] allowedValues);

        bool IsOneOf(MethodBase member, short value, short[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: UInt16
        ushort CoerceUp(MethodBase member, ushort value, ushort[] allowedValues);

        ushort CoerceDown(MethodBase member, ushort value, ushort[] allowedValues);

        bool IsOneOf(MethodBase member, ushort value, ushort[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int32
        int CoerceUp(MethodBase member, int value, int[] allowedValues);

        int CoerceDown(MethodBase member, int value, int[] allowedValues);

        bool IsOneOf(MethodBase member, int value, int[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: UInt32
        uint CoerceUp(MethodBase member, uint value, uint[] allowedValues);

        uint CoerceDown(MethodBase member, uint value, uint[] allowedValues);

        bool IsOneOf(MethodBase member, uint value, uint[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int64
        long CoerceUp(MethodBase member, long value, long[] allowedValues);

        long CoerceDown(MethodBase member, long value, long[] allowedValues);

        bool IsOneOf(MethodBase member, long value, long[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: UInt64
        ulong CoerceUp(MethodBase member, ulong value, ulong[] allowedValues);

        ulong CoerceDown(MethodBase member, ulong value, ulong[] allowedValues);

        bool IsOneOf(MethodBase member, ulong value, ulong[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: Single
        float CoerceUp(MethodBase member, float value, float[] allowedValues);

        float CoerceDown(MethodBase member, float value, float[] allowedValues);

        bool IsOneOf(MethodBase member, float value, float[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: Double
        double CoerceUp(MethodBase member, double value, double[] allowedValues);

        double CoerceDown(MethodBase member, double value, double[] allowedValues);

        bool IsOneOf(MethodBase member, double value, double[] allowedValues);
        #endregion

        #region RangeCheckDiscreteAttribute operations: String
        bool IsOneOf(MethodBase member, string value, string[] allowedValues);
        #endregion
    }
}
