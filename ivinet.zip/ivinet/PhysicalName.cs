﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Represents a single repeated capability physical name.
    /// </summary>
    internal class PhysicalName
    {
        /// <summary>
        /// Creates a new instance of a PhysicalName object to represent the repeated capability instance. If the 
        /// number of levels of hierarchy in the full name specified does not match the level of nesting for the 
        /// associated repeated capability, then this method throws an exception. Also, if the parent repeated 
        /// capability physical names referenced do not exist, then this method throws an exception.
        /// </summary>
        /// <param name="fullName">
        /// The full repeated capability physical name including all parent identifiers (e.g. "a1:b2:c3").
        /// </param>
        /// <param name="manager">
        /// The repeated capability manager object for the repeated capability with which this physical name is 
        /// associated.
        /// </param>
        internal PhysicalName(string fullName, IRepCapManager manager)
        {
            this.FullName = fullName ?? throw new ArgumentNullException(nameof(fullName));
            this.Manager = manager ?? throw new ArgumentNullException(nameof(manager));
            this.Index = manager.PhysicalNameCount;

            var parts = fullName.Split(new[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
            var numberOfAncestorsInFullName = parts.Length - 1;

            if (numberOfAncestorsInFullName != this.Manager.GetNumberOfAncestors())
            {
                throw ErrorService.SelectorHierarchy(fullName);
            }

            if (numberOfAncestorsInFullName > 0)
            {
                if (this.Manager.Parent == null)
                {
                    throw ErrorService.SelectorHierarchy(fullName);
                }

                var lastColonIndex = fullName.LastIndexOf(':');
                this.Name = fullName.Substring(lastColonIndex + 1);

                var parentFullName = fullName.Substring(0, lastColonIndex);
                this.Parent = this.Manager.Parent.LookupPhysicalName(parentFullName);
            }
            else
            {
                if (this.Manager.Parent != null)
                {
                    throw ErrorService.SelectorHierarchy(fullName);
                }

                this.Name = parts[0];
            }

            this.QualifiedName = $"{this.Manager.RepCapName}!!{this.Name}";

            this.QualifiedFullName = (this.Parent == null)
                ? this.QualifiedName
                : $"{this.Parent.QualifiedFullName}:{this.QualifiedName}";
        }

        /// <summary>
        /// The repeated capability physical name.  For a nested repeated capability, this represents the identifier 
        /// for this particular repeated capability instance within the parent repeated capability instance.  For 
        /// example, the full name of a nested repeated capability would be of the form:
        /// 
        ///     "a1:b2:c3"
        ///     
        /// This Name property would have the value "c3" if this physical name were associated with the most nested 
        /// repeated capability of the three repeated capabilities in the hierarhcy implied above.
        /// </summary>
        internal string Name { get; private set; }

        /// <summary>
        /// Conditionally returns either the Name or the QualifiedName depending upon whether the parent repcap uses
        /// qualified physical names.
        /// </summary>
        internal string ExportedName => this.Manager.UseQualifiedPhysicalNames ? this.QualifiedName : this.Name;

        /// <summary>
        /// The 0-based index of the physical name within the collection.  For nested repeated capabilities, this 
        /// represents the index within the specific parent repeated capability instance's collection
        /// of child physical names.
        /// </summary>
        internal int Index { get; private set; }

        /// <summary>
        /// The full repeated capability physical name which includes the identifiers for all parent repeated 
        /// capability instances (e.g. "a1:b2:c3").
        ///     
        /// </summary>
        internal string FullName { get; private set; }

        /// <summary>
        /// The repeated capability manager object for the repeated capability with which this physical name is 
        /// associated.
        /// </summary>
        internal IRepCapManager Manager { get; private set; }

        /// <summary>
        /// The qualified physical name (e.g. "Channel!!c1").
        /// </summary>
        internal string QualifiedName { get; private set; }

        /// <summary>
        /// The qualified full physical name, which includes the qualified full name of the parent repeated capability 
        /// names (e.g. "Trace1:Channel!!c1").
        /// </summary>
        internal string QualifiedFullName { get; private set; }

        /// <summary>
        /// The repeated capability physical name of the parent, or null if the physical name is not defined on a 
        /// nested repeated capability.
        /// </summary>
        internal PhysicalName Parent { get; private set; }
    }
}
