﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;

namespace MindWorks.Nimbus
{
    internal interface IRepCapManager
    {
        PhysicalName LookupPhysicalName(string fullName);

        IRepCapManager Parent { get; }

        string RepCapName { get; }

        int GetNumberOfAncestors();

        int PhysicalNameCount { get; }

        bool UseQualifiedPhysicalNames { get; }
    }

    /// <summary>
    /// Represents the repeated capability collection object in the driver object model hierarchy.
    /// </summary>
    public abstract class RepCapManager : IRepCapManager
    {
        internal RepCapManager(string repCapName, SessionInfo session, bool useQualifiedPhysicalNames, IRepCapManager parent)
        {
            this.RepCapName = repCapName ?? throw new ArgumentNullException(nameof(repCapName));
            this.Session = session;
            this.UseQualifiedPhysicalNames = useQualifiedPhysicalNames;
            this.Parent = parent;
            this.PhysicalNames = new List<PhysicalName>();
        }

        /// <summary>
        /// The name of the repeated capability being manager (e.g. "Channel").
        /// </summary>
        internal string RepCapName { get; }

        /// <summary>
        /// The session information which consists of data loaded from the IVI Configuration Store as well as 
        /// information specified in the options specified in the driver's constructor call.
        /// </summary>
        internal SessionInfo Session { get; }

        /// <summary>
        /// Reference to the manager class for the parent repeated capability or null if this repeated capability is 
        /// not nested.  This property is typed as an IRepCapManager because it could be either a collection-style 
        /// repcap (which do not derive from the RepCapManager class) or a parameter or selector-style repcap (both of 
        /// which DO derive from the RepCapManager class).
        /// </summary>
        internal IRepCapManager Parent { get; }

        /// <summary>
        /// Indicates whether or not qualifed physical names are used in the IVI Configuration Store for the repeated 
        /// capability instances.  Physical names can be qualified by the repeated capability name or they can be 
        /// unqualified.  Qualified physical names are prefixed with the repeated capability name and delimited by 
        /// "!!".  For example, "Channel!!CH1" is an example of a qualified physical name, while "CH1" is an 
        /// unqualified physical name. 
        /// </summary>
        internal bool UseQualifiedPhysicalNames { get; }

        /// <summary>
        /// The ordered list of physical names defined for the current repeated capability.
        /// </summary>
        internal IList<PhysicalName> PhysicalNames { get; }

        /// <summary>
        /// Indicates if the specified physical name is defined for the current repeated capability.
        /// </summary>
        /// <param name="fullName">The physical name to search for.</param>
        /// <returns>True if the physical name is defined.  False otherwise.</returns>
        internal bool IsPhysicalNameDefined(string fullName)
        {
            return this.TryLookupPhysicalName(fullName, out _);
        }

        /// <summary>
        /// Returns the number of ancestor repeated capabilities.  For instance, if this repeated capability has only a
        /// parent, then this method returns 1.  If this repeated capability has a parent and a grandparent, then this 
        /// method returns 2.  If the current repeated capability is not nested, then this method returns 0.
        /// </summary>
        internal int GetNumberOfAncestors()
        {
            return GetNumberOfAncestors(this);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal static int GetNumberOfAncestors(IRepCapManager mananger)
        {
            var count = 0;
            var parent = mananger.Parent;

            while (parent != null)
            {
                count++;
                parent = parent.Parent;
            }

            return count;
        }

        /// <summary>
        /// Looks up the physical name object with the specified full name (e.g. "a1:b2:c3").  No exception is thrown 
        /// if this physical name is not found.
        /// </summary>
        /// <param name="fullName">The full physical name to look up, including all parent identifiers.</param>
        /// <param name="physicalName">The physical name object found or null if no physical name object with the 
        /// specified full name was found.</param>
        /// <returns>True if a physical name object with the specified full name was found.  False otherwise.</returns>
        internal bool TryLookupPhysicalName(string fullName, out PhysicalName physicalName)
        {
            physicalName = null;

            for (int i = 0; i < this.PhysicalNames.Count; i++)
            {
                if (String.Equals(this.PhysicalNames[i].FullName, fullName, StringComparison.OrdinalIgnoreCase))
                {
                    physicalName = this.PhysicalNames[i];
                    break;
                }
            }

            return physicalName != null;
        }

        /// <summary>
        /// Looks up the physical name object with the specified full name (e.g. "a1:b2:c3").  This method throws
        /// an exception if no physical name object is found with the specified full physical name.
        /// </summary>
        /// <param name="fullName">The full physical name to look up, including all parent identifiers.</param>
        /// <returns>The physical name object found or null if no physical name object with the specified full name was
        /// found.</returns>
        internal PhysicalName LookupPhysicalName(string fullName)
        {
            return this.TryLookupPhysicalName(fullName, out var physicalName)
                           ? physicalName
                           : throw ErrorService.SelectorName(this.RepCapName, fullName);
        }

        /// <summary>
        /// Expands the specified selector to a list of physical name objects.  If the selector is invalid according to
        /// the IVI-defined format for repated capability selectors or if any of the resulting physical namesare not 
        /// defined for this repeated capability, this method throws an exception.  The selector may contain virtual 
        /// and physical names. 
        /// 
        /// Selectors have a general form such as the following:
        ///
        ///		a1,a3,a5-a7:b2:[c5,c7]
        ///
        /// The formal syntax for repeated capability selectors is given in IVI 3.1 Section 4.4.7 Formal Syntax for 
        /// Repeated Capability Selectors.
        /// </summary>
        /// <param name="selector">
        /// The selector to expand.  This parameter may be empty or null if, and only if, the currentrepeated 
        /// capability has a single physical name defined.
        /// </param>
        /// <returns></returns>
        internal IList<PhysicalName> ExpandSelector(string selector)
        {
            if (String.IsNullOrEmpty(selector))
            {
                if (this.PhysicalNames.Count > 1)
                {
                    throw ErrorService.SelectorNameRequired(this.RepCapName);
                }

                if (this.PhysicalNames.Count == 1)
                {
                    return new[] { this.PhysicalNames[0] };
                }

                return new PhysicalName[0];
            }

            var names = new List<PhysicalName>();
            var selectorObject = RepCapSelector.Parse(selector);

            foreach (var fullPhysicalName in RepCapSelector.ExpandToPhysicalNames(selectorObject, this.Session))
            {
                names.Add(this.LookupPhysicalName(fullPhysicalName));
            }

            return names;
        }

        /// <summary>
        /// Adds a physical name to the collection.  For nested repeated capabilities, the name must be in the standard
        /// IVI-defined format for a nested physical name (e.g. "a1:b2:c3").  Note that all parent repeated capability
        /// physical names referenced must be added before adding the child physical name, else this method will throw
        /// an exception.
        /// </summary>
        /// <param name="fullPhysicalName">
        /// The full physical name of the repeated capability instance, including all parent instance identifiers. If 
        /// the number of levels of hierarchy in the physical name specified does not match the level of nesting for 
        /// this repeated capability, then this method throws an exception.
        /// </param>
        internal virtual PhysicalName AddPhysicalName(string fullPhysicalName)
        {
            var physicalName = new PhysicalName(fullPhysicalName, this);

            this.PhysicalNames.Add(physicalName);

            return physicalName;
        }

        /// <summary>
        /// Removes a physical name from the collection.  For nested repeated capabilities, the name must be in the 
        /// standard IVI-defined format for a nested physical name (e.g. "a1:b2:c3").
        /// </summary>
        /// <param name="fullPhysicalName">
        /// The full physical name of the repeated capability instance, including all parent instance identifiers. If 
        /// the number of levels of hierarchy in the physical name specified does not match the level of nesting for 
        /// this repeated capability, then this method throws an exception.
        /// </param>
        internal virtual void RemovePhysicalName(string fullPhysicalName)
        {
            for (int i = 0; i < this.PhysicalNames.Count; i++)
            {
                if (String.Equals(this.PhysicalNames[i].FullName, fullPhysicalName, StringComparison.OrdinalIgnoreCase))
                {
                    this.PhysicalNames.RemoveAt(i);
                    return;
                }
            }
        }

        #region IRepCapManager Members

        PhysicalName IRepCapManager.LookupPhysicalName(string fullName)
        {
            return this.LookupPhysicalName(fullName);
        }

        IRepCapManager IRepCapManager.Parent => this.Parent;

        string IRepCapManager.RepCapName => this.RepCapName;

        int IRepCapManager.GetNumberOfAncestors()
        {
            return this.GetNumberOfAncestors();
        }

        int IRepCapManager.PhysicalNameCount => this.PhysicalNames.Count;

        bool IRepCapManager.UseQualifiedPhysicalNames => this.UseQualifiedPhysicalNames;

        #endregion
    }
}
