///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Represents the repeated capability collection object in the driver object model hierarchy.
    /// </summary>
    public abstract class RepCapCollection : DriverNode, IRepCapManager
    {
        internal RepCapCollection(DriverNode parent, string repCapName)
            : base(parent)
        {
            this.RepCapName = repCapName;
        }

        /// <summary>
        /// Gets the name of the repeated capability with which this collection is associated.
        /// </summary>
        internal string RepCapName { get; private set; }

        /// <summary>
        /// Indicates whether or not qualifed physical names are used in the IVI Configuration Store for the repeated 
        /// capability instances.  Physical names can be qualified by the repeated capability name or they can be 
        /// unqualified.  Qualified physical names are prefixed with the repeated capability name and delimited by 
        /// "!!". For example, "Channel!!CH1" is an example of a qualified physical name, while "CH1" is an unqualified
        /// physical name. 
        /// </summary>
        internal bool UseQualifiedPhysicalNames { get; set; }

        /// <summary>
        /// Returns the set of repcap instances in this collection.
        /// </summary>
        internal abstract IEnumerable<RepCap> GetNodes();

        /// <summary>
        /// Returns the number of repcap instances in this collection.
        /// </summary>
        internal abstract int NodeCount { get; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        protected override string CacheKeyPrefix => (this.Parent as IDriverNode).CacheKeyPrefix;

        /// <summary>
        /// Gets the 0-based numeric index of the current repeated capability instance.
        /// </summary>
        internal abstract int Index { get; }

        /// <summary>
        /// Gets the unqualified physical name of the current repeated capability instance.  Note that the unqualified 
        /// name is returned even if the repeated capability instance name in the IVI Configuration Store is a qualified
        /// physical name.
        /// </summary>
        internal virtual string PhysicalName => this.PhysicalNameObject.Name;

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from
        /// driver developer code.
        /// </summary>
        internal abstract PhysicalName PhysicalNameObject { get; }

        /// <summary>
        /// Gets the virtual name mapped to the physical name of the current repeated capability instance.  If the IVI 
        /// Configuration Store contains no virtual name mapped  to this instance's physical name, then this property 
        /// returns the physical name.
        /// </summary>
        internal abstract string VirtualName { get; }

        #region IRepCapManager Members

        PhysicalName IRepCapManager.LookupPhysicalName(string fullName)
        {
            foreach (var node in this.GetNodes())
            {
                if (node.PhysicalNameObject.FullName == fullName)
                {
                    return node.PhysicalNameObject;
                }
            }

            return null;
        }

        IRepCapManager IRepCapManager.Parent => this.Parent is RepCap parentRepCap ? parentRepCap.Parent : null;

        string IRepCapManager.RepCapName => this.RepCapName;

        int IRepCapManager.GetNumberOfAncestors()
        {
            return RepCapManager.GetNumberOfAncestors(this);
        }

        int IRepCapManager.PhysicalNameCount => this.NodeCount;

        bool IRepCapManager.UseQualifiedPhysicalNames => this.UseQualifiedPhysicalNames;

        #endregion
    }
}
