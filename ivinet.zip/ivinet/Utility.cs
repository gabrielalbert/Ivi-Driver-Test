﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

namespace MindWorks.Nimbus
{
    internal static class Utility
    {
        /// <summary>
        /// Tests whether the given type implements the specified interface.
        /// </summary>
        /// <param name="type">The type to test.</param>
        /// <param name="intfType">The interface type to test for.</param>
        /// <returns>True if the given type implements the specified interface; otherwise False.</returns>
        ///
        internal static bool TypeImplementsInterface(Type type, Type intfType)
        {
            if (type == null) throw new ArgumentNullException(nameof(type));
            if (intfType == null) throw new ArgumentNullException(nameof(intfType));

            foreach (var baseIntfType in type.GetInterfaces())
            {
                if (baseIntfType == intfType)
                {
                    return true;
                }

                if (TypeImplementsInterface(baseIntfType, intfType))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Tests whether given type directly overrides the virtual method specified.
        /// </summary>
        /// <param name="targetType">The type to test.</param>
        /// <param name="virtualMethod">The virtual method to test for.</param>
        /// <returns>True if the given type directly overrides the specified virtual method; otherwise False.</returns>
        ///
        internal static bool TypeOverridesMethod(Type targetType, MethodInfo virtualMethod)
        {
            if (targetType == null) throw new ArgumentNullException(nameof(targetType));
            if (virtualMethod == null) throw new ArgumentNullException(nameof(virtualMethod));

            // Verify that the given method is virtual or abstract.
            //
            if (!virtualMethod.IsVirtual && !virtualMethod.IsAbstract)
            {
                return false;
            }

            // Verify that the target type does, in fact, derive from the type that the given virtual/abstract method
            // is defined on.  If not, the question is moot.
            //
            var declaringTypeForVirtualMethod = virtualMethod.DeclaringType;

            if (!declaringTypeForVirtualMethod.IsAssignableFrom(targetType))
            {
                return false;
            }

            // Locate all of the methods on the target type that are instance methods, and that have a visibility
            // (public or non-public) matching that of the specified virtual method.
            //
            var bindingFlags = BindingFlags.Instance | (virtualMethod.IsPublic ? BindingFlags.Public : BindingFlags.NonPublic);
            var methodsOnTargetType = targetType.GetMethods(bindingFlags);

            foreach (var method in methodsOnTargetType)
            {
                if (ReferenceEquals(method.GetBaseDefinition(), virtualMethod))
                {
                    // We've located the method in the target type that is related to the given virtual method via 
                    // inheritance.  Now check to see if we're dealing with an inherited implementation, or an override
                    // by this method's class.  Either way, we can stop checking methods.
                    //
                    return ReferenceEquals(method.DeclaringType, targetType);
                }
            }

            return false;
        }

        /// <summary>
        /// Tests whether the given collection contains the specified value.  If the given collection implements
        /// ICollection(Of <typeparamref name="T"/>), the Contains method on that collection is used to perform the
        /// membership test.  Otherwise, the IEqualityComparer(Of <typeparamref name="T"/>) will be used.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to process.</param>
        /// <param name="value">The value to search for within the collection.</param>
        /// <returns>True if the given collection contains the specified value; otherwise False.</returns>
        ///
        internal static bool Contains<T>(IEnumerable<T> source, T value)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            return source is ICollection<T> collection
                ? collection.Contains(value)
                : Contains(source, value, comparer: null);
        }

        /// <summary>
        /// Tests whether the given collection contains the specified value, using the given equality comparer.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to process.</param>
        /// <param name="value">The value to search for within the collection.</param>
        /// <param name="comparer">The equality comparer to use.</param>
        /// <returns>True if the given collection contains the specified value; otherwise False.</returns>
        ///
        internal static bool Contains<T>(IEnumerable<T> source, T value, IEqualityComparer<T> comparer)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            if (comparer == null)
            {
                comparer = EqualityComparer<T>.Default;
            }

            foreach (var item in source)
            {
                if (comparer.Equals(item, value))
                {
                    return true;
                }
            }

            return false;
        }


        /// <summary>
        /// Converts the given enumerable collection into a standard CLR array.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to process.</param>
        /// <returns>An array containing each of the items in the given collection.</returns>
        /// 
        internal static T[] ToArray<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            var list = new List<T>();

            foreach (var item in source)
            {
                list.Add(item);
            }

            return list.ToArray();
        }

        /// <summary>
        /// Returns the subset of the given collection that matches the condition expressed by the given predicate 
        /// (test function).
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to iterate over.</param>
        /// <param name="predicate">A delegate </param>
        /// <returns>The subset (possibly empty) of items from the input collection for which the given predicate 
        /// returned true.</returns>
        /// 
        internal static IEnumerable<T> Where<T>(IEnumerable<T> source, Predicate<T> predicate)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            foreach (var item in source)
            {
                if (predicate(item))
                {
                    yield return item;
                }
            }
        }

        /// <summary>
        /// Returns the first item in the given collection or, if the collection is empty, returns the default value
        /// for type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to iterate over.</param>
        /// <returns>The first item in the collection, if the collection is not empty; otherwise, 
        /// default(<typeparamref name="T"/>).</returns>
        ///
        internal static T FirstOrDefault<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            var enumerator = source.GetEnumerator();

            if (enumerator.MoveNext())
            {
                return enumerator.Current;
            }

            return default;
        }

        /// <summary>
        /// Returns the first item in the given collection or, if the collection is empty, returns the default
        /// value for type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to iterate over.</param>
        /// <param name="predicate">A delegate </param>
        /// <returns>The first item in the collection, if the collection is not empty; otherwise, default(<typeparamref name="T"/>).</returns>
        ///
        internal static T FirstOrDefault<T>(IEnumerable<T> source, Predicate<T> predicate)
        {
            return FirstOrDefault(Where(source, predicate));
        }

        /// <summary>
        /// Returns the number of items in the given collection.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to iterate over.</param>
        /// <returns>The number of items in the given collection.</returns>
        ///
        internal static int Count<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            var count = 0;
            var enumerator = source.GetEnumerator();

            while (enumerator.MoveNext())
            {
                count++;
            }

            return count;
        }

        /// <summary>
        /// Tests whether or not the given collection contains duplicate items.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to iterate over.</param>
        /// <returns>True if the collection contains any duplicate items; otherwise False.</returns>
        ///
        internal static bool ContainsDuplicates<T>(IEnumerable<T> source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            var itemsSeen = new List<T>();

            foreach (var item in source)
            {
                if (itemsSeen.Contains(item))
                {
                    return true;
                }

                itemsSeen.Add(item);
            }

            return false;
        }

        /// <summary>
        /// Returns a collection containing each item of the input collection cast to the type
        /// specified by <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to iterate over.</param>
        /// <returns>A collection containing each item from the input collection cast to the requested type.</returns>
        ///
        internal static IEnumerable<T> Cast<T>(IEnumerable source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));

            return source is IEnumerable<T> enumerable ? enumerable : CastIterator<T>(source);
        }

        internal static IEnumerable<T> CastIterator<T>(IEnumerable source)
        {
            foreach (var item in source)
            {
                yield return (T)item;
            }
        }

        /// <summary>
        /// Returns true if any of the items in the given collection match the condition expressed by
        /// the specified Predicate function.
        /// </summary>
        /// <typeparam name="T">The type of each element in the given collection.</typeparam>
        /// <param name="source">The collection to iterate over.</param>
        /// <param name="predicate">True if the specified function returns true for any items in the collection; 
        /// otherwise False.</param>
        /// <returns></returns>
        ///
        internal static bool Any<T>(IEnumerable<T> source, Predicate<T> predicate)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));

            foreach (var item in source)
            {
                if (predicate(item))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
