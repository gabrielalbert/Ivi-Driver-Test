///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Represents the repeated capability container object in the driver object model hierarchy.
    /// </summary>
    internal class RepCapCollection<TRepCap> : RepCapCollection, IEnumerable<TRepCap>
        where TRepCap : RepCap, new()
    {
        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal RepCapCollection(DriverNode parent, string repCapName)
            : base(parent, repCapName)
        {
        }

        internal override void InitNode()
        {
            var physicalNames = new List<string>();

            // Get the physical names specified in the PhysicalNames attribute.
            //
            var attrs = (PhysicalNamesAttribute[])typeof(TRepCap).GetCustomAttributes(typeof(PhysicalNamesAttribute), false);
            Debug.Assert(attrs != null && attrs.Length == 1);

            if (attrs == null || attrs.Length == 0)
            {
                throw new InvalidOperationException(NclStrings.MissingPhysicalNamesAttribute(typeof(TRepCap).Name));
            }

            if (attrs.Length != 1)
            {
                throw new InvalidOperationException(NclStrings.DuplicatePhysicalNamesAttribute(typeof(TRepCap).Name));
            }

            var attr = attrs[0];
            this.UseQualifiedPhysicalNames = attr.UseQualifiedNames;

            var selector = attr.Validate(typeof(TRepCap));

            var attrPhysicalNames = RepCapSelector.ExpandToPhysicalNames(selector, null);

            if (selector.IsNested)
            {
                // The physical names have been explicitly specified, so make sure our parent actually is a repcap and then create 
                // only those physical names that explicitly include the parent repcap instance name.
                //
                if (!(this.Parent is RepCap))
                {
                    throw new InvalidOperationException(NclStrings.NestedPhysicalNameSpecifiedOnNonNestedRepCap(this.RepCapName));
                }

                foreach (var attrNestedPhysicalName in attrPhysicalNames)
                {
                    var parts = attrNestedPhysicalName.Split(':');

                    if (parts.Length != 2)
                    {
                        throw ErrorService.SelectorHierarchy(selector.Source);
                    }

                    var attrParentPhysicalName = parts[0];

                    if (attrParentPhysicalName == this.PhysicalName)
                    {
                        var physicalName = parts[1];
                        physicalNames.Add(physicalName);
                    }
                }
            }
            else
            {
                // The physical names are either not nested or they do not explicitly specify nested physical names, so we simply 
                // add all of the physical names represented by the selector.
                //
                physicalNames.AddRange(attrPhysicalNames);
            }

            // Get the dynamic repcap names
            //
            this.GetDynamicRepCapNames(this.RepCapName, physicalNames);

            int index = 0;
            foreach (var physicalName in physicalNames)
            {
                var repCap = RepCap.CreateInstance<TRepCap>(this, index, physicalName);

                if (repCap == null)
                {
                    throw new InvalidOperationException(NclStrings.CouldNotCreateRepCap(typeof(TRepCap).Name, physicalName));
                }

                repCap.InitNode();

                this.Append(repCap);

                index++;
            }
        }

        /// <summary>
        /// Maps an unqualified physical name to the repeated capability instance.  Note that the nodes are always keyed by unqualified names, irrespective
        /// of whether or not qualified physical names are used in the IVI Configuration Store.
        /// </summary>
        private Dictionary<string, TRepCap> NodeNameMap { get; } = new Dictionary<string, TRepCap>();

        private List<TRepCap> NodesList { get; } = new List<TRepCap>();

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal override IEnumerable<RepCap> GetNodes()
        {
            foreach (var node in this.NodesList)
            {
                yield return node;
            }
        }


        internal override int NodeCount => this.NodesList.Count;

        /// <summary>
        /// Gets the 0-based numeric index of the current repeated capability instance.
        /// </summary>
        internal override int Index
            => (this.Parent is RepCap parentRepCap)
                ? parentRepCap.Index
                : throw new InvalidOperationException(NclStrings.IndexPropertyNotAvailable);

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from
        /// driver developer code.
        /// </summary>
		internal override PhysicalName PhysicalNameObject
            => (this.Parent is RepCap parentRepCap)
                ? parentRepCap.PhysicalNameObject
                : throw new InvalidOperationException(NclStrings.PhysicalNamePropertyNotAvailable);

        /// <summary>
        /// Gets the virtual name mapped to the physical name of the current repeated capability instance.  If the IVI Configuration Store contains no virtual name mapped 
        /// to this instance's physical name, then this property returns the physical name.
        /// </summary>
        internal override string VirtualName
            => (this.Parent is RepCap parentRepCap)
                ? parentRepCap.VirtualName
                : throw new InvalidOperationException(NclStrings.VirtualNamePropertyNotAvailable);

        /// <summary>
        /// Gets the number of repeated capability instances in the collection.
        /// </summary>
        internal int Count => this.NodesList.Count;

        /// <summary>
        /// Gets a child repeated capability instance using either the physical name or a virtual name.  This indexer will throw a
        /// SelectorNameException if the instance is not found in the current list.
        /// </summary>
        /// <param name="name">The physical or virtual name of the child repeated capability instance to retrieve.  For physical names,
        /// either the qualified or unqualified name may be used.
        /// </param>
        /// <returns>The repeated capability instance.</returns>
        internal TRepCap this[string name]
            => GetRepCap(name) ?? throw ErrorService.SelectorName(this.RepCapName, name);

        /// <summary>
        /// Gets a child repeated capability instance using either the physical name or a virtual name.  This method differs from the
        /// indexer only in that this method will not throw a SelectorNameException if the instance is not found in the current list.
        /// </summary>
        /// <param name="name">The physical or virtual name of the child repeated capability instance to retrieve.  For physical names,
        /// either the qualified or unqualified name may be used.
        /// </param>
        /// <returns>The repeated capability instance.</returns>
        internal TRepCap GetRepCap(string name)
        {
            // An empty selector is only valid if there is a single item
            //
            if (TextUtility.IsWhiteSpace(name))
            {
                if (this.Count == 1)
                {
                    return this.NodesList[0];
                }

                throw ErrorService.SelectorNameRequired(this.RepCapName);
            }

            // Collection-style repcap selectors cannot include ranges or nesting
            //
            if (!RepCapSelector.IsValidCollectionStyleSelector(name))
            {
                throw ErrorService.SelectorFormat(name);
            }

            name = TextUtility.RemoveWhiteSpace(name);

            // There are three possibilities for the name that the user can supply:
            //	1. A virtual name
            //	2. An unqualified physical name
            //	3. A qualified physical name
            //
            var physicalName = this.Session.TranslateVirtualName(name);

            if (String.Equals(physicalName, name, StringComparison.OrdinalIgnoreCase))
            {
                const string separator = "!!";

                // No mapping was found OR they specified a physical name in the wrong PhysicalNameFormat
                //
                var index = name.IndexOf(separator, StringComparison.Ordinal);

                if (index > 0)
                {
                    // A qualified name was specified
                    //
                    if (!this.UseQualifiedPhysicalNames)
                    {
                        // They specified a name in the wrong format, so fixup the name and try the translation again
                        //
                        name = name.Substring(index + separator.Length);

                        physicalName = this.Session.TranslateVirtualName(name);
                    }
                    else
                    {
                        // They specified a physical name in the correct PhysicalNameFormat, so there really is no virtual name mapped to the physical name
                    }
                }
                else
                {
                    // An unqualified name was specified
                    //
                    if (this.UseQualifiedPhysicalNames)
                    {
                        // They specified a name in the wrong PhysicalNameFormat, so fixup the name and try the translation again
                        //
                        name = this.RepCapName + separator + name;

                        physicalName = this.Session.TranslateVirtualName(name);
                    }
                    else
                    {
                        // They specified a physical name in the correct PhysicalNameFormat, so there really is no virtual name mapped to the physical name
                    }
                }
            }

            this.NodeNameMap.TryGetValue(physicalName, out var repCapNode);

            return repCapNode;
        }

        /// <summary>
        /// Gets a child repeated capability instance by index.
        /// </summary>
        /// <param name="index">The 0-based index of the repeated capability instance to retrieve.</param>
        /// <returns>The repeated capability instance at the given index.</returns>
        internal TRepCap this[int index]
        {
            get
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new ArgumentOutOfRangeException(nameof(index));
                }

                return this.NodesList[index];
            }
        }

        private void Append(TRepCap node)
        {
            this.NodeNameMap.Add(node.PhysicalName, node);
            this.NodesList.Add(node);
        }

        private void Remove(TRepCap repCap)
        {
            this.NodeNameMap.Remove(repCap.PhysicalName);
            this.NodesList.Remove(repCap);
        }

        /// <summary>
        /// Adds a new repeated capability instance with the specified name.  No virtual-to-physical name translation is
        /// performed on the specified name. This method is useful for implementing IviLxiSync methods that allow the 
        /// end-user of the driver to add repeated capabilities at runtime. 
        /// </summary>
        /// <param name="physicalName">
        /// The name to assign to the new repeated capability instance.  Only a single name can be specified.  Ranges are not supported.
        /// </param>
        /// <returns>The newly created repeated capability instance.</returns>
        internal TRepCap AddRepCap(string physicalName)
        {
            if (physicalName == null) throw new ArgumentNullException(nameof(physicalName));

            // Collection-style repcap selectors cannot include ranges or nesting
            //
            if (!RepCapSelector.IsValidCollectionStyleSelector(physicalName))
            {
                throw ErrorService.SelectorFormat(physicalName);
            }

            var index = this.NodesList.Count;
            var repCap = RepCap.CreateInstance<TRepCap>(this, index, physicalName);

            if (repCap == null)
            {
                throw new InvalidOperationException(NclStrings.CouldNotCreateRepCap(typeof(TRepCap).Name, physicalName));
            }

            repCap.InitNode();

            this.Append(repCap);

            return repCap;
        }

        /// <summary>
        /// Removes an existing repeated capability instance with the specified name.  No virtual-to-physical name
        /// translation is performed on the specified name.  This method is useful for implementing IviLxiSync methods
        /// that allow the end-user of the driver to remove repeated capabilities at runtime.  
        /// </summary>
        /// <param name="physicalName">
        /// The name of the repeated capability instance to remove.  Only a single name can be specified.  Ranges are not supported.
        /// </param>
        /// <param name="throwIfNotFound">
        /// Indicates if the method should throw a SelectorNameException if the specified name is not currently in the list of repeated capability instances.
        /// </param>
        /// <returns>True if the instance was found and removed.  False otherwise.</returns>
        internal bool RemoveRepCap(string physicalName, bool throwIfNotFound)
        {
            if (physicalName == null) throw new ArgumentNullException(nameof(physicalName));

            // Collection-style repcap selectors cannot include ranges or nesting
            //
            if (!RepCapSelector.IsValidCollectionStyleSelector(physicalName))
            {
                throw ErrorService.SelectorFormat(physicalName);
            }

            var repCap = GetRepCap(physicalName);

            if (repCap != null)
            {
                // Decrement by 1 the instance index of all the instances that follow the instance we are about to remove
                //
                for (int i = repCap.Index + 1; i < this.NodesList.Count; i++)
                {
                    this.NodesList[i].Index--;
                }

                this.Remove(repCap);

                return true;
            }

            if (throwIfNotFound)
            {
                throw ErrorService.SelectorName(this.RepCapName, physicalName);
            }

            return false;
        }

        #region IEnumerable<DriverRepCapNode> Members

        IEnumerator<TRepCap> IEnumerable<TRepCap>.GetEnumerator()
        {
            foreach (var node in this.NodesList)
            {
                yield return node;
            }
        }

        #endregion

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            return ((IEnumerable<RepCap>)this).GetEnumerator();
        }

        #endregion
    }
}
