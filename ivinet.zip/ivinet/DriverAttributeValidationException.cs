﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// This class is for internal use of the Nimbus Class Library and is not intended to be used directly by driver 
    /// developer code.
    /// </summary>
    [Serializable]
    public class DriverAttributeValidationException<TAttr> : Exception
    {
        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public DriverAttributeValidationException()
            : this(innerException: null)
        {
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public DriverAttributeValidationException(Exception innerException)
            : this(message: String.Empty, innerException)
        {
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public DriverAttributeValidationException(string targetName, string validationDetails, params object[] args)
            : this(targetName, validationDetails, innerException: null, args)
        {
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public DriverAttributeValidationException(string targetName, string validationDetails, Exception innerException, params object[] args)
            : base(message: String.Empty, innerException)
        {
            base.Data["message"] = FormatMessage(targetName, validationDetails, args);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public DriverAttributeValidationException(string message, params object[] args)
            : this(message, innerException: null, args)
        {
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public DriverAttributeValidationException(string message, Exception innerException, params object[] args)
            : base(String.Format(message, args), innerException)
        {
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        protected DriverAttributeValidationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        private static string FormatMessage(string targetName, string details, params object[] args)
        {
            var attrTypeName = typeof(TAttr).Name;
            var formattedDetails = String.Format(details, args);

            return String.IsNullOrEmpty(formattedDetails)
                ? NclStrings.AttributeValidationFailed(attrTypeName, targetName)
                : NclStrings.AttributeValidationFailedWithDetails(attrTypeName, targetName, formattedDetails);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        public override string Message => (string)base.Data["message"] ?? base.Message;
    }
}
