///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.ConfigServer;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Information about a particular driver session. Initialized when the driver is initialized and can change during
    /// driver execution.  Contains default values before the driver is initialized and after the driver is closed.
    /// </summary>
    public class SessionInfo
    {
        private string _instrumentManufacturer;
        private string _instrumentModel;
        private string _instrumentSerialNumber;
        private string _instrumentFirmwareRevision;

        /// <summary>
        /// This constructor is marked private to prevent external construction.  Valid instances of this class are 
        /// obtained by calling the static Load method.
        /// </summary>
        private SessionInfo()
        {
            this.DriverSetup = new ReadOnlyDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            this.ConfigSettings = new ReadOnlyDictionary<string, object>();
            this.OriginalVirtualToPhysicalNameMap = new ReadOnlyDictionary<string, string>();
            this.ExpandedVirtualToPhysicalNameMap = new ReadOnlyDictionary<string, string>();
            this.ExpandedPhysicalToVirtualNameMap = new ReadOnlyDictionary<string, string>();

            this.InitOptions = new InitOptions();
            this.OriginalInitOptions = new InitOptions();

            this.ResourceDescriptor = String.Empty;
            this.LogicalName = String.Empty;
            this.InitOptionsString = String.Empty;
            this.DriverSetupString = String.Empty;

            _instrumentManufacturer = String.Empty;
            _instrumentModel = String.Empty;
            _instrumentSerialNumber = String.Empty;
            _instrumentFirmwareRevision = String.Empty;

            this.InitOptions.InitializeToIviDefinedDefaults();
        }

        /// <summary>
        /// Map of virtual name (in lowercase) to physical name (case unchanged) as they were originally loaded from 
        /// the IVI Configuration Store.  A single virtual name can map to a range of physical names.  Virtual names 
        /// can also map to nested physical names, as well as ranges thereof.  This map stores those original 
        /// associations.
        /// </summary>
        private ReadOnlyDictionary<string, string> OriginalVirtualToPhysicalNameMap { get; set; }

        /// <summary>
        /// Map of virtual name (in lowercase) to physical name (case unchanged).  The physical name returned is the 
        /// qualified physical name, if qualified physical names were specified in the IVI Configuration Store.  
        /// Otherwise, the physical name returned is the unqualified physical name. This map contains the set of 
        /// mappings resulting from expanding lists and ranges.  Use the OriginalVirtualToPhysicalNameMap to access the
        /// original, unexpanded mappings.
        /// </summary>
        private ReadOnlyDictionary<string, string> ExpandedVirtualToPhysicalNameMap { get; set; }

        /// <summary>
        /// Map of physical name (in lowercase) to virtual name (case unchanged).  The virtual names are keyed by the 
        /// qualified physical name, if qualified physical names were specified in the IVI Configuration Store.  
        /// Otherwise, the virtual names are keyed by the unqualified physical name. This map contains the set of 
        /// mappings resulting from expanding lists and ranges.  Use the OriginalVirtualToPhysicalNameMap to access the
        /// original, unexpanded mappings.
        /// </summary>
        private ReadOnlyDictionary<string, string> ExpandedPhysicalToVirtualNameMap { get; set; }

        /// <summary>
        /// Map of configuration component name (in lowercase) to value (case unchanged).
        /// Type of value can be string, Int32, Double or Boolean.
        /// </summary>
        internal ReadOnlyDictionary<string, object> ConfigSettings { get; private set; }

        /// <summary>
        /// Map of option name (in lowercase) to option value (case unchanged).
        /// </summary>
        internal ReadOnlyDictionary<string, string> DriverSetup { get; private set; }

        /// <summary>
        /// Gets the current value of the driver initialization options.
        /// </summary>
        internal InitOptions InitOptions { get; private set; }

        /// <summary>
        /// Gets the original value of the driver initialization options that were established during instantiation of 
        /// the driver and, possibly, parsing of 
        /// IVI Configuration Store data.
        /// </summary>
        internal InitOptions OriginalInitOptions { get; private set; }

        /// <summary>
        /// Enables or disables tracing of driver execution.  NOTE: Tracing is not currently implemented, so changing 
        /// the value of this property has no effect.
        /// </summary>
        internal bool TraceEnabled { get; set; }

        internal string InitOptionsString { get; private set; }

        /// <summary>
        /// Gets the driver setup string that the user specified in the configuration store when the driver session 
        /// was instantiated or that the user passed to the driver constructor.
        /// </summary>
        internal string DriverSetupString { get; private set; }

        internal string ResourceDescriptor { get; private set; }

        internal string LogicalName { get; private set; }

        internal string InstrumentFirmwareRevision
        {
            get => _instrumentFirmwareRevision;
            set => _instrumentFirmwareRevision = value ?? throw new ArgumentNullException(nameof(value));
        }

        internal string InstrumentSerialNumber
        {
            get => _instrumentSerialNumber;
            set => _instrumentSerialNumber = value ?? throw new ArgumentNullException(nameof(value));
        }

        internal string InstrumentManufacturer
        {
            get => _instrumentManufacturer;
            set => _instrumentManufacturer = value ?? throw new ArgumentNullException(nameof(value));
        }

        internal string InstrumentModel
        {
            get => _instrumentModel;
            set => _instrumentModel = value ?? throw new ArgumentNullException(nameof(value));
        }

        /// <summary>
        /// Returns the unqualified physical name associated with the specified virtual name.  
        /// </summary>
        /// <param name="virtualName">The virtual name to translate.</param>
        /// <returns>  
        /// The unqualified physical name associated with the specified virtual name. If a qualified physical name was 
        /// specified in the IVI Configuration Store, then the repeated capability name prefix (e.g. "Channel!!") is 
        /// stripped and only the unqualified name is returned.
        /// </returns>
        internal string TranslateVirtualName(string virtualName)
        {
            var virtualNameLower = virtualName.ToLower();

            if (!this.ExpandedVirtualToPhysicalNameMap.TryGetValue(virtualNameLower, out var physicalName))
            {
                physicalName = virtualName;
            }

            const string qualifiedNameSeparator = "!!";
            var qualifiedNameSeparatorIndex = physicalName.IndexOf(qualifiedNameSeparator);

            if (qualifiedNameSeparatorIndex >= 0)
            {
                // It's a physical name qualified by the repcap name, so we only return the unqualified physical name.
                //
                physicalName = physicalName.Substring(qualifiedNameSeparatorIndex + qualifiedNameSeparator.Length);
            }

            return physicalName;
        }

        /// <summary>
        /// Returns the virtual name associated with the specified physical name.  
        /// </summary>
        /// <param name="physicalName">The physical name to translate.  If a qualified physical name was specified in 
        /// the IVI Configuration Store, then this parameter must also be that same qualified physical name.</param>
        /// <returns>The virtual name associated with the specified physical name.</returns>
        internal string TranslatePhysicalName(string physicalName)
        {
            var physicalNameLower = physicalName.ToLower();

            if (!this.ExpandedPhysicalToVirtualNameMap.TryGetValue(physicalNameLower, out var virtualName))
            {
                virtualName = physicalName;
            }

            return virtualName;
        }

        private void SaveInitialOptions()
        {
            this.OriginalInitOptions = (InitOptions)this.InitOptions.Clone();
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        /// 
        internal void RestoreInitialOptions()
        {
            this.InitOptions = (InitOptions)this.OriginalInitOptions.Clone();
        }

        private const string ConfigurableInitialSettingsDataComponentName = "Configurable Initial Settings";

        /// <summary>
        /// Parse the session information specified by the parameters.
        /// </summary>
        /// <param name="driver">The driver object to initialize.</param>
        /// <param name="resourceName">Resource name can be a resource descriptor, or a logical name in the 
        /// configuration store.  This can be empty.</param>
        /// <param name="options">Inherent options and driver setup options.  This can be empty.</param>
        /// <param name="softwareModuleName">Name of the software module in the configuration store.  This must be 
        /// valid software module name in the configuration store.</param>
        /// <returns>Session information.</returns>
        internal static SessionInfo Load(Driver driver, string resourceName, string options, string softwareModuleName)
        {
            if (resourceName == null) throw new ArgumentNullException(nameof(resourceName));
            if (options == null) throw new ArgumentNullException(nameof(options));
            if (softwareModuleName == null) throw new ArgumentNullException(nameof(softwareModuleName));

            // Create with IVI default values.
            //
            var info = new SessionInfo();

            // Override with the values in the config store.
            //
            LoadSessionInfoFromConfigStore(info, resourceName, softwareModuleName);

            // Override with the values in the options.
            //
            ProcessOptions(driver, info, options);

            // Save a copy of the options so they can be restored later.
            //
            info.SaveInitialOptions();

            return info;
        }

        private static void LoadSessionInfoFromConfigStore(SessionInfo info, string resourceName, string softwareModuleName)
        {
            var location = String.IsNullOrEmpty(ConfigStore.ProcessDefaultLocation)
                ? ConfigStoreLocation.Master
                : ConfigStoreLocation.ProcessDefault;

            var store = ConfigStore.Load(location);

            var session = store.GetDriverSession(resourceName);

            if (session != null)
            {
                info.LogicalName = resourceName;

                info.ResourceDescriptor = String.Empty;

                ProcessDriverSession(info, session);
            }
            else
            {
                info.LogicalName = String.Empty;

                info.ResourceDescriptor = resourceName;

                var software = FindSoftwareModule(store, softwareModuleName)
                    ?? throw ErrorService.SoftwareModuleNotFound(resourceName, softwareModuleName);

                if (FindDataComponent(software, ConfigurableInitialSettingsDataComponentName) is IviStructure settings)
                {
                    ParseConfigurableInitialSettings(info, settings);
                    ProcessConfigurableInitialSettings(info);
                }
            }
        }

        private static void ProcessDriverSession(SessionInfo info, DriverSession driverSession)
        {
            var hardware = driverSession.HardwareAsset;

            if (hardware?.IOResourceDescriptor != null)
            {
                info.ResourceDescriptor = hardware.IOResourceDescriptor;
            }

            info.InitOptions.CachingEnabled = driverSession.Cache;
            info.InitOptions.InterchangeCheckingEnabled = driverSession.InterchangeCheck;
            info.InitOptions.QueryInstrumentStatusEnabled = driverSession.QueryInstrStatus;
            info.InitOptions.RangeCheckingEnabled = driverSession.RangeCheck;
            info.InitOptions.CoercionRecordingEnabled = driverSession.RecordCoercions;
            info.InitOptions.SimulationEnabled = driverSession.Simulate;
            info.DriverSetupString = driverSession.DriverSetup;

            if (FindDataComponent(driverSession, ConfigurableInitialSettingsDataComponentName) is IviStructure settings)
            {
                ParseConfigurableInitialSettings(info, settings);
                ProcessConfigurableInitialSettings(info);
            }

            LoadVirtualNames(info, driverSession);
        }

        private static void ProcessConfigurableInitialSettings(SessionInfo info)
        {
            if (info.ConfigSettings.TryGetValue("model", out var model))
            {
                info.InstrumentModel = model as string;
            }
        }

        private static void LoadVirtualNames(SessionInfo info, DriverSession session)
        {
            var originalVirtualToPhysicalNameMap = new Dictionary<string, string>();
            var expandedVirtualToPhysicalNameMap = new Dictionary<string, string>();
            var expandedPhysicalToVirtualNameMap = new Dictionary<string, string>();

            foreach (var virtualName in session.VirtualNames)
            {
                if (virtualName.VirtualRanges.Count == 0)
                {
                    // This virtual name is mapped to a single physical name.
                    //
                    var virt = virtualName.Name;
                    var phys = virtualName.MapTo;

                    var virtLower = virt.ToLower(CultureInfo.CurrentCulture);
                    var physLower = phys.ToLower(CultureInfo.CurrentCulture);

                    originalVirtualToPhysicalNameMap.Add(virtLower, phys);
                    expandedVirtualToPhysicalNameMap.Add(virtLower, phys);
                    expandedPhysicalToVirtualNameMap.Add(physLower, virt);
                }
                else
                {
                    foreach (var virtualRange in virtualName.VirtualRanges)
                    {
                        for (var virtIndex = virtualRange.Min; virtIndex <= virtualRange.Max; virtIndex++)
                        {
                            var physIndex = virtIndex + virtualRange.StartingPhysicalIndex - virtualRange.Min;

                            var virt = $"{virtualName.Name}{virtIndex}";
                            var phys = $"{virtualName.MapTo}{physIndex}";

                            var virtLower = virt.ToLower(CultureInfo.CurrentCulture);
                            var physLower = phys.ToLower(CultureInfo.CurrentCulture);

                            originalVirtualToPhysicalNameMap.Add(virtLower, phys);
                            expandedVirtualToPhysicalNameMap.Add(virtLower, phys);
                            expandedPhysicalToVirtualNameMap.Add(physLower, virt);
                        }
                    }
                }
            }

            info.OriginalVirtualToPhysicalNameMap = new ReadOnlyDictionary<string, string>(originalVirtualToPhysicalNameMap);
            info.ExpandedVirtualToPhysicalNameMap = new ReadOnlyDictionary<string, string>(expandedVirtualToPhysicalNameMap);
            info.ExpandedPhysicalToVirtualNameMap = new ReadOnlyDictionary<string, string>(expandedPhysicalToVirtualNameMap);
        }

        private static void ParseConfigurableInitialSettings(SessionInfo info, IviStructure settings)
        {
            var configSettings = new Dictionary<string, object>();

            foreach (var component in settings.DataComponents)
            {
                var name = component.Name.ToLower(CultureInfo.CurrentCulture);

                switch (component)
                {
                    case IviString str:
                        configSettings.Add(name, str.Value);
                        break;

                    case IviInteger integer:
                        configSettings.Add(name, integer.Value);
                        break;

                    case IviReal real:
                        configSettings.Add(name, real.Value);
                        break;

                    case IviBoolean boolean:
                        configSettings.Add(name, boolean.Value);
                        break;

                    default:
                        break;
                }
            }

            info.ConfigSettings = new ReadOnlyDictionary<string, object>(configSettings);
        }

        private static void ProcessOptions(Driver driver, SessionInfo info, string options)
        {
            info.InitOptionsString = options;

            ExtractInherentAndDriverSetupOptions(options, out var inherentOptions, out var driverSetup);

            ProcessInherentOptions(info, inherentOptions);

            // It's null if no "DriverSetup" was found in the initialize options.
            //
            if (driverSetup != null)
            {
                info.DriverSetupString = driverSetup;
            }
            else
            {
                // The user did not specify a DriverSetup string in the constructor, so keep the DriverSetupString to 
                // the value read from the DriverSession (if any).
                //
            }

            ProcessDriverSetup(driver, info);
        }

        private static void ExtractInherentAndDriverSetupOptions(string options, out string inherentOptions, out string driverSetupOptions)
        {
            const string driverSetupToken = "driversetup=";
            var driverSetupIndex = options.ToLower(CultureInfo.CurrentCulture).IndexOf(driverSetupToken, StringComparison.OrdinalIgnoreCase);

            if (driverSetupIndex >= 0)
            {
                inherentOptions = options.Substring(0, driverSetupIndex);
                driverSetupOptions = options.Substring(driverSetupIndex + driverSetupToken.Length);
            }
            else
            {
                inherentOptions = options;
                driverSetupOptions = null;
            }
        }

        /// <summary>
        /// Parse the IVI-defined inherent options.
        /// </summary>
        /// <param name="info">The associated session information object.</param>
        /// <param name="inherentOptions">Inherent options, specified as name=value pairs, and separated by commas.</param>
        private static void ProcessInherentOptions(SessionInfo info, string inherentOptions)
        {
            var nameValuePairs = ParseNameValuePairs(inherentOptions);

            foreach (var name in nameValuePairs.Keys)
            {
                var val = nameValuePairs[name];

                ProcessInherentOption(info, name, val);
            }
        }

        private static void ProcessInherentOption(SessionInfo info, string name, string value)
        {
            switch (name.ToLower(CultureInfo.CurrentCulture))
            {
                case "cache":
                    info.InitOptions.CachingEnabled = ParseOptionBooleanValue(name, value);
                    break;

                case "interchangecheck":
                    info.InitOptions.InterchangeCheckingEnabled = ParseOptionBooleanValue(name, value);
                    break;

                case "queryinstrstatus":
                    info.InitOptions.QueryInstrumentStatusEnabled = ParseOptionBooleanValue(name, value);
                    break;

                case "rangecheck":
                    info.InitOptions.RangeCheckingEnabled = ParseOptionBooleanValue(name, value);
                    break;

                case "recordcoercions":
                    info.InitOptions.CoercionRecordingEnabled = ParseOptionBooleanValue(name, value);
                    break;

                case "simulate":
                    info.InitOptions.SimulationEnabled = ParseOptionBooleanValue(name, value);
                    break;

                default:
                    throw ErrorService.UnknownOption(name);
            }
        }

        private static void ProcessDriverSetup(Driver driver, SessionInfo info)
        {
            var nameValuePairs = ParseNameValuePairs(info.DriverSetupString);
            var driverSetupMap = new Dictionary<string, string>();

            foreach (var name in nameValuePairs.Keys)
            {
                var val = nameValuePairs[name];

                ProcessDriverSetupOption(driver, info, driverSetupMap, name, val);
            }

            info.DriverSetup = new ReadOnlyDictionary<string, string>(driverSetupMap, StringComparer.OrdinalIgnoreCase);
        }

        private static void ProcessDriverSetupOption(Driver driver, SessionInfo info, IDictionary<string, string> driverSetupMap, string name, string value)
        {
            var addOption = true;

            switch (name.ToLower(CultureInfo.CurrentCulture))
            {
                case "model":
                    {
                        // Don't overwrite the value loaded from the Configuration Initial Setting if the driver setup 
                        // supplied an empty value.
                        //
                        addOption = !String.IsNullOrEmpty(value?.Trim());

                        if (addOption)
                        {
                            info.InstrumentModel = value;
                        }

                        break;
                    }

                case "trace":
                    info.TraceEnabled = ParseOptionBooleanValue(name, value);
                    break;

                default:
                    driver.ProcessCustomDriverSetupOption(name, value);
                    break;
            }

            if (addOption)
            {
                driverSetupMap.Add(name.ToLower(CultureInfo.CurrentCulture), value);
            }
        }

        internal static bool ParseOptionBooleanValue(string name, string value)
        {
            // From IVI 3.2 - section 6.14 (Initialize):
            //
            //	- To set the attribute to True, use VI_TRUE, True, or 1.
            //	- To set the attribute to False, use VI_FALSE, False, or 0.
            //
            if (String.Equals(value, "True", StringComparison.OrdinalIgnoreCase) ||
                String.Equals(value, "VI_TRUE", StringComparison.OrdinalIgnoreCase) ||
                String.Equals(value, "1", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (String.Equals(value, "False", StringComparison.OrdinalIgnoreCase) ||
                String.Equals(value, "VI_FALSE", StringComparison.OrdinalIgnoreCase) ||
                String.Equals(value, "0", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            throw ErrorService.InvalidOptionValue(name, value);
        }

        private static Dictionary<string, string> ParseNameValuePairs(string source)
        {
            var pairsMap = new Dictionary<string, string>();

            var pairs = source.Split(',');

            foreach (var pair in pairs)
            {
                if (pair.Trim().Length > 0)
                {
                    var equalIndex = pair.IndexOf("=", StringComparison.OrdinalIgnoreCase);

                    if (equalIndex >= 0)
                    {
                        var name = pair.Substring(0, equalIndex).Trim();
                        var val = pair.Substring(equalIndex + 1).Trim();

                        pairsMap.Add(name, val);
                    }
                }
            }

            return pairsMap;
        }

        private static SoftwareModule FindSoftwareModule(ConfigStore store, string name)
        {
            SoftwareModule software = null;

            try
            {
                software = store.SoftwareModules[name];
            }
            catch (KeyNotFoundException)
            {
                // Do not propagate the config server exception if the item is not found.
                //
            }

            return software;
        }

        private static DataComponent FindDataComponent(DriverSession session, string name)
        {
            DataComponent component = null;

            try
            {
                component = session.DataComponents[name];
            }
            catch (KeyNotFoundException)
            {
                // Do not propagate the config server exception if the item is not found.
                //
            }

            return component;
        }

        private static DataComponent FindDataComponent(SoftwareModule software, string name)
        {
            DataComponent component = null;

            try
            {
                component = software.DataComponents[name];
            }
            catch (KeyNotFoundException)
            {
                // Do not propagate the config server exception if the item is not found.
                //
            }

            return component;
        }
    }
}
