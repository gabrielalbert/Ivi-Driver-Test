﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Reflection;

namespace MindWorks.Nimbus
{
    internal abstract class NimbusAttribute : Attribute
    {
        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal void Validate()
        {
            string message;
            string resolution;

            if (!this.TryValidate(this.GetType().Assembly, out message, out resolution))
            {
                if (resolution.Length > 0)
                {
                    throw new DriverAttributeValidationException<NimbusAttribute>(message + Environment.NewLine + resolution);
                }
                else
                {
                    throw new DriverAttributeValidationException<NimbusAttribute>(message);
                }
            }
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal virtual bool TryValidate(Assembly target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            return true;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal virtual bool TryValidate(Type target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            return true;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal virtual bool TryValidate(MethodInfo target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            return true;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal virtual bool TryValidate(PropertyInfo target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            return true;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal virtual bool TryValidate(EventInfo target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            return true;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal virtual bool TryValidate(FieldInfo target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            return true;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal virtual bool TryValidate(ParameterInfo target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            return true;
        }
    }
}
