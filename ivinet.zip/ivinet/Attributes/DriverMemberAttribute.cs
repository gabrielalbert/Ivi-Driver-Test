﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System.Diagnostics.CodeAnalysis;

namespace MindWorks.Nimbus
{
    internal abstract class DriverMemberAttribute : NimbusCodeWeaverAttribute
    {
        protected DriverMemberAttribute()
        {
            this.Lock = true;
        }

        /// <summary>
        /// Enables or disables code weaver handling of thread synchronization.  When not set, locking is enabled by 
        /// default.
        /// </summary>
        public bool Lock { get; set; }


        /// <summary>
        /// When locking is enabled, specifies the lock timeout in milliseconds.
        /// By default, the code weaver injects a call to <see cref="M:MindWorks.Nimbus.DriverNode.AcquireLock"/>, 
        /// which implies an infinite timeout. Setting this property causes the code weaver to inject a call to 
        /// <see cref="M:MindWorks.Nimbus.DriverNode.AcquireLock(Ivi.Driver.PrecisionTimeSpan)"/> using the specified 
        /// timeout value.
        /// </summary>
        public uint LockTimeoutMilliseconds { get; set; }

        /// <summary>
        /// When set to true, suppresses code weaver injection of a call to 
        /// <see cref="M:MindWorks.Nimbus.DriverNode.CheckDisposed"/>. By default, the value of this property is false.
        /// </summary>
        public bool SuppressObjectDisposedCheck { get; set; }

        /// <summary>
        /// When set to true, suppresses code weaver injection of a call to 
        /// <see cref="M:MindWorks.Nimbus.DriverNode.PollInstrumentErrors"/>. By default, the value of this property is 
        /// false.
        /// </summary>
        public bool SuppressPollInstrumentErrors { get; set; }
    }
}
