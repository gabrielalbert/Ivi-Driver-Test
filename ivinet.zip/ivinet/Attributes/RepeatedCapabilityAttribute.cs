﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.Driver;
using System;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Declares a parameter-style or selector-style repeated capability.  Note that this attribute is not used to 
    /// declare collection-style repeated capabilities. Collection-style repeated capabilities are declared on the 
    /// repeated capability classes themselves.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    internal sealed class RepeatedCapabilityAttribute : NimbusAttribute
    {
        /// <summary>
        /// Initializes a new instance of the RepeatedCapabilityAttribute class.  This attribute is used to declare 
        /// either a parameter-style of selector-style repeated capability.
        /// </summary>
        /// <param name="repeatedCapabilityName">The name of the repeated capability.</param>
        /// <param name="physicalNames">
        /// A comma-separated list of static physical names for this repeated capability.  The list may include ranges,
        /// such as "CH1, CH3, CH5-CH7". This string may be empty if the repeated capability contains only dynamic 
        /// instances and no static instances.  The items in the list must be unqualified physical names.  If the items
        /// include one or more qualified physical names, a runtime exception will be thrown.  Set the value of the 
        /// UseQualifiedNames property to control the format of physical names published in the IVI Configuration 
        /// Store.
        /// </param>
        /// <param name="style">
        /// Specifies whether the RepeatedCapability attribute declares a parameter-style repeated capability or a 
        /// selector-style repeated capability.
        /// </param>
        public RepeatedCapabilityAttribute(string repeatedCapabilityName, string physicalNames, RepeatedCapabilityStyle style)
        {
            this.Style = style;
            this.PhysicalNames = physicalNames;

            var parts = TextUtility.RemoveWhiteSpace(repeatedCapabilityName).Split(':');

            if (parts.Length > 1)
            {
                this.RepCapName = parts[parts.Length - 1];
                this.Parent = parts[parts.Length - 2];
            }
            else
            {
                this.RepCapName = parts[0];
            }
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal string RepCapName { get; private set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal RepeatedCapabilityStyle Style { get; private set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal string PhysicalNames { get; private set; }

        internal string Parent { get; private set; }

        /// <summary>
        /// Gets or sets a value that determines whether the physical names will be stored in the collection as
        /// qualified physical names or unqualified physical names. This property also controls the format of 
        /// physical names registered in the IVI Configuration Store by the driver installer.  Typically, this 
        /// property is set to false.  This property only needs to be set to true if a physical name associated with
        /// this repeated capability is also used in another repeated capability.
        /// </summary>
        public bool UseQualifiedNames { get; set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal override bool TryValidate(Type target, out string message, out string resolution)
        {
            message = resolution = String.Empty;

            if (!base.TryValidate(target, out message, out resolution))
            {
                return false;
            }

            if (String.IsNullOrEmpty(this.RepCapName))
            {
                message = NclStrings.RepeatedCapabilityAttributeCannotHaveEmptyRepCapName(target.Name);
                return false;
            }

            RepCapSelector selector;

            try
            {
                selector = RepCapSelector.Parse(this.PhysicalNames);
            }
            catch (SelectorFormatException)
            {
                message = NclStrings.SyntaxErrorInPhysicalNamesListInRepeatedCapabilityAttribute(this.RepCapName, target.Name);
                return false;
            }
            catch (SelectorRangeException)
            {
                message = NclStrings.InvalidRangeInRepeatedCapabilityAttribute(this.RepCapName, target.Name);
                return false;
            }

            if (selector.IsEmpty)
            {
                // Verify that the target type has overridden DriverNode.GetDynamicRepCapNames.
                //
                if (!DriverNode.TypeOverridesGetDynamicRepCapNames(target))
                {
                    message = NclStrings.EmptyPhysicalNamesListInRepeatedCapabilityAttribute(this.RepCapName, target.Name);
                    return false;
                }
            }

            var haveParent = !String.IsNullOrEmpty(this.Parent);

            if (this.Style == RepeatedCapabilityStyle.Selector)
            {
                if (haveParent)
                {
                    message = NclStrings.CannotSpecifyParentOnSelectorStyleRepeatedCapabilityAttribute(target.Name, this.RepCapName, this.Parent);
                    return false;
                }
            }

            // If the target type is a derivative of RepCap (as opposed to Driver), then we need to verify that the
            // parent relationship is (1) specified and (2) valid.
            //
            if (typeof(RepCap).IsAssignableFrom(target))
            {
                var repcapNameForTargetType = target.Name.Substring(this.GetDriverBaseName().Length);

                if (!haveParent)
                {
                    message = NclStrings.NestedRepeatedCapabilitiesMustHaveParentMessage(target.Name, this.RepCapName);
                    resolution = NclStrings.NestedRepeatedCapabilitiesMustHaveParentResolution(repcapNameForTargetType, this.RepCapName);
                    return false;
                }

                // Verify that either of the following two conditions is true:
                //
                // (1) This Parent for this RepeatedCapability attribute corresponds to the target type to which this 
                //     attribute is applied. or
                // (2) This Parent for this RepeatedCapability attribute is one of the *other* repeated capabilities 
                //     specified for the type to which this RepeatedCapability is applied.

                // (1)
                //
                if (this.Parent == repcapNameForTargetType)
                {
                    return true;
                }

                // (2)
                //
                if (this.HasRepeatedCapability(target, this.Parent))
                {
                    return true;
                }

                // If we get here, neither of the above conditions was true, so we have a problem.
                //
                message = NclStrings.NestedRepeatedCapabilitiesInvalidParentMessage(target.Name, this.RepCapName, this.Parent);
                resolution = NclStrings.NestedRepeatedCapabilitiesInvalidParentResolution;
                return false;
            }

            return true;
        }

        private bool HasRepeatedCapability(Type target, string repcapName)
        {
            // Fetch all of the RepeatedCapability attributes applied to the given target type.
            //
            var repcapAttrs = Utility.Cast<RepeatedCapabilityAttribute>(target.GetCustomAttributes(typeof(RepeatedCapabilityAttribute), false));

            // Exclude this attribute.
            //
            repcapAttrs = Utility.Where(repcapAttrs, attr => attr.RepCapName != this.RepCapName);

            // Return true if any of the remaining attributes has the given name.
            //
            return Utility.Any(repcapAttrs, attr => attr.RepCapName == repcapName);
        }

        private string GetDriverBaseName()
        {
            // We need to locate the driver class within this assembly.  Start by locating the set of types that derive
            // directly from Driver.
            //
            var driverClasses = Utility.Where(this.GetType().Assembly.GetTypes(),
                                              t => t.IsClass && !t.IsAbstract && Object.ReferenceEquals(t.BaseType, typeof(Driver)));

            // There should only be one of these, so grab the first (or null if the above failed).
            //
            var driverClass = Utility.FirstOrDefault(driverClasses);

            if (driverClass == null)
            {
                return String.Empty;
            }

            return driverClass.Name;
        }
    }


    /// <summary>
    /// Specifies whether the RepeatedCapability attribute declares a selector-style repeated capability or a 
    /// parameter-style repeated capability. Note that this is not used for collection-style repeated capabilities 
    /// since those are declared on the repeated capability classes themselves.	
    /// </summary>
    internal enum RepeatedCapabilityStyle
    {
        /// <summary>
        /// Specifies a parameter-style repeated capability declaration.
        /// </summary>
        Parameter,

        /// <summary>
        /// Specifies a selector-style repeated capability declaration.
        /// </summary>
        Selector
    }
}
