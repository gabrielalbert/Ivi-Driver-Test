﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Specifies one or more instrument commands to associate with an enum member when the enum is used as a parameter
    /// to the Printf I/O method. The Scanf I/O method also uses this attribute to map instrument response strings to 
    /// enum members. This attribute should only be used on instrument-specific enums defined in the driver assembly.
    /// <para>
    /// This attribute can only be applied to an enum. Use the <see cref="EnumCommandAttribute"/> class for enums 
    /// defined in the current assembly, such as instrument-specific enums.
    /// </para>
    /// </summary>
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = true)]
    internal sealed class CommandAttribute : ModelSpecificNimbusAttribute
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CommandAttribute"/> class.
        /// </summary>
        /// <param name="command">Instrument command.</param>
        /// <param name="models">Instrument model(s).</param>
		internal CommandAttribute(string command, params string[] models)
            : base(models)
        {
            this.Command = command;
            this.AdditionalResponses = String.Empty;
        }

        /// <summary>
        /// Instrument command.
        /// </summary>
		public string Command { get; private set; }

        /// <summary>
        /// Comma-separated list of additional responses which can be returned from the instrument. Use this if the 
        /// instrument may return a response that is different than the one specified in the Command property.
        /// </summary>
        public string AdditionalResponses { get; set; }
    }
}
