﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Reflection;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
    internal sealed class SupportedInstrumentClassAttribute : NimbusAttribute
    {
        internal SupportedInstrumentClassAttribute(string instrumentClassName, int majorVersion, int minorVersion, string capabilityGroups)
        {
            this.InstrumentClassName = instrumentClassName.Trim();
            this.MajorVersion = majorVersion;
            this.MinorVersion = minorVersion;
            this.CapabilityGroups = new List<string>(TextUtility.RemoveWhiteSpace(capabilityGroups).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
        }

        private bool Validated { get; set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal string InstrumentClassName { get; private set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal int MajorVersion { get; private set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal int MinorVersion { get; private set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal IList<string> CapabilityGroups { get; private set; }

        /// <summary>
        /// When a driver supports more than one instrument class, this attribute indicates if the current instrument 
        /// class should be used as the primary instrument class.  The primary instrument class determines which 
        /// SpecificationMajorVersion and SpecificationMinorVersion values are returned by the implementation of 
        /// IIviDriverIdentity. The value of this property is ignored if the driver supports one instrument class.
        /// </summary>
        public bool IsPrimaryInstrumentClass { get; set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal override bool TryValidate(Assembly target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            if (this.Validated)
            {
                return true;
            }

            if (!base.TryValidate(target, out message, out resolution))
            {
                return false;
            }

            // In order to validate this attribute, we must validate all SupportedInstrumentClass attributes together
            //
            var instrClasses = new Dictionary<string, string>();
            var primaryClassFound = false;
            var attrs = (SupportedInstrumentClassAttribute[])target.GetCustomAttributes(typeof(SupportedInstrumentClassAttribute), false);

            foreach (var attr in attrs)
            {
                if (!attr.TryValidateSelf(instrClasses, ref primaryClassFound, out message))
                {
                    return false;
                }
            }

            if (instrClasses.Count > 1 && !primaryClassFound)
            {
                message = NclStrings.MustSpecifyPrimaryInstrumentClass;
                return false;
            }

            this.Validated = true;

            return true;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        private bool TryValidateSelf(Dictionary<string, string> instrClasses, ref bool primaryClassFound, out string message)
        {
            message = String.Empty;

            if (this.IsPrimaryInstrumentClass)
            {
                if (primaryClassFound)
                {
                    message = NclStrings.OnlyOneSupportedInstrumentClassAttributeCanSpecifyPrimary;
                    return false;
                }

                primaryClassFound = true;
            }

            if (instrClasses.ContainsKey(this.InstrumentClassName))
            {
                message = NclStrings.DuplicateInstrumentClassNames;
                return false;
            }

            instrClasses.Add(this.InstrumentClassName, this.InstrumentClassName);

            return true;
        }
    }
}
