﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;

namespace MindWorks.Nimbus
{
    /// <summary>
	/// Indicates whether or not the instrument is SCPI compliant.  When set to True, the automatic command formatting 
    /// code will automatically send the SCPI short form of instrument commands.
	/// <para>
	/// This attribute can only be applied at the assembly level.
	/// </para>
    /// </summary>
	[AttributeUsage(AttributeTargets.Assembly)]
    internal sealed class SCPICompliantAttribute : NimbusAttribute
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SCPICompliantAttribute"/> class.
        /// </summary>
		/// <param name="compliant">
		/// True indicates the instrument is SCPI compliant.  Automatic command formatting will use the SCPI short form
        /// for all instrument commands.  When False, no instrument command simplification is performed, and the full 
        /// text of all instrument commands is sent to the instrument.
		/// </param>
		internal SCPICompliantAttribute(bool compliant)
        {
            this.Compliant = compliant;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal bool Compliant { get; set; }
    }
}
