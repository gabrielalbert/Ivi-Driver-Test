﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Reflection;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
    internal sealed class RangeCheckStringAttribute : ModelSpecificNimbusCodeWeaverAttribute
    {
        internal RangeCheckStringAttribute(string allowedValues, params string[] models)
            : base(models)
        {
            var listOfAllowedValues = new List<string>();

            foreach (var val in TextUtility.RemoveWhiteSpace(allowedValues).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                listOfAllowedValues.Add(val);
            }

            this.AllowedValues = listOfAllowedValues;
        }

        public IEnumerable<string> AllowedValues { get; private set; }

        internal override bool TryValidate(PropertyInfo target, out string message, out string resolution)
        {
            message = resolution = String.Empty;

            const string AttributeShortName = "RangeCheckString";

            if (Utility.Count(this.AllowedValues) == 0)
            {
                message = NclStrings.RangeCheckEmptyAllowedValuesMessage(AttributeShortName, target.DeclaringType.Name, target.Name);
                resolution = NclStrings.RangeCheckEmptyAllowedValuesResolution;
                return false;
            }

            if (Utility.ContainsDuplicates(this.AllowedValues))
            {
                message = NclStrings.RangeCheckDuplicateAllowedValuesMessage(AttributeShortName, target.DeclaringType.Name, target.Name);
                resolution = NclStrings.RangeCheckDuplicateAllowedValuesResolution;
                return false;
            }

            // Note: Validation of the model or family specified (if any) is performed in the static analysis component.
            //
            return true;
        }
    }
}
