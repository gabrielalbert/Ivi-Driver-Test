﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Reflection;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
    internal sealed class DriverSessionAttribute : NimbusAttribute
    {
        internal DriverSessionAttribute(string sessionName)
        {
            this.SessionName = sessionName;
        }

        private bool Validated { get; set; }

        internal string SessionName { get; private set; }

        public string HardwareAsset { get; set; }

        public string DriverSetup { get; set; }

        public bool Cache { get; set; }

        public bool RangeCheck { get; set; }

        public bool RecordCoercions { get; set; }

        public bool InterchangeCheck { get; set; }

        public bool QueryInstrumentStatus { get; set; }

        public bool Simulate { get; set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal override bool TryValidate(Assembly target, out string message, out string resolution)
        {
            message = String.Empty;
            resolution = String.Empty;

            if (this.Validated)
            {
                return true;
            }

            if (!base.TryValidate(target, out message, out resolution))
            {
                return false;
            }

            this.Validated = true;

            // Locate the DriverCapabilities attribute applied to this driver assembly.
            //
            var driverCapabilityAttributes = (DriverCapabilitiesAttribute[])target.GetCustomAttributes(typeof(DriverCapabilitiesAttribute), false);

            foreach (var attr in driverCapabilityAttributes)
            {
                // Check to see if the driver advertises that it's capable of doing interchange checking.
                //
                var driverCapabilityInterchangeCheck = (attr.DriverCapabilities & Capabilities.InterchangeCheck) == Capabilities.InterchangeCheck;

                // If the driver is not capable of doing interchange checking, it would be an error for
                // a DriverSession attribute to enable interchange checking.  Make sure this is the case.
                //
                if (!driverCapabilityInterchangeCheck && this.InterchangeCheck)
                {
                    message = NclStrings.DriverSessionAndCapabilitiesAttributesSpecifyInconsistentInterchangeChecking(this.InterchangeCheck.ToString(), driverCapabilityInterchangeCheck ? "set" : "not set");
                    resolution = NclStrings.DriverSessionAndCapabilitiesAttributesRequireConsistentInterchangeChecking;

                    this.Validated = false;
                }
            }

            return this.Validated;
        }
    }
}
