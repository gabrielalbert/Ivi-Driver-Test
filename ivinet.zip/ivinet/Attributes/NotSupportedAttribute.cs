﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Method | AttributeTargets.Event)]
    internal sealed class NotSupportedAttribute : NimbusCodeWeaverAttribute
    {
        internal NotSupportedAttribute(params string[] unsupportedModelsAndFamilies)
        {
            this.UnsupportedModelsAndFamilies = new List<string>();

            foreach (var modelOrFamily in unsupportedModelsAndFamilies)
            {
                this.UnsupportedModelsAndFamilies.Add(modelOrFamily.Trim());
            }
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal IList<string> UnsupportedModelsAndFamilies { get; private set; }
    }
}
