﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = false)]
    internal sealed class DriverCapabilitiesAttribute : NimbusAttribute
    {
        internal DriverCapabilitiesAttribute(Capabilities capabilities)
        {
            this.DriverCapabilities = capabilities;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal Capabilities DriverCapabilities { get; private set; }
    }

    [Flags]
    internal enum Capabilities
    {
        None = 0,
        IdQuery = 1,
        InterchangeCheck = 2,
        Reset = 4,
        RevisionQuery = 8,
        SelfTest = 16,
        AllExceptInterchangeCheck = Reset | SelfTest | RevisionQuery | IdQuery,
        All = AllExceptInterchangeCheck | InterchangeCheck
    }
}
