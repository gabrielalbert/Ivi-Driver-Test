﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Reflection;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
    internal sealed class SimulationAttribute : ModelSpecificNimbusCodeWeaverAttribute
    {
        internal SimulationAttribute(SimulationMode mode, params string[] models)
            : base(models)
        {
            this.Mode = mode;
        }

        public SimulationMode Mode { get; private set; }

        public string Default { get; set; }

        internal override bool TryValidate(PropertyInfo target, out string message, out string resolution)
        {
            message = resolution = String.Empty;

            if (this.Mode != SimulationMode.Manual && this.Default == null)
            {
                message = NclStrings.SimulationDefaultValueShouldBeSpecified;
                return false;
            }

            return true;
        }
    }

    /// <summary>
    /// Specifies how simulation will behave for the associated property.
    /// </summary>
    internal enum SimulationMode
    {
        /// <summary>
        /// Simulation is implemented manually in the body of the driver property.
        /// </summary>
        Manual,

        /// <summary>
        /// The property getter returns a constant value in simulation mode.  The constant value is specified with the 
        /// Default parameter. The property setter does nothing in this mode.
        /// </summary>
        ConstantValue,

        /// <summary>
        /// The property getter returns the last value that was set using the property setter.  The Default parameter 
        /// specifies the value that will be returned if the getter is called before the setter is called the first 
        /// time.
        /// </summary>
        LastValue
    }
}
