﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// This class is for internal use of the Nimbus Class Library and is not intended to be used directly in driver 
    /// developer code.
    /// </summary>
    [AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Method)]
    internal sealed class NimbusCompilerModifiedAttribute : Attribute
    {
        /// <summary>
        /// This constructor is used when this attribute is applied to any modified type member.
        /// </summary>
        internal NimbusCompilerModifiedAttribute()
        {
            this.PostCompilerVersion = new Version();
        }

        /// <summary>
        /// This constructor is only used when this attribute is applied to an assembly.
        /// </summary>
        internal NimbusCompilerModifiedAttribute(string postCompilerVersion)
        {
            this.PostCompilerVersion = new Version(postCompilerVersion);
        }

        /// <summary>
        /// The version of the post compiler that modified the assembly.  Will be
        /// empty when applied to type members.
        /// </summary>
        internal Version PostCompilerVersion { get; set; }
    }
}
