﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Reflection;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Indicates which kind of coercion is performed on a numeric value.
    /// </summary>
    public enum CoercionStyle
    {
        /// <summary>
        /// No coercion is performed.  The value is sent to the instrument unmodified.
        /// </summary>
        None,

        /// <summary>
        /// The value is coereced to the next higher value supported by the instrumet.
        /// </summary>
        Up,

        /// <summary>
        /// The value is coereced to the next lower value supported by the instrumet.
        /// </summary>
        Down,
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
    internal sealed class RangeCheckDiscreteAttribute : ModelSpecificNimbusCodeWeaverAttribute
    {
        internal RangeCheckDiscreteAttribute(string allowedValues, params string[] models)
            : base(models)
        {
            this.CoercionStyle = CoercionStyle.None;

            var listOfAllowedValues = new List<double>();

            foreach (var stringValue in TextUtility.RemoveWhiteSpace(allowedValues).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                double doubleValue;

                if (Double.TryParse(stringValue, out doubleValue))
                {
                    listOfAllowedValues.Add(doubleValue);
                }
                else
                {
                    listOfAllowedValues.Add(Double.NaN);
                }
            }

            this.AllowedValues = listOfAllowedValues;
        }

        public IEnumerable<double> AllowedValues { get; private set; }

        public CoercionStyle CoercionStyle { get; set; }

        internal override bool TryValidate(PropertyInfo target, out string message, out string resolution)
        {
            message = resolution = String.Empty;

            const string AttributeShortName = "RangeCheckDiscrete";

            if (Utility.Count(this.AllowedValues) == 0)
            {
                message = NclStrings.RangeCheckEmptyAllowedValuesMessage(AttributeShortName, target.DeclaringType.Name, target.Name);
                resolution = NclStrings.RangeCheckEmptyAllowedValuesResolution;
                return false;
            }

            if (Utility.ContainsDuplicates(this.AllowedValues))
            {
                message = NclStrings.RangeCheckDuplicateAllowedValuesMessage(AttributeShortName, target.DeclaringType.Name, target.Name);
                resolution = NclStrings.RangeCheckDuplicateAllowedValuesResolution;
                return false;
            }

            if (Utility.Contains(this.AllowedValues, Double.NaN))
            {
                message = NclStrings.RangeCheckDiscreteNaNMessage(target.DeclaringType.Name, target.Name);
                resolution = NclStrings.RangeCheckDiscreteNaNResolution;
                return false;
            }

            // Note: Validation of the model or family specified (if any) is performed in the static analysis 
            // component.
            //
            return true;
        }
    }
}
