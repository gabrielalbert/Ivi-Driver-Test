﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Reflection;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
    internal sealed class RangeCheckMinMaxAttribute : ModelSpecificNimbusCodeWeaverAttribute
    {
        internal RangeCheckMinMaxAttribute(double min, double max, params string[] models)
            : base(models)
        {
            this.Min = min;
            this.Max = max;
        }

        public double Min { get; private set; }

        public double Max { get; private set; }

        public bool MinInclusive { get; set; }

        public bool MaxInclusive { get; set; }

        internal override bool TryValidate(PropertyInfo target, out string message, out string resolution)
        {
            message = resolution = String.Empty;

            if (this.Min >= this.Max)
            {
                message = NclStrings.RangeCheckMinNotLessThanMaxMessage(target.DeclaringType.Name, target.Name, this.Min, this.Max);
                resolution = NclStrings.RangeCheckMinNotLessThanMaxResolution;
                return false;
            }

            return true;
        }
    }
}
