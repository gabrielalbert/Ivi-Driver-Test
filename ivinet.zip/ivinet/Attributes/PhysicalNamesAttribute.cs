﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.Driver;
using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Specifies the physical names stored in the repeated capability collection class to which the attribute is 
    /// applied.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    internal sealed class PhysicalNamesAttribute : NimbusAttribute
    {
        /// <summary>
        /// Initializes a new instance of the PhysicalNamesAttribute class.
        /// </summary>
        /// <param name="physicalNames">
        /// A comma-separated list of static physical repeated capability names for this repeated capability.  The list
        /// may include ranges, such as "CH1, CH3, CH5-CH7". This string may be empty if the repeated capability 
        /// contains only dynamic instances and no static instances.  The items in the list must be unqualified 
        /// physical names.  If the items include one or more qualified physical names, a runtime exception will be 
        /// thrown.  Set the value of the UseQualifiedNames property to control the format of physical names stored in 
        /// the collection and published in the IVI Configuration Store.
        /// </param>
        public PhysicalNamesAttribute(string physicalNames)
        {
            this.PhysicalNames = physicalNames;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal string PhysicalNames { get; private set; }

        /// <summary>
        /// Gets or sets a value that determines whether the physical names will be stored in the collection as 
        /// qualified physical names or unqualified physical names. This property also controls the format of physical
        /// names registered in the IVI Configuration Store by the driver installer.  Typically, this property is set 
        /// to false.  This property only needs to be set to true if a physical name associated with this repeated 
        /// capability is also used in another repeated capability.
        /// </summary>
        public bool UseQualifiedNames { get; set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal RepCapSelector Validate(Type target)
        {
            RepCapSelector selector;
            string message;
            string resolution;

            if (!this.TryValidate(target, out selector, out message, out resolution))
            {
                throw new DriverAttributeValidationException<PhysicalNamesAttribute>("class " + target.Name, message);
            }

            return selector;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal bool TryValidate(Type target, out RepCapSelector selector, out string message, out string resolution)
        {
            message = String.Empty;
            selector = null;

            if (!base.TryValidate(target, out message, out resolution))
            {
                return false;
            }

            if (!typeof(RepCap).IsAssignableFrom(target))
            {
                message = NclStrings.PhysicalNamesAttributeAppliedToWrongClass(target.Name);
                return false;
            }

            try
            {
                selector = RepCapSelector.Parse(this.PhysicalNames);
            }
            catch (SelectorFormatException)
            {
                message = NclStrings.SyntaxErrorInPhysicalNamesAttribute(target.Name);
                return false;
            }
            catch (SelectorRangeException)
            {
                message = NclStrings.InvalidRangeInPhysicalNamesAttribute(target.Name);
                return false;
            }

            if (selector.IsEmpty)
            {
                // Verify that the corresponding repcap collection class has overridden 
                // DriverNode.GetDynamicRepCapNames.
                //
                var repCapCollType = Utility.FirstOrDefault(this.GetType().Assembly.GetTypes(),
                    t => t.BaseType != null &&
                    Object.Equals(t.BaseType.BaseType, typeof(RepCapCollection)) &&
                    t.BaseType.IsGenericType &&
                    Object.Equals(t.BaseType.GetGenericArguments()[0], target));

                // We should always find the associated repcap collection class.
                //
                Debug.Assert(repCapCollType != null);

                if (repCapCollType != null)
                {
                    if (!DriverNode.TypeOverridesGetDynamicRepCapNames(repCapCollType))
                    {
                        message = NclStrings.EmptyPhysicalNamesListInPhysicalNamesAttribute(target.Name, repCapCollType.Name);
                        return false;
                    }
                }
            }

            if (selector.IsNested)
            {
                // Make sure all physical names have a depth of two.
                //
                var myPhysicalNames = Utility.ToArray(RepCapSelector.ExpandToPhysicalNames(selector, null));

                foreach (var physicalName in myPhysicalNames)
                {
                    var parts = physicalName.Split(new[] { ':' }, StringSplitOptions.RemoveEmptyEntries);

                    if ((parts == null) || (parts.Length != 2))
                    {
                        message = NclStrings.NestedPhysicalNamesMustHaveDepthTwo(target.Name, parts == null ? 0 : parts.Length);
                        return false;
                    }
                }

                // If we get here, we know that the target type is a child of another collection-style repcap.  We now 
                // need to locate the parent class/type that corresponds to the parent repcap name. Start by locating 
                // the set of types within this assembly that directly derive from the RepCap base class.
                //
                var repCapTypes = Utility.Where(this.GetType().Assembly.GetTypes(), t => Object.ReferenceEquals(t.BaseType, typeof(RepCap)));
                Type parentRepCapType = null;

                foreach (Type t in repCapTypes)
                {
                    // Check to see if this type has an interface reference property of type 
                    // IIviRepeatedCapabilityCollection<T>, where T is an interface that's implemented by the target 
                    // type.
                    //
                    if (IsParentRepeatedCapabilityOf(t, target))
                    {
                        // We've located the type object that corresponds to the parent repcap name for this repcap.
                        //
                        parentRepCapType = t;
                        break;
                    }
                }

                if (parentRepCapType != null)
                {
                    // We've located the type of the parent repcap.  Now look at the PhysicalNames attributes applied
                    // to that type, and verify that each of this repcap's physical names refer to one of the parent 
                    // repcap's physical names.
                    //
                    var parentRepCapPhysicalNamesAttributes = parentRepCapType.GetCustomAttributes(typeof(PhysicalNamesAttribute), false);

                    foreach (PhysicalNamesAttribute physicalNameAttr in parentRepCapPhysicalNamesAttributes)
                    {
                        var parentRepCapSelector = RepCapSelector.Parse(physicalNameAttr.PhysicalNames);
                        var parentPhysicalNames = Utility.ToArray(RepCapSelector.ExpandToPhysicalNames(parentRepCapSelector, null));

                        foreach (var physicalName in myPhysicalNames)
                        {
                            // Verify that the parent portion of the physical name associated with this repcap is found
                            // in the set of physical names associated with the parent repcap class we located above. If 
                            // not, then we have a child repcap that specifies an invalid physical name for its parent.
                            //
                            var parts = physicalName.Split(new[] { ':' }, StringSplitOptions.RemoveEmptyEntries);

                            if (!Utility.Contains(parentPhysicalNames, parts[0]))
                            {
                                message = NclStrings.InvalidParentPhysicalNameSpecifiedOnNestedRepCap(target.Name, parts[0], parentRepCapType.Name);
                                return false;
                            }
                        }
                    }
                }
                else
                {
                    message = NclStrings.NestedPhysicalNameSpecifiedOnNonNestedRepCap(target.Name);
                    return false;
                }
            }

            return true;
        }

        private static bool IsParentRepeatedCapabilityOf(Type t, Type repCapType)
        {
            // Fetch the set of properties that (a) are get-only and (b) return an interface.
            //
            var interfaceReferenceProperties = Utility.Where(t.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly),
                                                             pi => pi.CanRead && !pi.CanWrite && pi.PropertyType.IsInterface);

            foreach (var property in interfaceReferenceProperties)
            {
                // Check to see if this interface reference property is specifically an IIviRepeatedCapabilityCollection<T>.
                // If it is, this function will return the typeof(T).
                //
                Type repCapCollBaseIntfType = DriverNode.GetRepCapCollectionInterfaceImplementedByType(property.PropertyType);

                if (repCapCollBaseIntfType == null)
                {
                    // This property points to an interface that is not a repcap collection interface.
                    //
                    continue;
                }

                // We found a repcap collection interface property (IIviRepeatedCapabilityCollection<T>).  If the given
                // repcap type implements T, then we've located the parent repcap class for the given repcap.
                //
                var repCapIntfType = repCapCollBaseIntfType.GetGenericArguments()[0];

                if (Utility.TypeImplementsInterface(repCapType, repCapIntfType))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal override bool TryValidate(Type target, out string message, out string resolution)
        {
            message = resolution = String.Empty;

            var valid = base.TryValidate(target, out message, out resolution);

            if (valid)
            {
                RepCapSelector selector;
                valid = this.TryValidate(target, out selector, out message, out resolution);
            }

            return valid;
        }
    }
}
