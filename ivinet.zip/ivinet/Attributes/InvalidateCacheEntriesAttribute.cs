﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Property, AllowMultiple = true)]
    internal sealed class InvalidateCacheEntriesAttribute : NimbusCodeWeaverAttribute
    {
        internal InvalidateCacheEntriesAttribute(params string[] keys)
        {
            this.Keys = keys;
        }

        internal IList<string> Keys { get; private set; }

        internal override bool TryValidate(MethodInfo target, out string message, out string resolution)
        {
            var validated = base.TryValidate(target, out message, out resolution);

            if (validated)
            {
                foreach (var key in this.Keys)
                {
                    if (!TryValidateCacheKey(key, out message))
                    {
                        return false;
                    }
                }
            }

            return validated;
        }

        internal override bool TryValidate(PropertyInfo target, out string message, out string resolution)
        {
            var validated = base.TryValidate(target, out message, out resolution);

            if (validated)
            {
                foreach (var key in this.Keys)
                {
                    if (!TryValidateCacheKey(key, out message))
                    {
                        return false;
                    }
                }
            }

            return validated;
        }

        internal static bool TryValidateCacheKey(string cacheKey, out string error)
        {
            error = String.Empty;
            cacheKey = TextUtility.RemoveWhiteSpace(cacheKey);

            // Validate the syntax of the cache key as a whole
            //
            var match = CacheKeyParser.Match(cacheKey);

            if (!match.Success)
            {
                error = NclStrings.SyntaxErrorInCacheKey;
                return false;
            }

            // Validate each of the repcap selectors
            //
            foreach (Capture selectorCapture in match.Groups["selector"].Captures)
            {
                if (selectorCapture.Value == "*")
                {
                    continue;
                }

                RepCapSelector selector;

                if (!RepCapSelector.TryParse(selectorCapture.Value, out selector) || selector.IsNested)
                {
                    error = NclStrings.SyntaxErrorInRepCapSelector(selectorCapture.Value);
                    return false;
                }
            }

            return true;
        }

        // There are 3 kinds of cache keys that may be supplied
        //
        //	1) Parent repcap collection property with the interface and property name
        //		- Ex: "Traces[TRACE1,TRACE2,TRACE3].IAcme4300Trace.Bandwidth"
        //		- Multiple parent repcaps may be specified, as in the following
        //			- Ex: "Traces[TRACE1].Channels[CH2].IAcme4300Trace.Frequency"
        //		- Physical name ranges are supported, as is the wildcard character (*)
        //			- Ex: "Traces[*].Channels[CH1,CH4,CH5-CH9].IAcme4300Trace.Frequency"
        //
        //	2) Interface and property name only
        //		- Ex: "IAcme4300.Bandidth"
        //
        //	3) Property name only
        //		- Ex: "Bandwidth"
        //
        internal static readonly Regex CacheKeyParser = new Regex(
            @"
			^(

			(			
				(
					(?<repCapCollProp> 
						[a-zA-Z_]+\w*) 
						\[ 
							(?<selector> 
								\* | [\w!,-]+) 
						\] 
						\. 
				)*

				(?= [a-zA-Z_]+ \w* \.)
			)?

			(
				(?<interface> 
					[a-zA-Z_]+ \w*)
				\. 
			)? 

			(?<property> 
				[a-zA-Z_]+ \w*)
			
			)$
			", RegexOptions.IgnorePatternWhitespace | RegexOptions.ExplicitCapture);
    }
}
