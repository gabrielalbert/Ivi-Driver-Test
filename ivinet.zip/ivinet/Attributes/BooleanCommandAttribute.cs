﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;

namespace MindWorks.Nimbus
{
    /// <summary>
	/// Specifies one or more instrument commands to associate with a boolean parameter passed to the Printf I/O method.
	/// The Scanf I/O method also uses this attribute to map instrument response strings to boolean output parameters.
	/// <para>
	/// This attribute can only be applied at the assembly level.
	/// </para>
    /// </summary>
	[AttributeUsage(AttributeTargets.Assembly)]
    internal sealed class BooleanCommandAttribute : NimbusAttribute
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BooleanCommandAttribute"/> class.
        /// </summary>
		/// <param name="trueCommands">
		/// Comma-separated list of instrument commands that should map to True when read from the device.  The first value 
        /// in the list will be used for sending boolean True values to the device.
		/// </param>
		/// <param name="falseCommands">
		/// Comma-separated list of instrument commands that should map to False when read from the device.  The first value 
        /// in the list will be used for sending boolean False values to the device.
		/// </param>
		internal BooleanCommandAttribute(string trueCommands, string falseCommands)
        {
            this.TrueCommands = new List<string>();

            foreach (var command in trueCommands.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                this.TrueCommands.Add(command.Trim());
            }

            this.FalseCommands = new List<string>();

            foreach (var command in falseCommands.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                this.FalseCommands.Add(command.Trim());
            }
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
		internal IList<string> TrueCommands { get; set; }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal IList<string> FalseCommands { get; set; }

        /// <summary>
        /// Gets or sets a value that controls whether the Scanf I/O method should ignore casing when mapping instrument 
        /// response strings to boolean parameters. By default, this property is false, so the response mappings are 
        /// case-sensitive.
        /// </summary>
        public bool IgnoreCase { get; set; }
    }
}
