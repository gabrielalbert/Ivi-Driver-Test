﻿using System;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Assembly)]
    internal sealed class DriverDescriptionAttribute : NimbusAttribute
    {
        internal DriverDescriptionAttribute(String description)
        {
            this.Description = description.Trim();
        }

        public String Description { get; set; }
    }
}
