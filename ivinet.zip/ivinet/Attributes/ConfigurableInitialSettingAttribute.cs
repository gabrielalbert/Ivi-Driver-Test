﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Text;

namespace MindWorks.Nimbus
{
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
    internal sealed class ConfigurableInitialSettingAttribute : NimbusAttribute
    {
        internal ConfigurableInitialSettingAttribute(string keyName, object value, UsedInSession usedInSession, string description)
        {
            this.KeyName = keyName;
            this.Value = value;
            this.UsedInSession = usedInSession;
            this.Description = description;
            this.HelpFilePath = String.Empty;
        }

        internal string KeyName { get; private set; }

        internal object Value { get; private set; }

        internal UsedInSession UsedInSession { get; private set; }

        internal string HelpFilePath { get; private set; }

        internal int HelpContextId { get; private set; }

        internal string Description { get; private set; }

        internal override bool TryValidate(System.Reflection.Assembly target, out string message, out string resolution)
        {
            message = resolution = String.Empty;

            var valid = base.TryValidate(target, out message, out resolution);

            // Verify that the supplied key is not null or empty.
            //
            valid = !String.IsNullOrEmpty(this.KeyName);

            if (!valid)
            {
                message = NclStrings.ConfigurableInitialSettingAttributeKeyNameEmptyMessage;
                resolution = NclStrings.ConfigurableInitialSettingAttributeKeyNameEmptyResolution;
            }

            // Verify that the type of the value specified for this setting is supported and, in the case of an 
            // unsigned 32-bit value, that the actual value doesn't exceed the maximum value for a signed 32-bit 
            // integer, as required by the config store.
            //
            if (valid)
            {
                if (this.Value is UInt32)
                {
                    // Verify that the value of the unsigned integer specified does not exceed the maximum value 
                    // support for signed integers (as required by the IVI config store spec).
                    //
                    var value = (uint)this.Value;
                    var maxValue = (uint)Int32.MaxValue;

                    valid = value <= maxValue;

                    if (!valid)
                    {
                        message = NclStrings.ConfigurableInitialSettingAttributeValueOverflowMessage(target.GetName().Name, value, maxValue);

                        resolution = NclStrings.ConfigurableInitialSettingAttributeValueOverflowResolution(maxValue);
                    }
                }
                else
                {
                    // Fetch the CLR type of the value provided via the attribute.
                    //
                    var valueType = this.Value.GetType();

                    // Only the following sets of CLR types are supported within the IVI config store for configurable 
                    // initial settings.
                    //
                    var supportedTypes = new Type[]
                    {
                        typeof(sbyte), typeof(byte),
                        typeof(short), typeof(ushort),
                        typeof(int), typeof(uint),
                        typeof(float), typeof(double),
                        typeof(bool),
                        typeof(string)
                    };

                    // Validate that the actual type of the provided value is one of the above.
                    //
                    valid = Array.Find(supportedTypes, st => Object.ReferenceEquals(st, valueType)) != null;

                    if (!valid)
                    {
                        message = NclStrings.ConfigurableInitialSettingAttributeValueTypeUnsupportedMessage(target.GetName().Name, valueType.Name);

                        resolution = NclStrings.ConfigurableInitialSettingAttributeValueTypeUnsupportedResolution(BuildTypeNameList(supportedTypes));
                    }
                }
            }

            // Cross-reference the entire set of ConfigurableInitialSetting attributes applied to this assembly,
            // verifying that none of them specify a duplicate key.
            //
            if (valid)
            {
                // Verify that none of the ConfigurableInitialSetting attributes applied to this assembly specify the 
                // same key name.
                //
                var cisAttributes = (ConfigurableInitialSettingAttribute[])target.GetCustomAttributes(typeof(ConfigurableInitialSettingAttribute), false);
                var keysSeen = new List<string>();

                foreach (var attr in cisAttributes)
                {
                    var keyName = attr.KeyName.Trim();
                    var lowerKeyName = keyName.ToLower();

                    valid = !keysSeen.Contains(lowerKeyName);

                    if (valid)
                    {
                        keysSeen.Add(lowerKeyName);
                    }
                    else
                    {
                        message = NclStrings.ConfigurableInitialSettingAttributeDuplicateKeyNameMessage(keyName);

                        resolution = NclStrings.ConfigurableInitialSettingAttributeDuplicateKeyNameResolution;
                        break;
                    }
                }
            }

            return valid;
        }

        private static string BuildTypeNameList(Type[] types)
        {
            var sb = new StringBuilder();

            for (int n = 0; n < types.Length; n++)
            {
                if (n > 0)
                {
                    if (n == (types.Length - 1))
                    {
                        sb.Append(" or ");
                    }
                    else
                    {
                        sb.Append(", ");
                    }
                }

                sb.Append(types[n].Name);
            }

            return sb.ToString();
        }
    }

    internal enum UsedInSession
    {
        Optional,
        Required
    }
}
