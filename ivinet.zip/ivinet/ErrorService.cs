///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.Driver;
using System;
using System.Globalization;
using System.Text;

namespace MindWorks.Nimbus
{
    internal static class ErrorService
    {
        internal static Exception ConfigurationServer(Exception innerException)
        {
            return new ConfigurationServerException(innerException);
        }

        internal static Exception ConfigurationStoreLoad(Exception innerException)
        {
            return new ConfigurationStoreLoadException(innerException);
        }

        internal static Exception DataArrayTooSmall(string measuredElements, string capacity)
        {
            return new DataArrayTooSmallException(measuredElements, capacity);
        }

        internal static Exception FileFormat(Uri uri)
        {
            return new FileFormatException(uri);
        }

        internal static Exception IdQuery()
        {
            return new IdQueryFailedException();
        }

        internal static Exception InstrumentStatus()
        {
            return new InstrumentStatusException();
        }

        internal static Exception InvalidOptionValue(string optionName, string optionValue)
        {
            return new InvalidOptionValueException(optionName, optionValue);
        }

        internal static Exception InvalidSpectrumDataType()
        {
            return new InvalidSpectrumDataTypeException();
        }

        internal static Exception InvalidSpectrumDataType(string type)
        {
            return new InvalidSpectrumDataTypeException(String.Empty, type);
        }

        internal static Exception InvalidWaveformDataType()
        {
            return new InvalidWaveformDataTypeException();
        }

        internal static Exception InvalidWaveformDataType(string type)
        {
            return new InvalidWaveformDataTypeException(String.Empty, type);
        }

        internal static Exception IO(Exception innerException)
        {
            return new IOException(innerException);
        }

        internal static Exception IOTimeout(string timeout)
        {
            return new IOTimeoutException(String.Empty, timeout);
        }

        internal static Exception MaxTimeExceeded(string timeout)
        {
            return new MaxTimeExceededException(String.Empty, timeout);
        }

        internal static Exception NotATime(string paramName)
        {
            return new NotATimeException(String.Empty, paramName);
        }

        internal static Exception ObjectDisposed(string objectName)
        {
            return new ObjectDisposedException(objectName);
        }

        internal static Exception OperationNotAvailableInSimulationMode(string operation)
        {
            return new InvalidOperationException(NclStrings.OperationNotAvailableInSimulationMode(operation));
        }

        internal static Exception OperationNotSupported(string typeName, string methodName)
        {
            return new OperationNotSupportedException(NclStrings.OperationNotSupported(typeName, methodName));
        }

        internal static Exception OperationNotSupportedForModel(string typeName, string methodName, string model)
        {
            return new OperationNotSupportedException(NclStrings.OperationNotSupportedForModel(typeName, methodName, model));
        }

        internal static Exception OperationPending()
        {
            return new OperationPendingException();
        }

        internal static Exception OptionMissing(string optionName)
        {
            return new OptionMissingException(String.Empty, optionName);
        }

        internal static Exception OptionStringFormat()
        {
            return new OptionStringFormatException();
        }

        internal static Exception OutOfRange(string parameterName, string parameterValue, string allowedRange)
        {
            return new OutOfRangeException(parameterName, parameterValue, allowedRange);
        }

        internal static Exception OutOfRange(string parameterName, string parameterValue, double min, double max, bool minInclusive, bool maxInclusive)
        {
            return new OutOfRangeException(parameterName, parameterValue, $"{min.ToString(CultureInfo.CurrentCulture)} {(minInclusive ? ">=" : ">")} {parameterName} {(maxInclusive ? "<=" : "<")} {max.ToString()}");
        }

        internal static Exception OutOfRange(string parameterName, string parameterValue, Array allowedValues)
        {
            var list = new StringBuilder();
            var firstItem = true;

            foreach (var allowedValue in allowedValues)
            {
                if (firstItem)
                {
                    firstItem = false;
                }
                else
                {
                    list.Append(", ");
                }

                list.Append(allowedValue.ToString());
            }

            return new OutOfRangeException(parameterName, parameterValue, list.ToString());
        }

        internal static Exception ResetFailed(Exception innerException)
        {
            return new ResetFailedException(message: String.Empty, innerException);
        }

        internal static Exception ResetNotSupported()
        {
            return new ResetNotSupportedException();
        }

        internal static Exception SelectorFormat(string selector)
        {
            return new SelectorFormatException(repeatedCapabilityName: String.Empty, selector);
        }

        internal static Exception SelectorHierarchy(string selector)
        {
            return new SelectorHierarchyException(String.Empty, selector);
        }

        internal static Exception SelectorName(string repeatedCapabilityName, string selector)
        {
            return new SelectorNameException(repeatedCapabilityName, selector);
        }

        internal static Exception SelectorNameRequired(string repeatedCapabilityName)
        {
            return new SelectorNameRequiredException(NclStrings.SelectorNameRequired, repeatedCapabilityName);
        }

        internal static Exception SelectorRange(string selector)
        {
            return new SelectorRangeException(repeatedCapabilityName: String.Empty, selector);
        }

        internal static Exception SimulationState()
        {
            return new SimulationStateException();
        }

        internal static Exception SoftwareModuleNotFound(string driverSession, string softwareModule)
        {
            return new SoftwareModuleNotFoundException(driverSession, softwareModule);
        }

        internal static Exception TriggerNotSoftware()
        {
            return new TriggerNotSoftwareException();
        }

        internal static Exception TriggerNotSoftware(string triggerSource)
        {
            return new TriggerNotSoftwareException(String.Empty, triggerSource);
        }

        internal static Exception UnexpectedResponse()
        {
            return new UnexpectedResponseException();
        }

        internal static Exception UnexpectedResponse(string message)
        {
            return new UnexpectedResponseException(message);
        }

        internal static Exception UnknownOption(string optionName)
        {
            return new UnknownOptionException(String.Empty, optionName);
        }

        internal static Exception UnknownPhysicalName(string driverSession, string repeatedCapabilityName, string virtualName, string physicalName)
        {
            return new UnknownPhysicalNameException(driverSession, repeatedCapabilityName, virtualName, physicalName);
        }

        internal static Exception ValueNotSupported(string paramName, string value)
        {
            return new ValueNotSupportedException(paramName, value);
        }

        internal static Exception ValidPointCountExceedsCapacity(string validPointCount, string capacity)
        {
            return new ValidPointCountExceedsCapacityException(validPointCount, capacity);
        }
    }
}
