﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.Driver;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MindWorks.Nimbus
{
    // Selectors have a general form such as the following:
    //
    //		a1,a3,a5-a7:b2:[c5,c7]
    //
    // The formal syntax for repeated capability selectors is given in IVI 3.1 Section 4.4.7 Formal Syntax for Repeated
    // Capability Selectors.
    // 
    // The following describes the formal syntax for repeated capability selectors:
    //
    //	-	A syntactically valid repeated capability selector consists of zero or more repeated capability path 
    //      segments separated by colons (:). White space around colons is ignored.  When used with IVI-COM 
    //      collections, repeated capability selectors have exactly one repeated capability path segment.  In other 
    //      words, colons (:) are not allowed in repeated capability selectors used with IVI-COM collections.
    // 
    //	-	A repeated capability path segment consists of one or more repeated capability list elements, separated by 
    //      commas (,).  White space after commas is ignored.  A repeated capability path segment may be enclosed in 
    //      square brackets ([]).
    //
    //	-	A repeated capability list element consists of a repeated capability token or a repeated capability range.
    //
    //	-	A repeated capability range consists of two repeated capability tokens separated by a hyphen (-).
    //
    //	-	The order of precedence of operators is square brackets ([]), hyphen (-), colon (:), and comma (,).  Each 
    //      operator is evaluated from left to right.  
    //
    //	-	A repeated capability token is a physical repeated capability identifer or a virtual repeated capability 
    //       identifier. 
    //
    //	-	A syntactically valid physical or virtual repeated capability identifier consists of one or more of the 
    //      following characters: a z, A Z, 0 9, !, and _.  

    internal class RepCapSelector
    {
        private bool _isSingleIdentifier;
        private bool _isSingleIdentifierFlagValid;

        /// <summary>
        /// This constructor is marked private to prevent external construction.  Valid instances of this class are 
        /// obtained by calling the static
        /// Parse method or the static CreateEmptySelector method.
        /// </summary>
        private RepCapSelector(string selector, IList<PathSegment> pathSegments)
        {
            this.Source = selector;
            this.PathSegments = new ReadOnlyCollection<PathSegment>(pathSegments);
        }

        /// <summary>
        /// Gets the original source string passed to the Parse method.  This string includes any virtual repeated 
        /// capability names that may have been specified.
        /// </summary>
        internal string Source { get; }

        internal ReadOnlyCollection<PathSegment> PathSegments { get; }

        internal bool IsEmpty => this.PathSegments.Count == 0;

        internal static RepCapSelector CreateEmptySelector()
        {
            return new RepCapSelector(selector: String.Empty, new List<PathSegment>());
        }

        /// <summary>
        /// A collection-style repeated capability can only be accessed using simple, non-nested indentifiers.  Ranges 
        /// are not allowed.
        /// </summary>
        private static readonly Regex _collectionStyleSelectorParser
            = new Regex(
                @"^( \s* [\w!]+ \s* )$",
                RegexOptions.IgnorePatternWhitespace);

        internal static bool IsValidCollectionStyleSelector(string selector)
        {
            return _collectionStyleSelectorParser.IsMatch(selector);
        }

        internal bool IsNested => this.PathSegments.Count > 1;

        internal bool IsSingleIdentifier
        {
            get
            {
                if (!_isSingleIdentifierFlagValid)
                {
                    if (this.IsEmpty)
                    {
                        _isSingleIdentifier = false;
                    }
                    else
                    {
                        _isSingleIdentifier = true;

                        foreach (var pathSegment in this.PathSegments)
                        {
                            if (pathSegment.ListElements.Count > 1)
                            {
                                _isSingleIdentifier = false;

                                return _isSingleIdentifier;
                            }
                            else
                            {
                                foreach (var listElement in pathSegment.ListElements)
                                {
                                    if (listElement is Range)
                                    {
                                        _isSingleIdentifier = false;

                                        return _isSingleIdentifier;
                                    }
                                }
                            }
                        }
                    }

                    _isSingleIdentifierFlagValid = true;
                }

                return _isSingleIdentifier;
            }
        }

        /// <summary>
        /// Generates the complete list of physical repeated capability identifiers represented by the specified 
        /// repeated capability selector.  This method first replaces virtual names with their corresponding physical
        /// names (and ranges) and then expands the resulting expression.  The procedure followed for the expansion and
        /// virtual name substituion are described in IVI-3.1.
        /// </summary>
        /// <param name="selector">
        /// The selector to expand.
        /// </param>
        /// <param name="sessionInfo">
        /// The session info object containing the virtual-to-physical name mappings that should be used in the 
        /// expansion.  If this parameter is null then all of the names in the selector are assumed to be physical 
        /// names, and no attempt is made to map virtual names to physical names
        /// before performing the expansion.
        /// </param>
        /// <returns>
        /// A complete list of physical repeated capability identifiers represented by the selector.  The list may 
        /// include qualified and unqualified physical identifiers, depending upon the actual mappings loaded from 
        /// the IVI Configuration Store.
        /// </returns>
        internal static IEnumerable<string> ExpandToPhysicalNames(RepCapSelector selector, SessionInfo sessionInfo)
        {
            var expandedSelector = sessionInfo != null ? ReplaceVirtualNames(selector, sessionInfo) : selector;

            var childListElements = new Dictionary<ListElement, ListElement>();

            for (var pathSegmentIndex = 0; pathSegmentIndex < expandedSelector.PathSegments.Count; pathSegmentIndex++)
            {
                foreach (var identifier in ExpandPathSegment(expandedSelector, pathSegmentIndex, childListElements))
                {
                    yield return identifier;
                }
            }
        }

        private static IEnumerable<string> ExpandPathSegment(RepCapSelector selector, int pathSegmentIndex, Dictionary<ListElement, ListElement> childListElements)
        {
            var pathSegment = selector.PathSegments[pathSegmentIndex];

            for (var listElementIndex = 0; listElementIndex < pathSegment.ListElements.Count; listElementIndex++)
            {
                var listElement = pathSegment.ListElements[listElementIndex];

                if (!childListElements.ContainsKey(listElement))
                {
                    foreach (var identifier in ExpandListElement(selector, pathSegmentIndex, listElementIndex, childListElements))
                    {
                        yield return identifier;
                    }
                }
            }
        }

        private static IEnumerable<string> ExpandListElement(RepCapSelector selector, int pathSegmentIndex, int listElementIndex, Dictionary<ListElement, ListElement> childListElements)
        {
            var listElement = selector.PathSegments[pathSegmentIndex].ListElements[listElementIndex];

            if (ListElementHasChildIdentifiers(selector, pathSegmentIndex, listElementIndex))
            {
                // The element has child identifiers, so we build the nested identifier by concatenating each 
                // identifier in the current element with each identifier (and its children) in the next path segment.
                //
                foreach (var identifier in GetListElementIdentifers(listElement))
                {
                    foreach (var childIdentifier in GetChildIdentifiersInPathSegment(selector, pathSegmentIndex + 1, childListElements))
                    {
                        yield return $"{identifier}:{childIdentifier}";
                    }
                }
            }
            else
            {
                // The element has no child identifiers, so get the identifiers represented by the list element itself.
                //
                foreach (var identifier in GetListElementIdentifers(listElement))
                {
                    yield return identifier;
                }
            }
        }

        private static IEnumerable<string> GetChildIdentifiersInPathSegment(RepCapSelector selector, int pathSegmentIndex, Dictionary<ListElement, ListElement> childListElements)
        {
            var pathSegment = selector.PathSegments[pathSegmentIndex];

            if (pathSegment.IsEnclosedInBrackets)
            {
                // Return all list elements (and their children) in the path segment.  This enforces the precedence 
                // rules for selectors whereby square  brackets have higher precedence than commas.  In the example 
                // below, this would occur when we encounter the path "[b1,b2,b3]".  This would produce three nested
                // identifiers: "a3:b1:c1", "a3:b2:c1", and "a3:b3:c1"
                //
                // Example: a1,a2,a3:[b1,b2,b3]:c1,c2,c3
                //                    ^  ^  ^
                //
                for (var listElementIndex = 0; listElementIndex < pathSegment.ListElements.Count; listElementIndex++)
                {
                    var listElement = pathSegment.ListElements[listElementIndex];

                    if (!childListElements.ContainsKey(listElement))
                    {
                        childListElements.Add(listElement, listElement);
                    }

                    foreach (var identifier in ExpandListElement(selector, pathSegmentIndex, listElementIndex, childListElements))
                    {
                        yield return identifier;
                    }
                }
            }
            else
            {
                // Only the first list element is part of the nested identifier.  In the example below, this would 
                // occur when we encounter the path "b1,b2,b3".  Only the identifier "b1" is part of the nested 
                // identifier "a3:b1".
                //
                // Example: a1,a2,a3:b1,b2,b3:c1,c2,c3
                //                   ^
                //
                var listElement = pathSegment.ListElements[0];

                if (!childListElements.ContainsKey(listElement))
                {
                    childListElements.Add(listElement, listElement);
                }

                foreach (var identifier in ExpandListElement(selector, pathSegmentIndex, 0, childListElements))
                {
                    yield return identifier;
                }
            }
        }

        private static bool ListElementHasChildIdentifiers(RepCapSelector selector, int pathSegmentIndex, int listElementIndex)
        {
            var pathSegment = selector.PathSegments[pathSegmentIndex];
            var lastPathSegmentIndex = selector.PathSegments.Count - 1;
            var lastListElementIndex = pathSegment.ListElements.Count - 1;

            // This list element has child identifiers if there are path segments after this one AND the current path 
            // segment is either enclosed in brackets or the list element is the last list element in the current path 
            // segment.
            //
            // Examples:
            //		a1,a2,a3:b1,b2,b3		=>	"a3" has child identifier "b1"
            //		[a1,a2,a3]:b1,b2,b3		=>	"a1", "a2" and "a3" all have "b1" as a child identifier
            //
            return pathSegmentIndex < lastPathSegmentIndex && (pathSegment.IsEnclosedInBrackets || listElementIndex == lastListElementIndex);
        }

        private static IEnumerable<string> GetListElementIdentifers(ListElement listElement)
        {
            if (listElement is Range range)
            {
                for (int i = range.LowerBound; i <= range.UpperBound; i++)
                {
                    yield return range.BaseName + i.ToString(CultureInfo.InvariantCulture);
                }
            }
            else
            {
                yield return ((Identifier)listElement).Text;
            }
        }

        private static RepCapSelector ReplaceVirtualNames(RepCapSelector selector, SessionInfo sessionInfo)
        {
            var newSelectorText = Regex.Replace(
                selector.Source,
                @"(?<identifier> [\w!]+ )",
                match =>
                {
                    var physicalName = sessionInfo.TranslateVirtualName(match.Value.Trim());

                    // The "physicalName" mapped from this one virtual identifier could be a comma-separated list of 
                    // physical identifiers, or a range of physical identifiers, or a nested physical identifier.  For
                    // example, all of the following are valid:
                    //
                    //		"CH1"
                    //		"CH1-CH3"
                    //		"CH1:TRACE2"
                    //		"CH1,CH2,CH3"

                    // As per IVI 3.1, Section 4.4.6, we insert brackets around mapped strings that contain at least 
                    // one comma, but no colons.
                    //
                    if (physicalName.IndexOf(',') > 0 && physicalName.IndexOf(':') < 0)
                    {
                        physicalName = $"[{physicalName}]";
                    }

                    return physicalName;
                },
                RegexOptions.IgnorePatternWhitespace | RegexOptions.ExplicitCapture);

            // Now we parse the expanded selector string again.
            //
            return Parse(newSelectorText.TrimEnd(','));
        }

        private void Validate()
        {
            // Make sure all ranges are ascending and none overlap.
            //
            foreach (var pathSegment in this.PathSegments)
            {
                ValidatePathSegment(pathSegment);
            }
        }

        private void ValidatePathSegment(PathSegment pathSegment)
        {
            // key = base name, value = list of index ranges
            //
            var existingRangesMap = new Dictionary<string, List<IndexRange>>();

            foreach (var listElement in pathSegment.ListElements)
            {
                ValidateListElement(listElement, existingRangesMap);
            }
        }

        private void ValidateListElement(ListElement listElement, Dictionary<string, List<IndexRange>> existingRangesMap)
        {
            if (listElement is Range range)
            {
                ValidateRange(existingRangesMap, range);
            }
            else
            {
                // This should be just an identifier, so we need to remember its index, if it has one.
                //
                var identifier = listElement as Identifier;

                Debug.Assert(identifier != null);
                if (identifier == null)
                {
                    throw ErrorService.SelectorFormat(this.Source);
                }

                ValidateIdentifier(identifier, existingRangesMap);
            }
        }

        private void ValidateIdentifier(Identifier identifier, Dictionary<string, List<IndexRange>> existingRangesMap)
        {
            if (identifier.HasIndex)
            {
                if (existingRangesMap.TryGetValue(identifier.BaseName, out var indexRanges))
                {
                    foreach (var indexRange in indexRanges)
                    {
                        if (identifier.Index >= indexRange.LowerBound && identifier.Index <= indexRange.UpperBound)
                        {
                            // Identifier index overlaps with the range.
                            //
                            throw ErrorService.SelectorRange(this.Source);
                        }
                    }
                }
                else
                {
                    // No indices stored for this base name yet, so create the list and add it to the map.
                    //
                    indexRanges = new List<IndexRange>();
                    existingRangesMap.Add(identifier.BaseName, indexRanges);
                }

                indexRanges.Add(new IndexRange(identifier.Index, identifier.Index));
            }
        }

        private void ValidateRange(Dictionary<string, List<IndexRange>> existingRangesMap, Range range)
        {
            if (range.LowerBound >= range.UpperBound)
            {
                throw ErrorService.SelectorRange(this.Source);
            }

            if (existingRangesMap.TryGetValue(range.BaseName, out var indexRanges))
            {
                foreach (var indexRange in indexRanges)
                {
                    if (!(range.LowerBound < indexRange.LowerBound && range.UpperBound < indexRange.LowerBound ||
                        range.LowerBound > indexRange.UpperBound && range.UpperBound > indexRange.UpperBound))
                    {
                        // Ranges overlap.
                        //
                        throw ErrorService.SelectorRange(this.Source);
                    }
                }
            }
            else
            {
                // No indices stored for this base name yet, so create the list and add it to the map.
                //
                indexRanges = new List<IndexRange>();
                existingRangesMap.Add(range.BaseName, indexRanges);
            }

            indexRanges.Add(new IndexRange(range.LowerBound, range.UpperBound));
        }

        internal static bool TryParse(string selector, out RepCapSelector parsedSelector)
        {
            parsedSelector = null;

            try
            {
                parsedSelector = Parse(selector);
            }
            catch (SelectorFormatException)
            {
            }
            catch (SelectorRangeException)
            {
            }

            return parsedSelector != null;
        }

        internal static RepCapSelector Parse(string selector)
        {
            selector = TextUtility.RemoveWhiteSpace(selector);

            // Match the entire selector first so that we can validate the format for easier processing of the list 
            // elements.
            //
            if (!_selectorParser.IsMatch(selector))
            {
                if (TextUtility.IsWhiteSpace(selector))
                {
                    return CreateEmptySelector();
                }

                throw ErrorService.SelectorFormat(selector);
            }

            var pathSegments = new List<PathSegment>();
            var listElements = new List<ListElement>();

            var matches = _listElementParser.Matches(selector);
            Match match = null;

            for (int i = 0; i < matches.Count; i++)
            {
                match = matches[i];

                if (match.Groups["range"].Success)
                {
                    var range = new Range(
                        match.Groups["range"].Value,
                        match.Groups["baseName"].Value,
                        Int32.Parse(match.Groups["lowerBound"].Value),
                        Int32.Parse(match.Groups["upperBound"].Value));

                    listElements.Add(range);
                }
                else if (match.Groups["identifier"].Success)
                {
                    var identifier = match.Groups["index"].Success
                        ? new Identifier(
                            match.Groups["identifier"].Value,
                            match.Groups["baseName"].Value,
                            Int32.Parse(match.Groups["index"].Value))
                        : new Identifier(match.Groups["identifier"].Value);

                    listElements.Add(identifier);
                }
                else
                {
                    Debug.Fail("Unknown list element type.");

                    throw ErrorService.SelectorFormat(selector);
                }

                if (match.Groups["pathSegmentSeparator"].Success)
                {
                    // We're at the end of a path segment, so add the current one to the path segments list and create 
                    // a new list element list.
                    //
                    pathSegments.Add(new PathSegment(listElements, match.Groups["bracket"].Success));

                    listElements = new List<ListElement>();
                }
            }

            if (listElements.Count > 0)
            {
                pathSegments.Add(new PathSegment(listElements, match.Groups["bracket"].Success));
            }

            var result = new RepCapSelector(selector, pathSegments);

            result.Validate();

            return result;
        }

        /// <summary>
        /// This parser is used to match the entire selector string so that the list element parser below can be 
        /// simpler.  Since this parser is only used to validate and not to parse any data from the selector, it uses 
        /// unnamed groups extensively, which act as non-capturing groups when RegexOptions.ExplicitCapture is 
        /// specified.  This improves performance when captured data is not needed.
        /// </summary>
        private static readonly Regex _selectorParser = new Regex(
            @"
			^ (	   													# anchor match to the beginning to ensure we match the entire input string

			(?<OpenBracket> \[ )?									# path segments are optionally enclosed in square brackets

			(	
				(													# list element; a simple name or a range								
					(	 											# range; Example: a1-a5
						( (?<baseName> [\w!]+ ) \d+ )				# lower identifer of range
						- 
						( (\k<baseName>) \d+ )						# upper identifier of range
					) 
					|
					[\w!]+											# simple name; NOTE: It is important that this appear AFTER the range because of the order 
				)													# that Regex evaluates the alternation construct ( '|' )
																	
				( , (?= [\w!]+ ) )?									# comma separates list elements; look ahead to ensure an indentifier follows
			)+

			(?<CloseBracket-OpenBracket> \] )?						# close outer square brackets
			(?(OpenBracket)(?!))									# force match to fail if Open count > 0 at this point (e.g. non-balanced brackets)				
			
			( : (?= [\w!]+ | \[ ) )?								# colon separates path segments; look ahead to ensure an identifer or open bracket follows
			
			)+ $													# anchor match to the end to ensure we match the entire input string

			", RegexOptions.IgnorePatternWhitespace | RegexOptions.ExplicitCapture);

        /// <summary>
        /// This parser extracts individual list elements.  It relies upon the selector parser above to validate the 
        /// selector string as a whole.
        /// </summary>
        private static readonly Regex _listElementParser = new Regex(
            @"
			(
				(?<range> 											# Example: a1-a5
					(?<lowerIdentifier>
						(?<baseName> [\w!]+ ) (?<lowerBound> \d+)
					)
					-
					(?<upperIdentifier>
						(\k<baseName>) (?<upperBound> \d+)
					)
				) 
				|
				(?<identifier> 										# simple name; NOTE: It is important that this appear AFTER <range> because of the order that Regex evaluates the alternation construct ( '|' )
					(?<baseName> [\w!]+ ) (?<index> \d+)
					|
					[\w!]+
				) 
			)
					
			( , (?= [\w!]+ ) )?										# comma separates list elements
						
			(?<pathSegmentSeparator> : | (?<bracket> \] ) )?		# colon or closing bracket separates path segments

			", RegexOptions.IgnorePatternWhitespace | RegexOptions.ExplicitCapture);


        private class IndexRange
        {
            internal IndexRange(int lowerBound, int upperBound)
            {
                this.LowerBound = lowerBound;
                this.UpperBound = upperBound;
            }

            internal int LowerBound { get; private set; }

            internal int UpperBound { get; private set; }
        }

        #region class PathSegment

        /// <summary>
        /// This class is for internal use of the Nimbus Class Library and is not intended to be used directly in 
        /// driver developer code.
        /// </summary>
        internal class PathSegment
        {
            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal PathSegment(IList<ListElement> listElements, bool isEnclosedInBrackets)
            {
                this.ListElements = new ReadOnlyCollection<ListElement>(listElements);
                this.IsEnclosedInBrackets = isEnclosedInBrackets;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal ReadOnlyCollection<ListElement> ListElements { get; }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly
            /// from driver developer code.
            /// </summary>
            internal bool IsEnclosedInBrackets { get; }
        }

        #endregion

        #region class ListElement

        /// <summary>
        /// This class is for internal use of the Nimbus Class Library and is not intended to be used directly in 
        /// driver developer code.
        /// </summary>
        internal abstract class ListElement
        {
            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from  driver developer code.
            /// </summary>
            protected ListElement(string text, string baseName)
            {
                this.Text = text;
                this.BaseName = baseName;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal string Text { get; }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal string BaseName { get; }
        }

        #endregion

        #region class Range

        /// <summary>
        /// This class is for internal use of the Nimbus Class Library and is not intended to be used directly in 
        /// driver developer code.
        /// </summary>
        internal class Range : ListElement
        {
            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly
            /// from driver developer code.
            /// </summary>
            internal Range(string text, string baseName, int lowerBound, int upperBound)
                : base(text, baseName)
            {
                this.LowerBound = lowerBound;
                this.UpperBound = upperBound;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal int LowerBound { get; }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal int UpperBound { get; }
        }

        #endregion

        #region class Identifier

        /// <summary>
        /// This class is for internal use of the Nimbus Class Library and is not intended to be used directly in 
        /// driver developer code.
        /// </summary>
        internal class Identifier : ListElement
        {
            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly
            /// from driver developer code.
            /// </summary>
            internal Identifier(string text)
                : this(text, text, -1)
            {
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from  driver developer code.
            /// </summary>
            internal Identifier(string text, string baseName, int index)
                : base(text, baseName)
            {
                this.Index = index;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal bool HasIndex => this.Index >= 0;

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal int Index { get; }
        }

        #endregion
    }
}
