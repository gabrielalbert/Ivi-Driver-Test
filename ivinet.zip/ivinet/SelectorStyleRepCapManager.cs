﻿///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	© 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Represents the repeated capability collection object in the driver object model hierarchy.
    /// </summary>
    public class SelectorStyleRepCapManager : RepCapManager
    {
        private string _activeSelector;

        internal SelectorStyleRepCapManager(string repCapName, SessionInfo session, bool useQualifiedPhysicalNames)
            : base(repCapName, session, useQualifiedPhysicalNames, null /* selector-style never have parents*/)
        {
            _activeSelector = String.Empty;
        }

        internal IList<PhysicalName> ActivePhysicalNames { get; } = new List<PhysicalName>();

        /// <summary>
        /// Gets the physical name of the active repeated capability.  If more than one name is active, this method 
        /// throws an InvalidOperationException.
        /// </summary>
        /// <returns>The active physical name.</returns>
        internal PhysicalName GetActivePhysicalName()
        {
            if (this.ActivePhysicalNames.Count == 0)
            {
                return null;
            }

            if (this.ActivePhysicalNames.Count > 1)
            {
                throw new InvalidOperationException(NclStrings.CannotReadMutipleRepCaps);
            }

            return this.ActivePhysicalNames[0];
        }

        /// <summary>
        /// Gets or sets the set of active repeated capabilities names.  The selector may contain physical or virtual 
        /// names as well as ranges.
        /// </summary>
        internal string ActiveSelector
        {
            get => _activeSelector;
            set
            {
                if (String.IsNullOrEmpty(value))
                {
                    if (this.PhysicalNames.Count > 1)
                    {
                        throw ErrorService.SelectorNameRequired(this.RepCapName);
                    }

                    if (this.PhysicalNames.Count == 0)
                    {
                        Debug.Fail("No physical names exist.");

                        _activeSelector = value;
                        this.ActivePhysicalNames.Clear();
                    }
                    else
                    {
                        _activeSelector = value;
                        this.ActivePhysicalNames.Clear();

                        this.ActivePhysicalNames.Add(this.PhysicalNames[0]);

                        return;
                    }
                }

                if (value != _activeSelector)
                {
                    _activeSelector = value;
                    this.ActivePhysicalNames.Clear();

                    var selector = RepCapSelector.Parse(value);

                    if (selector.IsNested)
                    {
                        throw ErrorService.SelectorHierarchy(value);
                    }

                    foreach (var physicalName in RepCapSelector.ExpandToPhysicalNames(selector, this.Session))
                    {
                        var name = this.LookupPhysicalName(physicalName);

                        if (name == null)
                        {
                            throw ErrorService.UnknownPhysicalName(this.Session.ResourceDescriptor, this.RepCapName, value, physicalName);
                        }

                        this.ActivePhysicalNames.Add(name);
                    }
                }
            }
        }
    }
}
