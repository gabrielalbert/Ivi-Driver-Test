///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.Driver;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reflection;
using System.Text;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Represents the root object in the driver object model hierarchy.
    /// </summary>
    public abstract class Driver : DriverNode,
        IServiceProvider,
        IDisposable
    {
        private SessionInfo _sessionInfo;
        private DriverInfo _driverInfo;

#if NCL_VISANET
        private Ivi.Visa.IMessageBasedSession _messageBasedSession;

        private Ivi.Visa.IRegisterBasedSession _registerBasedSession;
#endif

        /// <summary>
        /// Creates a new instance of the Driver class.
        /// </summary>
        protected Driver()
        {
            this.DataCache = new Cache();
            this.DisposedSyncRoot = new object();
            this.DefaultImplementation = new DefaultImplementations(this);
        }

        /// <summary>
        /// Diposes of any unmanaged resources held by the driver class.
        /// </summary>
        ~Driver()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// Initializes the Driver class.  This method must be called from any of the derived constructors to ensure 
        /// proper initialization of the driver.
        /// </summary>
        protected void Initialize(string resourceName, bool idQuery, bool reset, string options, LockType lockType, string accessKey, int ioTimeoutMilliseconds, int resetTimeoutMilliseconds, int selfTestTimeoutMilliseconds)
        {
            this.IOTimeoutMilliseconds = ioTimeoutMilliseconds;
            this.ResetTimeoutMilliseconds = resetTimeoutMilliseconds;
            this.SelfTestTimeoutMilliseconds = selfTestTimeoutMilliseconds;

            this.LockManager = new LockManager((IIviDriver)this, lockType, accessKey);

            this.InitializeServiceProvider();

            _driverInfo = DriverInfo.Load(this);

            _sessionInfo = SessionInfo.Load(this, resourceName, options, this.DriverInfo.SoftwareModuleName);
            this.ValidateSessionInformation();

            if (!this.Session.InitOptions.SimulationEnabled)
            {
                this.InitializeIO();

                if (this.Session.InitOptions.QueryInstrumentStatusEnabled)
                {
                    this.ClearIO();
                }
            }

            // Use the try-catch to ensure we close the connection if any error occurs after this point.
            //
            try
            {
                this.InitializeIdentification();

                if (idQuery)
                {
                    this.CheckInstrumentSupported();
                }

                if (reset)
                {
                    if (!this.DriverInfo.ResetSupported)
                    {
                        throw ErrorService.ResetNotSupported();
                    }

                    try
                    {
                        (this as IIviDriverUtility).Reset();
                    }
                    catch (Exception ex)
                    {
                        throw ErrorService.ResetFailed(ex);
                    }
                }

#if NCL_VISANET
                this.TypeConverter = new TypeFormatter(this.Session.InstrumentModel);

                if (this.IsMessageBasedIOSession)
                {
                    this.IO.FormattedIO.TypeFormatter = this.TypeConverter;
                }
#endif
                this.InitNode();
            }
            catch (Exception)
            {
                this.CloseIO();
                throw;
            }
        }

        private void InitializeServiceProvider()
        {
            this.Services = new Dictionary<Type, object>();

            // We always support IIviDriver as a service type.
            //
            this.AddService(typeof(IIviDriver), this);

            // We always support the instrument-specific root interface as a service type.
            //
            Type instrSpecificRoot = null;
            var mainDriverType = this.GetType();
            var baseInterfaces = mainDriverType.GetInterfaces();
            var instrSpecificRootIntfName = 'I' + mainDriverType.Name;

            foreach (var baseIntf in baseInterfaces)
            {
                if (baseIntf.Name == instrSpecificRootIntfName)
                {
                    instrSpecificRoot = baseIntf;
                    this.AddService(instrSpecificRoot, this);
                    break;
                }
            }

            Debug.Assert(instrSpecificRoot != null);

            // Gather the list of all base interfaces from IVI-defined assemblies
            //
            var iviInterfaces = new List<Type>();

            foreach (var baseIntf in baseInterfaces)
            {
                if (baseIntf.Namespace.StartsWith("Ivi.", StringComparison.Ordinal))
                {
                    iviInterfaces.Add(baseIntf);
                }
            }

            // Gather all root interfaces from instrument classes supported by the driver.
            //
            var asm = mainDriverType.Assembly;
            var attrs = (SupportedInstrumentClassAttribute[])asm.GetCustomAttributes(typeof(SupportedInstrumentClassAttribute), false);

            foreach (var attr in attrs)
            {
                foreach (var baseIntf in iviInterfaces)
                {
                    if (baseIntf.Name == 'I' + attr.InstrumentClassName)
                    {
                        this.AddService(baseIntf, this);
                    }
                }
            }
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from .
        /// driver developer code.
        /// </summary>
        protected override string CacheKeyPrefix
        {
            get { return String.Empty; }
        }

        private Dictionary<Type, object> Services { get; set; }

        private object DisposedSyncRoot { get; set; }

        private Cache DataCache { get; set; }

        private LockManager LockManager { get; set; }

#if NCL_VISANET
        private TypeFormatter TypeConverter { get; set; }
#endif
        private bool IsDisposed { get; set; }

        private int IOTimeoutMilliseconds { get; set; }

        private int ResetTimeoutMilliseconds { get; set; }

        private int SelfTestTimeoutMilliseconds { get; set; }

        /// <summary>
        /// Returns a reference to the DefaultImplementations class, which provides implementation code for many of the
        /// IVI-defined inherent capabilities. 
        /// </summary>
        protected DefaultImplementations DefaultImplementation { get; private set; }

        /// <summary>
        /// Warning event.
        /// </summary>
        protected event EventHandler<WarningEventArgs> Warning;

        /// <summary>
        /// Coercion record event.
        /// </summary>
        protected event EventHandler<CoercionEventArgs> Coercion;

        /// <summary>
        /// Override this method to process a custom DriverSetup option.  Custom DriverSetup options are driver-defined 
        /// name-value pairs that must be processed by this method.  Custom DriverSetup options do *not* include those 
        /// options common to all Nimbus drivers, such as the "Model" and "Trace" options.  This method is only called 
        /// when Nimbus cannot interpret a DriverSetup option.
        /// <para>
        /// Be default, this method throws an UnknownOptionException.  As such, it *must* be overridden in the main 
        /// driver class if the user specifies
        /// any custom DriverSetup options.
        /// </para>
        /// </summary>
        /// <param name="name">Name of the custom DriverSetup option.</param>
        /// <param name="value">Value of the custom DriverSetup option.</param>
        internal virtual void ProcessCustomDriverSetupOption(string name, string value)
        {
            throw ErrorService.UnknownOption(name);
        }

        /// <summary>
        /// Interchange check warning event.
        /// </summary>
        protected event EventHandler<InterchangeCheckWarningEventArgs> InterchangeCheckWarning;

        #region DriverNode overrides

        /// <summary>
        /// Returns a reference to the SessionInfo, which includes details about the instrument to which the driver is connected as well as session-specific information loaded from
        /// the IVI Configuration Store and information specified in the driver constructor.
        /// </summary>
        internal sealed override SessionInfo Session => _sessionInfo;

        /// <summary>
        /// Returns a reference to the DriverInfo, which includes details about the driver itself.  This information is static and unrelated to any instrument connection
        /// that may have been established.
        /// </summary>
        protected sealed override DriverInfo DriverInfo => _driverInfo;

#if NCL_VISANET

        /// <summary>
        /// Returns a reference to the standard VISA.NET IMessageBasedSession interface.  This property is null if the driver is running in simulation mode or if the driver
        /// is using an I/O implementation other than VISA.NET or if the driver does not support message-based communication.
        /// NOTE: This property is only available when using VISA.NET as the driver's I/O provider.
        /// </summary>
        protected sealed override Ivi.Visa.IMessageBasedSession IO
        {
            get { return _messageBasedSession; }
        }

        /// <summary>
        /// Returns a reference to the standard VISA.NET IRegisterBasedSession interface.  This property is null if the driver is running in simulation mode or if the driver
        /// is using an I/O implementation other than VISA.NET or if the driver does not support register-based communication.
        /// NOTE: This property is only available when using VISA.NET as the driver's I/O provider.
        /// </summary>
        protected sealed override Ivi.Visa.IRegisterBasedSession RegisterIO
        {
            get { return _registerBasedSession; }
        }

        /// <summary>
        /// Returns a reference to the standard VISA.NET IVisaSession interface.  This property is null if the driver is running in simulation mode or if the driver
        /// is using an I/O implementation other than VISA.NET.
        /// NOTE: This property is only available when using VISA.NET as the driver's I/O provider.
        /// </summary>
        protected sealed override Ivi.Visa.IVisaSession VisaSession
        {
            get { return this.IsMessageBasedIOSession ? (Ivi.Visa.IVisaSession)this.IO : this.RegisterIO; }
        }

#endif  // NCL_VISANET

        /// <summary>
        /// Acquires a driver-wide lock that protects the driver from simultaneous access by more than one thread at a time.  An infinite timeout is used, meaning that the calling
        /// thread will wait indefinitely for the lock to become available.
        /// </summary>
        protected sealed override IIviDriverLock AcquireLock()
        {
            return ((IIviDriverUtility)this).Lock();
        }

        /// <summary>
        /// Acquires a driver-wide lock that protects the driver from simultaneous access by more than one thread at a time.  The calling thread specifies how much time it is
        /// willing to wait for the lock.  If <paramref name="maxTime"/> expires before the lock becomes available, then an exception is thrown.
        /// </summary>
        protected sealed override IIviDriverLock AcquireLock(PrecisionTimeSpan maxTime)
        {
            return ((IIviDriverUtility)this).Lock(maxTime);
        }

        /// <summary>
        /// Throws an exception if the driver instance has already been disposed.
        /// </summary>
        protected override void CheckDisposed()
        {
            if (this.IsDisposed)
            {
                throw ErrorService.ObjectDisposed(this.DriverInfo.DriverIdentifier);
            }
        }

        /// <summary>
        /// Indicates if the currently connected instrument model is a member of the specified instrument family.
        /// </summary>
        protected override bool InstrumentInFamily(string family)
        {
            return this.DriverInfo.IsModelInFamily(this.Session.InstrumentModel, family);
        }

        /// <summary>
        /// Indicates if the driver is currently connect to the specified instrument model.
        /// </summary>
        protected override bool InstrumentIsModel(string model)
        {
            return this.Session.InstrumentModel == model;
        }

        /// <summary>
        /// If QueryInstrStatus is enabled for the driver session, this method communicates with the instrument to determine
        /// if the previous operation resulted in an instrument error.  An InstrumentStatusException is thrown if an error 
        /// occurred.  By default, this method uses the standard "*ESR?" query to determine if an error occurred.  Drivers
        /// that require an alternate scheme for error polling must override this method.
        /// </summary>
        protected override void PollInstrumentErrors()
        {

#if NCL_VISANET

            if (!this.Session.InitOptions.QueryInstrumentStatusEnabled || this.Session.InitOptions.SimulationEnabled)
            {
                // User has not enabled polling, or is running in simulation mode, so just return without doing anything.
                //
                return;
            }

            if (!this.IsMessageBasedIOSession)
            {
                Debug.Fail("The PollInstrumentErrors method must be overridden for non-message-based I/O sessions.");
                return;
            }

            try
            {
                this.IO.FormattedIO.WriteLine("*ESR?");

                var value = this.IO.FormattedIO.ReadLineInt64();

                if ((value & 4) != 0 || (value & 8) != 0 || (value & 16) != 0 || (value & 32) != 0)
                {
                    throw new InstrumentStatusException();
                }
            }
            catch (InstrumentStatusException)
            {
                throw;
            }
            catch (Exception)
            {
                this.IO.Clear();
                throw;
            }

#else   // NCL_VISA_NET

            throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented(nameof(PollInstrumentErrors)));

#endif  // NCL_VISA_NET
        }

        /// <summary>
        /// Fires the standard IIviDriverOperation.Warning event.
        /// </summary>
        protected sealed override void SendWarningEvent(WarningEventArgs args)
        {
            this.Warning?.Invoke(this, args);
        }

        /// <summary>
        /// Fires the standard IIviDriverOperation.Coercion event.
        /// </summary>
        protected sealed override void SendCoercionEvent(object originalValue, object coercedValue)
        {
            if (this.Session.InitOptions.CoercionRecordingEnabled)
            {
                this.Coercion?.Invoke(this, new CoercionEventArgs(NclStrings.CoercionEvent(this.GetType().Name, originalValue, coercedValue)));
            }
        }

        /// <summary>
        /// Fires the standard IIviDriverOperation.InterchangeCheckWarning event.
        /// </summary>
        protected sealed override void SendInterchangeEvent(InterchangeCheckWarningEventArgs args)
        {
            if (this.Session.InitOptions.InterchangeCheckingEnabled)
            {
                this.InterchangeCheckWarning?.Invoke(this, args);
            }
        }

#if NCL_VISANET

        /// <summary>
        /// Converts the specified enum value to a string using the driver's TypeConverter.
        /// NOTE: This method is only available when using VISA.NET as the driver's I/O provider.
        /// </summary>
        internal sealed override string ConvertEnumToString(Enum member)
        {
            return ((Ivi.Visa.ITypeFormatter)this.TypeConverter).ToString(member);
        }

        /// <summary>
        /// Converts the specified string value to an enum value using the driver's TypeConverter.
        /// NOTE: This method is only available when using VISA.NET as the driver's I/O provider.
        /// </summary>
        internal sealed override Enum ConvertStringToEnum<TEnum>(string data)
        {
            return (Enum)((Ivi.Visa.ITypeFormatter)this.TypeConverter).Parse(typeof(TEnum), data);
        }

#endif // NCL_VISANET

        /// <summary>
        /// Indicates if the driver's internal state caching engine contains the specified value for the calling property.  Each cached value is maintained on a per-property basis. 
        /// This method MUST be called directly from the driver method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected sealed override bool CacheContainsValue(object value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            return this.CacheContainsValue(meth, this, value);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal bool CacheContainsValue(MethodInfo meth, DriverNode node, object value)
        {
            return this.DataCache.CacheContainsValue(meth, node, value);
        }

        /// <summary>
        /// Returns the value cached for the calling property.  Each cached value is maintained on a per-property basis. 
        /// This method MUST be called directly from the driver method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected sealed override bool GetCacheValue<T>(out T value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            return this.GetCacheValue(meth, this, out value);
        }


        /// <summary>
        /// Gets the value cached for the specified property.
        /// This method MUST be called directly from the driver method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected sealed override bool GetCacheValue<T>(string key, out T value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            return this.DataCache.GetValue(key, meth, this, out value);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal bool GetCacheValue<T>(MethodInfo meth, DriverNode node, out T value)
        {
            return this.DataCache.GetValue(meth, node, out value);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal bool GetCacheValue<T>(string key, MethodInfo meth, DriverNode node, out T value)
        {
            return this.DataCache.GetValue(key, meth, node, out value);
        }

        /// <summary>
        /// Returns the value cached for the calling property.  Each cached value is maintained on a per-property basis. 
        /// This method MUST be called directly from the driver method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected sealed override bool GetCacheValue(out object value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            return this.GetCacheValue(meth, this, out value);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal bool GetCacheValue(MethodInfo meth, DriverNode node, out object value)
        {
            return this.DataCache.GetValue(meth, node, out value);
        }

        /// <summary>
        /// Updates the value cached for the calling property with the specified value.  Each cached value is maintained on a per-property basis. 
        /// This method MUST be called directly from the driver method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected sealed override void UpdateCacheValue(object value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            this.DataCache.UpdateEntry(meth, this, value);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal void UpdateCacheValue(MethodInfo meth, DriverNode node, object value)
        {
            this.DataCache.UpdateEntry(meth, node, value);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal void UpdateCacheValue(string key, MethodInfo meth, DriverNode node, object value)
        {
            this.DataCache.UpdateEntry(key, meth, node, value);
        }

        /// <summary>
        /// Updates the value cached for the specified property.
        /// This method MUST be called directly from the driver method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected sealed override void UpdateCacheValue(string key, object value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            this.DataCache.UpdateEntry(key, meth, this, value);
        }

        /// <summary>
        /// Invalidates the value cached for the specified property.  This causes the very next property access to communicate with the instrument
        /// to get or set the property value.  Each cached value is maintained on a per-property basis. 
        /// This method MUST be called directly from the driver method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected sealed override void InvalidateCacheEntry(string key)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            this.DataCache.InvalidateEntry(key, meth, this);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal void InvalidateCacheEntry(MethodInfo meth, DriverNode node, string key)
        {
            this.DataCache.InvalidateEntry(key, meth, node);
        }

        /// <summary>
        /// Invalidates all cached values in the state caching engine.  
        /// </summary>
        protected sealed override void InvalidateAllCacheEntries()
        {
            this.DataCache.InvalidateAll();
        }

        /// <summary>
        /// Gets the default value that should be returned from a property when the driver is operating in simulation mode.  For properties configured to use
        /// a simulation mode of LastValueSet, this method is called by Nimbus whenever a property getter is called before the setter is called for that same
        /// property.  For properties configured to use a simulation mode of ConstantValue, this method is called to retrieve the constant value returned for
        /// all calls to the property getter.  Override this method to provide default simulation values for types not covered by the default implementation.
        /// </summary>
        protected override object GetDefaultValueForSimulation(Type targetType, string defaultValue)
        {
            if (targetType == null) throw new ArgumentNullException(nameof(targetType));
            if (defaultValue == null) throw new ArgumentNullException(nameof(defaultValue));

            if (IsIviType(targetType, "Ivi.Driver"))
            {
                if (targetType == typeof(PrecisionDateTime))
                {
                    return new PrecisionDateTime(defaultValue);
                }

                if (targetType == typeof(PrecisionTimeSpan))
                {
                    // We parse both TimeSpan and PrecisionTimeSpan using the TimeSpan semantics, so that we can 
                    // support the time interval specification (e.g. "0:1:23").
                    //
                    var timeSpan = TimeSpan.Parse(defaultValue);

                    return PrecisionTimeSpan.FromSeconds(timeSpan.TotalSeconds);
                }

                if (targetType == typeof(SelfTestResult))
                {
                    var parts = defaultValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    var code = Convert.ToInt32(parts[0].Trim());
                    var message = parts.Length == 2 ? parts[1].Trim() : String.Empty;

                    return new SelfTestResult(code, message);
                }

                if (targetType == typeof(ErrorQueryResult))
                {
                    var parts = defaultValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    var code = Convert.ToInt32(parts[0].Trim());
                    var message = parts.Length == 2 ? parts[1].Trim() : String.Empty;

                    return new ErrorQueryResult(code, message);
                }

                if (targetType == typeof(LockManager))
                {
                    var parts = defaultValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    var lockType = (LockType)Enum.Parse(typeof(LockType), parts[0].Trim());
                    var accessKey = parts.Length == 2 ? parts[1] : String.Empty;

                    return new LockManager(this.Root as IIviDriver, lockType, accessKey);
                }

                if (targetType.Name == "Waveform`1")
                {
                    return Activator.CreateInstance(targetType, new object[] { new PrecisionTimeSpan(defaultValue) });
                }

                if (targetType.Name == "Spectrum`1")
                {
                    var parts = defaultValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    var startFrequency = Convert.ToDouble(parts[0].Trim());
                    var stopFrequency = Convert.ToDouble(parts[1].Trim());

                    return Activator.CreateInstance(targetType, new object[] { startFrequency, stopFrequency });
                }
            }
            else if (IsIviType(targetType, "Ivi.Downconverter", "Band"))
            {
                var parts = defaultValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                var startFrequency = Convert.ToDouble(parts[0].Trim());
                var stopFrequency = Convert.ToDouble(parts[1].Trim());

                return Activator.CreateInstance(targetType, new object[] { startFrequency, stopFrequency });
            }
            else if (IsIviType(targetType, "Ivi.Scope", "MinMaxWaveform`1"))
            {
                var parts = defaultValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                var minWaveformTimeSpan = new PrecisionTimeSpan(parts[0].Trim());
                var maxWaveformTimeSpan = new PrecisionTimeSpan(parts[1].Trim());
                var minMaxWaveformTypeArgument = targetType.GetGenericArguments()[0];
                var waveformType = typeof(Waveform<>).MakeGenericType(minMaxWaveformTypeArgument);
                var minWaveform = Activator.CreateInstance(waveformType, new object[] { minWaveformTimeSpan });
                var maxWaveform = Activator.CreateInstance(waveformType, new object[] { maxWaveformTimeSpan });

                return Activator.CreateInstance(targetType, new object[] { minWaveform, maxWaveform });
            }
            else if (IsIviType(targetType, "Ivi.SpecAn", "MarkerInfo"))
            {
                var parts = defaultValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                var position = Convert.ToDouble(parts[0].Trim());
                var amplitude = Convert.ToDouble(parts[1].Trim());

                return Activator.CreateInstance(targetType, new object[] { position, amplitude });
            }
            else if (IsIviType(targetType, "Ivi.Upconverter"))
            {
                if ((targetType.Name == "FrequencyGain") || (targetType.Name == "FrequencyPower"))
                {
                    var parts = defaultValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    var frequency = Convert.ToDouble(parts[0].Trim());
                    var gainOrPower = Convert.ToDouble(parts[1].Trim());

                    return Activator.CreateInstance(targetType, new object[] { frequency, gainOrPower });
                }
            }
            else if (targetType == typeof(TimeSpan))
            {
                return TimeSpan.Parse(defaultValue);
            }
            else if (targetType == typeof(Guid))
            {
                return new Guid(defaultValue);
            }
            else if (targetType == typeof(IntPtr))
            {
                return new IntPtr(Convert.ToInt64(defaultValue));
            }
            else if (targetType == typeof(UIntPtr))
            {
                return new UIntPtr(Convert.ToUInt64(defaultValue));
            }

            return null;
        }

        static readonly byte[] IviAssemblyPublicKeyToken = new byte[] { 0xa1, 0x28, 0xc9, 0x8f, 0x1d, 0x77, 0x17, 0xc1 };

        static bool IsIviType(Type type, string iviNamespace)
        {
            var assemblyKeyToken = type.Assembly.GetName().GetPublicKeyToken();
            var isIviAssembly = (assemblyKeyToken != null) && (assemblyKeyToken.Length == IviAssemblyPublicKeyToken.Length);

            for (var n = 0; isIviAssembly && (n < IviAssemblyPublicKeyToken.Length); n++)
            {
                isIviAssembly = assemblyKeyToken[n] == IviAssemblyPublicKeyToken[n];
            }

            return isIviAssembly && (type.Namespace == iviNamespace);
        }

        private static bool IsIviType(Type type, string iviNamespace, string iviTypeName)
        {
            return IsIviType(type, iviNamespace) && (type.Name == iviTypeName);
        }

        #endregion

        /// <summary>
        /// Add the specified service.  Services are typically interfaces implemented by the driver that need to be 
        /// exposed to the end user. Services added via this method will be available in the driver's 
        /// IServiceProvider.GetService implementation.
        /// </summary>
        /// <param name="serviceIdentifier">Type for the service.  The service can later be retrieved by querying for 
        /// this same type.</param>
        /// <param name="serviceProvider">Object implementating the service.</param>
        internal void AddService(Type serviceIdentifier, object serviceProvider)
        {
            this.Services.Add(serviceIdentifier, serviceProvider);
        }

        /// <summary>
        /// Validates that the current session information does not conflict with the capabilities of the driver.  
        /// Override this method to perform
        /// customer session information validation.
        /// </summary>
        protected virtual void ValidateSessionInformation()
        {
            // Report an error if requesting interchange checking and the driver doesn't support it.
            //
            if (this.Session.InitOptions.InterchangeCheckingEnabled && !this.DriverInfo.InterchangeCheckSupported)
            {
                throw ErrorService.InvalidOptionValue("interchangecheck", "true");
            }
        }

        /// <summary>
        /// Initializes an instrument I/O communication session.  By default, this method creates a VISA.NET session.  
        /// Override this method to implement custom communication protocols.
        /// </summary>
        protected virtual void InitializeIO()
        {

#if NCL_VISANET

            var visaSession = Ivi.Visa.GlobalResourceManager.Open(this.Session.ResourceDescriptor, Ivi.Visa.AccessModes.None, this.IOTimeoutMilliseconds);

            if (visaSession == null)
            {
                throw new IOException(NclStrings.FailedToCreateVisaSession(this.Session.ResourceDescriptor));
            }

            _messageBasedSession = visaSession as Ivi.Visa.IMessageBasedSession;
            _registerBasedSession = visaSession as Ivi.Visa.IRegisterBasedSession;

#else   // NCL_VISANET

            throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented("InitializeIO"));

#endif  // NCL_VISANET

        }

        /// <summary>
        /// Clears the instrument I/O session of any errors that may exist.  By default, this method issues the 
        /// standard "*CLS" command.  Override this method to specify an alternate instrument command for clearing
        /// instrument errors.
        /// </summary>
        protected virtual void ClearIO()
        {

#if NCL_VISANET

            this.IO.FormattedIO.WriteLine("*CLS");

#else   // NCL_VISA_NET

            throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented(nameof(ClearIO)));

#endif  // NCL_VISANET

        }

        /// <summary>
        /// Closes the instrument I/O session.
        /// NOTE: This method is only available when using VISA.NET as the driver's I/O provider.
        /// </summary>
        internal virtual void CloseIO()
        {

#if NCL_VISANET

            if (this.VisaSession != null)
            {
                this.VisaSession.Dispose();
            }

#else   // NCL_VISA_NET

            throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented(nameof(CloseIO)));

#endif  // NCL_VISANET

        }

        /// <summary>
        /// This method communicates with the instrument to determine and store basic instrument characteristics, such 
        /// as the instrument manufacturer, model, serial number, and firmware revision.  By default, this method 
        /// issues the standard "*IDN?" command and parses the response.  In simulation mode, this method does nothing.
        /// Override this method for instruments that do not support the "*IDN?" query.
        /// </summary>
        protected virtual void InitializeIdentification()
        {

#if NCL_VISANET

            if (this.Session.InitOptions.SimulationEnabled)
            {
                // Nothing to do in simulation mode

                return;
            }

            if (!this.IsMessageBasedIOSession)
            {
                Debug.Fail("The InitializeIdentification method must be overridden for non-message-based I/O sessions.");
                return;
            }

            this.IO.FormattedIO.WriteLine("*IDN?");
            var id = this.IO.FormattedIO.ReadLine().Trim();

            this.PollInstrumentErrors();

            var parts = id.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length != 4)
            {
                throw ErrorService.UnexpectedResponse(NclStrings.IdnQueryParseError(id));
            }

            this.Session.InstrumentManufacturer = parts[0].Trim();
            this.Session.InstrumentModel = parts[1].Trim();
            this.Session.InstrumentSerialNumber = parts[2].Trim();
            this.Session.InstrumentFirmwareRevision = parts[3].Trim();

#else   // NCL_VISANET

            throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented(nameof(InitializeIdentification)));

#endif  // NCL_VISANET
        }

        /// <summary>
        /// Checks to see if the driver is connected to a supported instrument model, if requested by the user, or 
        /// required for correct operation.
        /// </summary>
        /// <param name="idQuery">User requested the authentication.</param>
        internal virtual void CheckInstrumentSupported()
        {
            if (!this.DriverInfo.IsModelSupported(this.Session.InstrumentModel))
            {
                throw ErrorService.IdQuery();
            }
        }

        #region IDisposable Members

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        protected void Dispose(bool disposing)
        {
            lock (this.DisposedSyncRoot)
            {
                if (this.IsDisposed)
                {
                    return;
                }

                using (((IIviDriverUtility)this).Lock())
                {
                    if (disposing)
                    {
                        CloseIO();
                    }

                    // Call down to the derived driver class to cleanup any driver-specific unmanaged resources.
                    //
                    this.CleanupUnmanagedResources();

                    this.IsDisposed = true;
                }

                if (disposing)
                {
                    this.LockManager.Dispose();
                }
            }
        }

        /// <summary>
        /// This method is invoked as part of the driver's IDisposable.Dispose implementation.  Rather than overriding 
        /// the implementation of Dispose itself, override this method to cleanup any driver-specific unmanaged 
        /// resources.  It is not necessary to override this method to cleanup driver-specific managed resources.
        /// </summary>
        protected virtual void CleanupUnmanagedResources()
        {
            // Do nothing by default
        }

        #endregion

        #region IServiceProvider Members

        /// <summary>
        /// Gets the service object of the specified type.
        /// </summary>
        /// <param name="serviceType">An object that specifies the type of service object to get.</param>
        /// <returns>A service object of type serviceType.</returns>
        public object GetService(Type serviceType)
        {
            this.Services.TryGetValue(serviceType, out object serviceProvider);

            return serviceProvider;
        }

        #endregion

        #region class DefaultImplementations

        /// <summary>
        /// This type is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        protected class DefaultImplementations
        {
            internal DefaultImplementations(Driver driver)
            {
                this.Inherent = new InherentCapabilitiesDefaultImplementation(driver);
            }

            internal InherentCapabilitiesDefaultImplementation Inherent { get; }
        }

        #endregion

        #region class InherentCapabilitiesDefaultImplementation

        internal class InherentCapabilitiesDefaultImplementation
        {
            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from  driver developer code.
            /// </summary>
            internal InherentCapabilitiesDefaultImplementation(Driver driver)
            {
                this.Driver = driver;
            }

            private Driver Driver { get; }

            private string[] SupportedInstrumentModels { get; set; }

            private string[] CapabilityGroups { get; set; }

            #region IIviDriver Members

            /// <summary>
            /// Reference to the IIviDriverOperation interface.
            /// </summary>
            internal IIviDriverOperation DriverOperation => (IIviDriverOperation)this.Driver;

            /// <summary>
            /// Reference to the IIviDriverIdentity interface.
            /// </summary>
            internal IIviDriverIdentity Identity => (IIviDriverIdentity)this.Driver;

            /// <summary>
            /// Reference to the IIviDriverUtility interface.
            /// </summary>
            internal IIviDriverUtility Utility => (IIviDriverUtility)this.Driver;

            /// <summary>
            /// Closes the I/O session to the instrument, as well as other unmanaged resources.
            /// The behavior is the same as IDisposable.Dispose.
            /// </summary>
            internal void Close()
            {
                this.Driver.Dispose(true);
            }

            #endregion

            #region IIviDriverOperation Members

            /// <summary>
            /// Logical Name identifies a driver session in the Configuration Store.  If Logical Name is not empty, the
            /// driver was initialized from  information in the driver session.  If it is empty, the driver was 
            /// initialized without using the Configuration Store.
            /// </summary>
            internal string LogicalName => this.Driver.Session.LogicalName;

            /// <summary>
            /// The resource descriptor specifies the connection to a physical device.  It is either specified in the 
            /// Configuration Store or passed in the ResourceName parameter of the Initialize function.  It is empty if
            /// the driver is not initialized.
            /// </summary>
            internal string IOResourceDescriptor => this.Driver.Session.ResourceDescriptor;

            /// <summary>
            /// The driver setup string.  It is either specified in the Configuration Store or passed in the 
            /// OptionString parameter of the Initialize function.  Driver setup is empty if the driver is not 
            /// initialized.
            /// </summary>
            internal string DriverSetup => this.Driver.Session.DriverSetupString;

            /// <summary>
            /// Drivers may choose to always cache some instrument settings, never cache others, and optionally cache
            /// others, to avoid unecessary I/O to the instrument.  If True, the driver caches optionally cached 
            /// instrument settings.
            /// </summary>
            internal bool Cache
            {
                get => this.Driver.Session.InitOptions.CachingEnabled;
                set => this.Driver.Session.InitOptions.CachingEnabled = value;
            }

            /// <summary>
            /// If True, the driver queries the instrument status at the end of each method or property that performs 
            /// I/O to the instrument.  If an error is reported, use ErrorQuery to retrieve error messages one at a 
            /// time from the instrument.
            /// </summary>
            internal bool QueryInstrumentStatus
            {
                get => this.Driver.Session.InitOptions.QueryInstrumentStatusEnabled;
                set => this.Driver.Session.InitOptions.QueryInstrumentStatusEnabled = value;
            }

            /// <summary>
            /// Drivers may choose to always validate some property/parameter values, never validate others, and 
            /// optionally validate others, to avoid sending invalid commands to the instrument.  If True, the driver
            /// performs optional validations.
            /// </summary>
            internal bool RangeCheck
            {
                get => this.Driver.Session.InitOptions.RangeCheckingEnabled;
                set => this.Driver.Session.InitOptions.RangeCheckingEnabled = value;
            }

            /// <summary>
            /// If True, the driver does not perform I/O to the instrument, and returns simulated values for output 
            /// parameters.
            /// </summary>
            internal bool Simulate
            {
                get => this.Driver.Session.InitOptions.SimulationEnabled;
                set
                {
                    // Check if the user is trying to turn off simulation when the driver was initialized in simulation
                    // mode.
                    //
                    if (value == false && this.Driver.Session.InitOptions.SimulationEnabled && this.Driver.Session.OriginalInitOptions.SimulationEnabled)
                    {
                        throw ErrorService.SimulationState();
                    }

                    this.Driver.Session.InitOptions.SimulationEnabled = value;
                }
            }

            /// <summary>
            /// Resets the interchangeability checking algorithms of the driver so that methods and properties that 
            /// executed prior to calling this function have no affect on whether future calls to the driver generate 
            /// interchangeability warnings.
            /// </summary>
            internal void ResetInterchangeCheck()
            {
                throw ErrorService.OperationNotSupported("IIviDriverOperation", nameof(ResetInterchangeCheck));
            }

            /// <summary>
            /// Invalidates all of the driver's cached values.
            /// </summary>
            internal void InvalidateAllAttributes()
            {
                this.Driver.InvalidateAllCacheEntries();
            }

            #endregion

            #region IIviDriverIdentity Members

            /// <summary>
            /// The name of the manufacturer reported by the physical instrument. If Simulation is enabled, this 
            /// property returns the following:
            /// "The 'InstrumentManufacturer' operation is not available while in simulation mode.".
            /// </summary>
            internal string InstrumentManufacturer
                => this.Driver.Session.InitOptions.SimulationEnabled
                    ? NclStrings.OperationNotAvailableInSimulationMode(nameof(InstrumentManufacturer))
                    : this.Driver.Session.InstrumentManufacturer;

            /// <summary>
            /// The model number or name reported by the physical instrument. If Simulation is enabled or the 
            /// instrument is not capable of reporting the model number or name, a string is returned that  explains
            /// the condition.  Model is limited to 256 bytes.
            /// </summary>
            internal string InstrumentModel => this.Driver.Session.InstrumentModel;

            /// <summary>
            /// The firmware revision reported by the physical instrument.  If Simulation is enabled, this property 
            /// returns the following: "The 'InstrumentFirmwareRevision' operation is not available while in simulation
            /// mode.".
            /// </summary>
            internal string InstrumentFirmwareRevision
                => this.Driver.Session.InitOptions.SimulationEnabled
                    ? NclStrings.OperationNotAvailableInSimulationMode(nameof(InstrumentFirmwareRevision))
                    : this.Driver.Session.InstrumentFirmwareRevision;

            /// <summary>
            /// The case-sensitive unique identifier of the implementing IVI.NET instrument driver.
            /// </summary>
            internal string Identifier => this.Driver.DriverInfo.DriverIdentifier;

            /// <summary>
            /// Returns the list of instrument models that the IVI specific driver can control.  The string does not 
            /// include an abbreviation for the manufacturer if it is the same for all models.
            /// </summary>
            /// <returns>Array of instrument models.</returns>
            internal string[] GetSupportedInstrumentModels()
            {
                return this.SupportedInstrumentModels
                                   ?? (this.SupportedInstrumentModels = new List<string>(this.Driver.DriverInfo.GetAllSupportedModels()).ToArray());
            }

            /// <summary>
            /// For IVI class-compliant drivers, the major version number of the instrument class specification.  If 
            /// the driver is not class compliant, the driver returns zero.
            /// </summary>
            internal int SpecificationMajorVersion => this.Driver.DriverInfo.SpecificationMajorVersion;

            /// <summary>
            /// For IVI class-compliant drivers, the minor version number of the instrument class specification.  If 
            /// the driver is not class compliant, the driver returns zero.
            /// </summary>
            internal int SpecificationMinorVersion => this.Driver.DriverInfo.SpecificationMinorVersion;

            /// <summary>
            /// Returns the list of the class capability groups implemented by the driver.  Capability group names are
            /// documented in the IVI class specifications.  If the driver is not class compliant, the driver returns 
            /// an empty array.
            /// </summary>
            /// <returns>Array of class capability groups.</returns>
            internal string[] GetGroupCapabilities()
            {
                return this.CapabilityGroups
                                   ?? (this.CapabilityGroups = new List<string>(this.Driver.DriverInfo.CapabilityGroups).ToArray());
            }

            #endregion

            #region IIviComponentIdentity Members

            /// <summary>
            /// A brief description of the implementing component.
            /// </summary>
            internal string Description => this.Driver.DriverInfo.DriverDescription;

            /// <summary>
            /// The revision of the implementing component.  Refer to IVI 3.1, Section 3.1.2.2, for a description of 
            /// revision syntax and semantics.  Revision is limited to 256 bytes.
            /// </summary>
            internal string Revision => this.Driver.DriverInfo.DriverRevision;

            /// <summary>
            /// The name of the vendor that supplies the implementing component. Vendor is limited to 256 bytes.
            /// </summary>
            internal string Vendor => this.Driver.DriverInfo.DriverVendor;

            #endregion

            #region IIviDriverUtility Members

            /// <summary>
            /// Queries the instrument and returns instrument specific error information.  This function can be used when QueryInstrumentStatus 
            /// is True to retrieve error details when the driver detects an instrument error.
            /// </summary>
            /// <returns>Error query result code and message.</returns>
            internal ErrorQueryResult ErrorQuery()
            {

#if NCL_VISANET
                var code = 0;
                var message = NclStrings.ErrorQueryNoError;

                if (this.Driver.Session.InitOptions.SimulationEnabled)
                {
                    // Nothing to do in simulation mode

                    return new ErrorQueryResult(code, message);
                }

                if (!this.Driver.IsMessageBasedIOSession)
                {
                    Debug.Fail("The InstrumentErrorQuery method must be overridden for non-message-based I/O sessions.");

                    return new ErrorQueryResult(-1, NclStrings.CouldNotPerformErrorQuery);
                }

                this.Driver.IO.FormattedIO.WriteLine("SYST:ERR?");
                var result = this.Driver.IO.FormattedIO.ReadLine();

                this.Driver.PollInstrumentErrors();

                result = result.Trim(' ', '\n', '\r', '"');

                var index = result.IndexOf(',');

                if (index < 0)
                {
                    throw ErrorService.UnexpectedResponse(NclStrings.ErrorQueryParseError(result));
                }

                var codeText = result.Substring(0, index).Trim();
                var messageText = result.Substring(index + 1).Trim();

                if (!Int32.TryParse(codeText, out code))
                {
                    throw ErrorService.UnexpectedResponse(NclStrings.ErrorQueryParseError(result));
                }

                message = messageText.Trim(' ', '\n', '\r', '"');

                return new ErrorQueryResult(code, message);

#else   // NCL_VISANET

                throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented(nameof(ErrorQuery)));

#endif  // NCL_VISANET

            }

            /// <summary>
            /// Performs an instrument self test, waits for the instrument to complete the test, and queries the instrument for the results.  
            /// If the instrument passes the test, TestResult is zero and TestMessage is 'Self test passed'.
            /// </summary>
            /// <returns>Self test result code and message.</returns>
            internal SelfTestResult SelfTest()
            {

#if NCL_VISANET

                var code = 0;
                var message = NclStrings.SelfTestPassed;

                if (this.Driver.Session.InitOptions.SimulationEnabled)
                {
                    // Nothing to do in simulation mode

                    return new SelfTestResult(code, message);
                }

                if (!this.Driver.IsMessageBasedIOSession)
                {
                    Debug.Fail("The SelfTest method must be overridden for non-message-based I/O sessions.");

                    return new SelfTestResult(-1, NclStrings.CouldNotPerformSelfTest);
                }

                this.Driver.IO.FormattedIO.WriteLine("*TST?");

                using (new VisaTimeoutManager(this.Driver.VisaSession, this.Driver.SelfTestTimeoutMilliseconds))
                {
                    var result = this.Driver.IO.FormattedIO.ReadLine();

                    this.Driver.PollInstrumentErrors();

                    var codeText = result;

                    // Format of response is:
                    //
                    //	<code>[,message]
                    //
                    //  where [,message] is optional
                    //
                    var index = result.IndexOf(',');

                    if (index > 0)
                    {
                        // A message field was received
                        //
                        codeText = result.Substring(0, index).Trim();
                        message = result.Substring(index + 1).Trim(' ', '"');
                    }

                    if (!Int32.TryParse(codeText, out code))
                    {
                        throw ErrorService.UnexpectedResponse(NclStrings.SelfTestParseError(result));
                    }
                }

                return new SelfTestResult(code, message);

#else   // NCL_VISANET

                throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented(nameof(SelfTest)));

#endif  // NCL_VISANET

            }

            /// <summary>
            /// Quickly places the instrument in a state where it has no, or minimal, effect on the external system to which it is connected.  
            /// This state is not necessarily a known state.
            /// </summary>
            internal void Disable()
            {

#if NCL_VISANET

                if (this.Driver.Session.InitOptions.SimulationEnabled)
                {
                    // Nothing to do in simulation mode

                    return;
                }

                if (!this.Driver.IsMessageBasedIOSession)
                {
                    Debug.Fail("The InstrumentDisable method must be overridden for non-message-based I/O sessions.");

                    return;
                }

                this.Driver.IO.FormattedIO.WriteLine("*RST;*OPC?");

                using (new VisaTimeoutManager(this.Driver.VisaSession, this.Driver.ResetTimeoutMilliseconds))
                {
                    this.Driver.IO.FormattedIO.ReadLine();
                }

                this.Driver.PollInstrumentErrors();

#else   // NCL_VISANET

                throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented(nameof(Disable)));

#endif  // NCL_VISANET

            }

            /// <summary>
            /// Does the equivalent of Reset and then, (1) disables class extension capability groups, (2) sets attributes to initial 
            /// values defined by class specs, and (3) configures the driver to the option string settings used when Initialize was last executed.
            /// </summary>
            internal void ResetWithDefaults()
            {
                (this.Driver as IIviDriverUtility).Reset();

                this.Driver.Session.RestoreInitialOptions();
            }

            /// <summary>
            /// Places the instrument in a known state and configures instrument options on which the IVI specific driver depends (for example, 
            /// enabling/disabling headers).  For an IEEE 488.2 instrument, Reset sends the command string *RST to the instrument.
            /// </summary>
            internal void Reset()
            {
                if (!this.Driver.DriverInfo.ResetSupported)
                {
                    throw ErrorService.ResetNotSupported();
                }

#if NCL_VISANET

                if (this.Driver.Session.InitOptions.SimulationEnabled)
                {
                    // Nothing to do in simulation mode
                    //
                    return;
                }

                if (!this.Driver.IsMessageBasedIOSession)
                {
                    Debug.Fail("The ResetInstrument method must be overridden for non-message-based I/O sessions.");
                    return;
                }

                this.Driver.IO.FormattedIO.WriteLine("*RST;*OPC?");

                using (new VisaTimeoutManager(this.Driver.VisaSession, this.Driver.ResetTimeoutMilliseconds))
                {
                    this.Driver.IO.FormattedIO.ReadLine();
                }

                this.Driver.PollInstrumentErrors();

                this.Driver.ResetObjectState();
                this.Driver.InvalidateAllCacheEntries();

                // From the IVI specs:
                //		"If an IVI specific driver performs interchangeability checking, the specific driver shall record an interchangeability warning when  the user calls the Reset function."
                //
                if (this.Driver.DriverInfo.InterchangeCheckSupported)
                {
                    this.Driver.SendInterchangeEvent(new InterchangeCheckWarningEventArgs("Reset"));
                }

#else
                throw new NotImplementedException(NclStrings.IOFunctionMustBeManuallyImplemented(nameof(Reset)));

#endif  // NCL_VISANET

            }

            /// <summary>
            /// Attempts to acquire a synchronization lock on this instance of the driver. The calling thread is blocked indefinitely until the lock is acquired. This
            /// method is useful for gaining exclusive access to the driver instance across a series of methods calls. The user must call the Unlock method on the returned
            /// lock to relinquish the lock and allow other threads to access this instance of the driver.
            /// </summary>
            /// <returns>A reference to the acquired lock.</returns>
            internal IIviDriverLock Lock()
            {
                return this.Driver.LockManager.Lock();
            }

            /// <summary>
            /// Attempts to acquire a synchronization lock on this instance of the driver. The calling thread is blocked until either the lock is acquired or maxTime
            /// expires. If the lock is not acquired within the interval specified by maxTime, an exception is thrown. This method is useful for gaining exclusive access
            /// to the driver instance across a series of methods calls. The user must call the Unlock method on the returned lock to relinquish the lock and allow other
            /// threads to access this instance of the driver.
            /// </summary>
            /// <param name="maxTime">Specifies the maximum amount of time to wait to acquire the lock.</param>
            /// <returns>A reference to the acquired lock.</returns>
            internal IIviDriverLock Lock(PrecisionTimeSpan maxTime)
            {
                return this.Driver.LockManager.Lock(maxTime);
            }

            #endregion
        }

        #endregion

        #region class Cache

        /// <summary>
        /// Container for cache entries.
        /// </summary>
        internal class Cache
        {
            private Dictionary<string, CacheEntry> Entries { get; } = new Dictionary<string, CacheEntry>();

            /// <summary>
            /// Stores a cache of keys since creating the keys can be expensive.  The Dictionary maps a MethodInfo to a
            /// Dictionary of keys since a single method can be called on multiple repcap instances, thereby yielding 
            /// multiple keys.
            /// </summary>
            private Dictionary<MethodInfo, Dictionary<DriverNode, string>> Keys { get; } = new Dictionary<MethodInfo, Dictionary<DriverNode, string>>();

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal string LookupKey(MethodInfo meth, DriverNode node)
            {
                if (this.Keys.TryGetValue(meth, out var keysForMeth))
                {
                    if (keysForMeth.TryGetValue(node, out var key))
                    {
                        return key;
                    }
                }

                return null;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal string CreateKey(MethodInfo propertyAccessor, DriverNode node)
            {
                // Method must be either the getter or setter for a property and should be named "get_Prop" or 
                // "set_Prop".
                //
                var propName = propertyAccessor.Name;
                var indexOfInterfaceQualifier = propName.LastIndexOf('.');

                if (indexOfInterfaceQualifier != -1)
                {
                    propName = propName.Substring(indexOfInterfaceQualifier + 1);
                }

                if (!propertyAccessor.IsSpecialName || (!propName.StartsWith("get_", StringComparison.Ordinal) && !propName.StartsWith("set_", StringComparison.Ordinal)))
                {
                    throw new ArgumentException(NclStrings.CouldNotCreateCacheKeyForMethod(propertyAccessor.DeclaringType.Name, propertyAccessor.Name));
                }

                // Lop off the leading "get_" or "set_" so we're left with just the property's unadorned name.
                //
                propName = propName.Substring("get_".Length);

                // General format of the key is:
                //
                //		Channel[CH5].Trace[TRACE2].IAcme4321Acquisition.Frequency
                //
                var key = new StringBuilder((node as IDriverNode).CacheKeyPrefix);
                var intf = GetInterfaceImplementedByMethod(propertyAccessor, true);
                var keyResult = key.AppendFormat("{0}.{1}", intf.Name, propName).ToString();

                // Add the newly created key to the cache of keys
                //
                if (!this.Keys.TryGetValue(propertyAccessor, out var keysForProp))
                {
                    keysForProp = new Dictionary<DriverNode, string>();

                    this.Keys.Add(propertyAccessor, keysForProp);

                    // If there is an accompanying setter method defined on the same property as this getter method 
                    // (or vice-versa), make the computed key available for the accompanying accessor.
                    //
                    var accompanyingAccessor = GetAccompanyingPropertyAccessor(propertyAccessor);

                    if (accompanyingAccessor != null)
                    {
                        this.Keys.Add(accompanyingAccessor, keysForProp);
                    }
                }

                keysForProp.Add(node, keyResult);

                return keyResult;
            }

            private static MethodInfo GetAccompanyingPropertyAccessor(MethodInfo meth)
            {
                foreach (var prop in meth.DeclaringType.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly))
                {
                    var propertyGetter = prop.GetGetMethod(true);
                    var propertySetter = prop.GetSetMethod(true);

                    if (propertyGetter == meth)
                    {
                        return propertySetter;
                    }

                    if (propertySetter == meth)
                    {
                        return propertyGetter;
                    }
                }

                return null;
            }

            internal string GetOrCreateKey(MethodInfo meth, DriverNode node)
            {
                return this.LookupKey(meth, node) ?? this.CreateKey(meth, node);
            }

            internal static IEnumerable<string> ExpandCacheEntryKey(string key, MethodInfo callingMethod, DriverNode callingNode)
            {
                // There are 3 possibilities for the format of the cached property key:
                //
                //	(1) Channel[*].Trace[TRACE2].IAcme4321Acquisition.Frequency
                //	(2) IAcme4321Acquisition.Frequency
                //		- if the specified interface portion of the key is implemented by the calling node refers to 
                //        the Frequency property on the specified interface on the same driver node instance as the caller 
                //		- else
                //			refers to the Frequency property on the specified interface on the calling nodes's root node
                //	(3) Frequency
                //		- refers to the Frequency property on the same interface on the same driver node instance as 
                //        the calling node
                //
                var keyParts = key.Split(new[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
                var callingNodeCacheKeyPrefix = (callingNode as IDriverNode).CacheKeyPrefix;

                Debug.Assert(keyParts.Length > 0);

                if (keyParts.Length == 1)
                {
                    // This is scenario (3).
                    //
                    var fullKey = new StringBuilder(callingNodeCacheKeyPrefix);
                    var callerInterface = GetInterfaceImplementedByMethod(callingMethod, false);
                    var intfName = callerInterface != null ? callerInterface.Name : String.Empty;

                    if (!String.IsNullOrEmpty(intfName))
                    {
                        fullKey.Append(intfName);
                        fullKey.Append('.');
                    }

                    fullKey.Append(key);

                    yield return fullKey.ToString();
                }
                else if (keyParts.Length == 2)
                {
                    // This is scenario (2).
                    //
                    var intfName = keyParts[0];
                    var nodeCacheKeyPrefix = GetNodeCacheKeyPrefixForInterface(callingNode, callingMethod, intfName);

                    yield return nodeCacheKeyPrefix + key;
                }
                else
                {
                    // This is scenario (1).
                    //
                    var keyNeedsExpansion = RepCapSelectorNeedsExpansion(key);

                    if (!keyNeedsExpansion)
                    {
                        // No expansion needed for repcap instances.
                        //
                        yield return key;
                    }
                    else
                    {
                        // One or more components of the key indicates the need to be expanded to specify all repcap 
                        // physical names in place of *.
                        //
                        var intfName = keyParts[keyParts.Length - 2];
                        var propName = keyParts[keyParts.Length - 1];

                        foreach (var keyPrefix in GetRepCapCacheKeyPrefixes(callingNode.Root, keyParts, currentIndex: 0))
                        {
                            yield return $"{keyPrefix}{intfName}.{propName}";
                        }
                    }
                }
            }

            private static bool RepCapSelectorNeedsExpansion(string selector)
            {
                return selector.IndexOfAny(s_SelectorExpansionTriggers) != -1;
            }

            private static readonly char[] s_SelectorExpansionTriggers = new[] { '*', ',', '-' };

            private static IEnumerable<string> GetRepCapCacheKeyPrefixes(DriverNode currentNode, string[] keyParts, int currentIndex)
            {
                if (currentIndex == keyParts.Length - 2)
                {
                    yield break;
                }

                var keyPart = keyParts[currentIndex];
                var indexerStart = keyPart.IndexOf('[');

                Debug.Assert(indexerStart != -1);

                if (indexerStart == -1)
                {
                    yield break;
                }

                var repCapName = keyPart.Substring(0, indexerStart);

                foreach (var repCapCollection in currentNode.CollectionStyleRepCaps.Values)
                {
                    if (repCapCollection.RepCapName == repCapName)
                    {
                        var repCapSelector = keyPart.Substring(indexerStart + 1).TrimEnd(']');
                        List<string> physicalNames = null;

                        if (repCapSelector == "*")
                        {
                            // The * syntax is not supported by RepCapSelector.Parse, so we don't want to parse/expand 
                            // it below.
                        }
                        else if (RepCapSelectorNeedsExpansion(repCapSelector))
                        {
                            // Need to match one of a specific set of physical names.
                            //
                            var selector = RepCapSelector.Parse(repCapSelector);
                            physicalNames = new List<string>(RepCapSelector.ExpandToPhysicalNames(selector, sessionInfo: null));
                        }
                        else
                        {
                            // Need to match a single specific physical name.
                            //
                            physicalNames = new List<string>(new[] { repCapSelector });
                        }

                        foreach (var repCap in repCapCollection.GetNodes())
                        {
                            if ((repCapSelector == "*") || ((physicalNames != null) && physicalNames.Contains(repCap.PhysicalName)))
                            {
                                var keyPrefixesToRight = new List<string>(GetRepCapCacheKeyPrefixes(repCap, keyParts, currentIndex + 1));

                                if (keyPrefixesToRight.Count == 0)
                                {
                                    yield return (repCap as IDriverNode).CacheKeyPrefix;
                                }
                                else
                                {
                                    foreach (var keyPrefixToRight in keyPrefixesToRight)
                                    {
                                        yield return keyPrefixToRight;
                                    }
                                }
                            }
                        }

                        break;
                    }
                }
            }

            private static Type GetInterfaceImplementedByMethod(MethodInfo implMeth, bool throwOnError)
            {
                // We need to find the interface that declares this member
                //
                var implType = implMeth.DeclaringType;

                foreach (var intf in implType.GetInterfaces())
                {
                    var mapping = implType.GetInterfaceMap(intf);

                    foreach (var targetMeth in mapping.TargetMethods)
                    {
                        if (targetMeth == implMeth)
                        {
                            return intf;
                        }
                    }
                }

                if (throwOnError)
                {
                    var propName = implMeth.Name.Substring("get_".Length);

                    throw new ArgumentException(NclStrings.CouldNotCreateCacheKeyForProperty(implType.Name, propName));
                }

                return null;
            }

            private static string GetNodeCacheKeyPrefixForInterface(IDriverNode node, MethodInfo meth, string interfaceName)
            {
                // Scan the set of interfaces implemented by the declaring type for this method on the specified node.  
                // If the specified interface is implemented by the specified node, return the specified node's cache 
                // key prefix.
                //
                var implType = meth.DeclaringType;

                foreach (var intf in implType.GetInterfaces())
                {
                    if (intf.Name == interfaceName)
                    {
                        return node.CacheKeyPrefix;
                    }
                }

                // The specified interface is not implemented by the specifeid node, so return cache key prefix of the 
                // specified node's root.
                //
                return node.Root.CacheKeyPrefix;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal bool CacheContainsValue(MethodInfo meth, DriverNode node, object value)
            {
                if (GetValue(meth, node, out object existingValue))
                {
                    if (existingValue is ICacheEquatable equatable)
                    {
                        return equatable.IsEqualTo(value);
                    }
                    // The cached data has to be a type we know how to compare.
                    //
                    switch (Type.GetTypeCode(value.GetType()))
                    {
                        case TypeCode.Single:
                            return AlmostEqual((double)(float)value, (double)(float)existingValue);

                        case TypeCode.Double:
                            return AlmostEqual((double)value, (double)existingValue);

                        default:
                            if (existingValue is IComparable comparable)
                            {
                                return comparable.CompareTo(value) == 0;
                            }

                            Debug.Fail("Unsupported data type for caching.");
                            return false;
                    }
                }

                return false;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal bool GetValue<T>(MethodInfo meth, DriverNode node, out T value)
            {
                value = default;

                var key = LookupKey(meth, node);

                if (key != null)
                {
                    if (this.Entries.TryGetValue(key, out var entry) && entry.IsValid)
                    {
                        value = (T)entry.Value;

                        return true;
                    }
                }

                return false;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal bool GetValue<T>(string key, MethodInfo callingMethod, DriverNode callingNode, out T value)
            {
                value = default;

                var fullKeys = new List<string>(ExpandCacheEntryKey(key, callingMethod, callingNode));

                if (fullKeys.Count == 0)
                {
                    throw new ArgumentException(NclStrings.CacheKeySyntaxError(key));
                }

                if (fullKeys.Count > 1)
                {
                    throw new ArgumentException(NclStrings.OperationRequiresSingleEntryCacheKey);
                }

                if (this.Entries.TryGetValue(fullKeys[0], out var entry) && entry.IsValid)
                {
                    value = (T)entry.Value;

                    return true;
                }

                return false;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal void UpdateEntry(MethodInfo meth, DriverNode node, object value)
            {
                var key = GetOrCreateKey(meth, node);

                this.UpdateOrCreateEntry(key, value);
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal void UpdateEntry(string key, MethodInfo meth, DriverNode node, object value)
            {
                var fullKeys = new List<string>(ExpandCacheEntryKey(key, meth, node));

                if (fullKeys.Count == 0)
                {
                    throw new ArgumentException(NclStrings.CacheKeySyntaxError(key));
                }

                if (fullKeys.Count > 1)
                {
                    throw new ArgumentException(NclStrings.OperationRequiresSingleEntryCacheKey);
                }

                this.UpdateOrCreateEntry(fullKeys[0], value);
            }

            private void UpdateOrCreateEntry(string key, object value)
            {
                if (!this.Entries.TryGetValue(key, out var entry))
                {
                    // Entry does not yet exist, so create it.
                    //
                    entry = new CacheEntry();

                    this.Entries.Add(key, entry);
                }

                entry.IsValid = true;
                entry.Value = value;
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal void InvalidateEntry(string key, MethodInfo meth, DriverNode node)
            {
                foreach (var fullKey in ExpandCacheEntryKey(key, meth, node))
                {
                    if (this.Entries.TryGetValue(fullKey, out var entry))
                    {
                        entry.IsValid = false;
                    }
                }
            }

            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from driver developer code.
            /// </summary>
            internal void InvalidateAll()
            {
                this.Entries.Clear();
            }

            /// <summary>
            /// This class is for internal use of the Nimbus Class Library and is not intended to be used directly in 
            /// driver developer code.
            /// </summary>
            private class CacheEntry
            {
                /// <summary>
                /// This member is for internal use of the Nimbus Class Library and is not intended to be called 
                /// directly from driver developer code.
                /// </summary>
                internal object Value { get; set; }

                /// <summary>
                /// This member is for internal use of the Nimbus Class Library and is not intended to be called 
                /// directly from driver developer code.
                /// </summary>
                internal bool IsValid { get; set; }
            }
        }

        #endregion

#if NCL_VISANET

        #region class TypeFormatter

        internal class TypeFormatter : Ivi.Visa.ITypeFormatter
        {
            /// <summary>
            /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly 
            /// from  driver developer code.
            /// </summary>
            internal TypeFormatter(string model)
            {
                if (model == null) throw new ArgumentNullException(nameof(model));

                this.Model = model;
                this.EnumValueToCommandMaps = new Dictionary<Type, Dictionary<int, Dictionary<string, string>>>();
                this.CommandToEnumValuesMaps = new Dictionary<Type, Dictionary<string, int>>();
                this.BooleanTrueCommands = new List<string>();
                this.BooleanFalseCommands = new List<string>();

                var driverAsm = Assembly.GetExecutingAssembly();
                var attrs = driverAsm.GetCustomAttributes(typeof(SCPICompliantAttribute), false);

                if (attrs.Length > 0)
                {
                    var attr = (SCPICompliantAttribute)attrs[0];
                    this.SCPICompliant = attr.Compliant;
                }

                this.LoadBooleanCommands();
            }

            private string Model { get; set; }

            private Dictionary<Type /*enum*/, Dictionary<int /*value*/, Dictionary<string /*model*/, string /*command*/>>> EnumValueToCommandMaps { get; set; }

            private Dictionary<Type /*enum*/, Dictionary<string /*command*/, int /*value*/>> CommandToEnumValuesMaps { get; set; }

            private IList<string> BooleanTrueCommands { get; set; }

            private IList<string> BooleanFalseCommands { get; set; }

            private bool IgnoreBooleanCommandCase { get; set; }

            private bool SCPICompliant { get; set; }

            #region ITypeFormatter Members

            bool Ivi.Visa.ITypeFormatter.IsSupported(Type type)
            {
                if (type == null) throw new ArgumentNullException(nameof(type));

                return type == typeof(bool) ||
                    type == typeof(TimeSpan) ||
                    type == typeof(PrecisionTimeSpan) ||
                    this.GetCommandToEnumValueMap(type) != null;
            }

            string Ivi.Visa.ITypeFormatter.ToString(object obj)
            {
                if (obj == null) throw new ArgumentNullException(nameof(obj));

                var command = String.Empty;
                var objectType = obj.GetType();

                if (objectType == typeof(bool))
                {
                    var value = (bool)obj;

                    if (value)
                    {
                        if (this.BooleanTrueCommands.Count == 0)
                        {
                            throw new Ivi.Visa.TypeFormatterException(obj);
                        }

                        return this.BooleanTrueCommands[0];
                    }
                    else
                    {
                        if (this.BooleanFalseCommands.Count == 0)
                        {
                            throw new Ivi.Visa.TypeFormatterException(obj);
                        }

                        return this.BooleanFalseCommands[0];
                    }
                }
                else if (objectType == typeof(TimeSpan))
                {
                    var value = (TimeSpan)obj;

                    return value.TotalSeconds.ToString();
                }
                else if (objectType == typeof(PrecisionTimeSpan))
                {
                    var value = (PrecisionTimeSpan)obj;

                    return value.TotalSeconds.ToString();
                }
                else if (objectType.IsEnum)
                {
                    var value = Convert.ToInt32(obj, CultureInfo.InvariantCulture);
                    var valueMap = this.GetEnumValueToCommandMap(objectType);

                    if (valueMap == null)
                    {
                        throw new Ivi.Visa.TypeFormatterException(obj);
                    }

                    Dictionary<string, string> modelMap;

                    if (!valueMap.TryGetValue(value, out modelMap))
                    {
                        throw new Ivi.Visa.TypeFormatterException(obj);
                    }

                    if (!modelMap.TryGetValue(this.Model, out command))
                    {
                        // No model-specific command exists for the current model, so use the default command.
                        //
                        if (!modelMap.TryGetValue(String.Empty, out command))
                        {
                            throw new Ivi.Visa.TypeFormatterException(obj);
                        }
                    }

                    return command;
                }

                throw new Ivi.Visa.TypeFormatterException(objectType);
            }

            object Ivi.Visa.ITypeFormatter.Parse(Type objectType, string data)
            {
                if (objectType == null) throw new ArgumentNullException(nameof(objectType));
                if (String.IsNullOrEmpty(data)) throw new ArgumentNullException(nameof(data));

                data = data.Trim();

                if (objectType == typeof(bool))
                {
                    var comparison = this.IgnoreBooleanCommandCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;

                    foreach (var command in this.BooleanTrueCommands)
                    {
                        if (String.Equals(command, data, comparison))
                        {
                            return true;
                        }
                    }

                    foreach (var command in this.BooleanFalseCommands)
                    {
                        if (String.Equals(command, data, comparison))
                        {
                            return false;
                        }
                    }
                }
                else if (objectType == typeof(TimeSpan))
                {
                    double value;

                    if (Double.TryParse(data, out value))
                    {
                        return TimeSpan.FromSeconds(value);
                    }
                }
                else if (objectType == typeof(PrecisionTimeSpan))
                {
                    double value;

                    if (Double.TryParse(data, out value))
                    {
                        return PrecisionTimeSpan.FromSeconds(value);
                    }
                }
                else if (objectType.IsEnum)
                {
                    var commandToValueMap = this.GetCommandToEnumValueMap(objectType);

                    if (commandToValueMap == null)
                    {
                        throw new Ivi.Visa.TypeFormatterException(objectType);
                    }

                    int value;

                    if (!commandToValueMap.TryGetValue(data, out value))
                    {
                        // If IgnoreCase was set to true for this entry, then the command would have also been stored 
                        // in the map in lowercase.
                        //
                        if (!commandToValueMap.TryGetValue(data.ToLower(CultureInfo.InvariantCulture), out value))
                        {
                            throw new Ivi.Visa.TypeFormatterException(objectType, data);
                        }
                    }

                    return (Enum)Enum.ToObject(objectType, value);
                }

                throw new Ivi.Visa.TypeFormatterException(objectType);
            }

            private Dictionary<int, Dictionary<string, string>> GetEnumValueToCommandMap(Type enumType)
            {
                Dictionary<int, Dictionary<string, string>> map;

                if (!this.EnumValueToCommandMaps.TryGetValue(enumType, out map))
                {
                    this.LoadCommandsForEnum(enumType);
                    this.EnumValueToCommandMaps.TryGetValue(enumType, out map);
                }

                return map;
            }

            private Dictionary<string, int> GetCommandToEnumValueMap(Type enumType)
            {
                Dictionary<string, int> map;

                if (!this.CommandToEnumValuesMaps.TryGetValue(enumType, out map))
                {
                    this.LoadCommandsForEnum(enumType);
                    this.CommandToEnumValuesMaps.TryGetValue(enumType, out map);
                }

                return map;
            }

            private void LoadCommandsForEnum(Type enumType)
            {
                var driverAsm = Assembly.GetExecutingAssembly();

                if (enumType.Assembly == driverAsm)
                {
                    this.LoadCommandsForDriverDefinedEnum(enumType);
                }
                else
                {
                    this.LoadCommandsForExternalEnum(enumType, driverAsm);
                }
            }

            private void LoadCommandsForDriverDefinedEnum(Type enumType)
            {
                // The command attributes are on the enum itself
                //
                var valueToCommandMap = new Dictionary<int /*value*/, Dictionary<string /*model*/, string /*command*/>>();
                var commandToValueMap = new Dictionary<string /*command*/, int /*value*/>(StringComparer.OrdinalIgnoreCase);

                foreach (FieldInfo fi in enumType.GetFields())
                {
                    if (fi.FieldType.BaseType.UnderlyingSystemType.FullName != "System.Enum")
                    {
                        // This is a non-member field on the enum.
                        //
                        continue;
                    }

                    foreach (CommandAttribute attr in fi.GetCustomAttributes(typeof(CommandAttribute), false))
                    {
                        var member = fi.GetValue(enumType) as Enum;

                        if (member == null)
                        {
                            throw new Ivi.Visa.TypeFormatterException(member);
                        }

                        var value = Convert.ToInt32(member, CultureInfo.InvariantCulture);

                        Dictionary<string, string> modelMap;

                        if (!valueToCommandMap.TryGetValue(value, out modelMap))
                        {
                            // No attributes have yet been found for this member.
                            //
                            modelMap = new Dictionary<string, string>();

                            valueToCommandMap.Add(value, modelMap);
                        }

                        if (attr.Models.Length > 0)
                        {
                            foreach (var model in attr.Models)
                            {
                                modelMap.Add(model, SimplifyCommandIfScpiCompliant(attr.Command));
                            }
                        }
                        else
                        {
                            modelMap.Add(String.Empty, SimplifyCommandIfScpiCompliant(attr.Command));
                        }

                        commandToValueMap.Add(attr.Command, value);

                        var simplifiedCommand = SimplifyCommandIfScpiCompliant(attr.Command);

                        if (simplifiedCommand != attr.Command)
                        {
                            commandToValueMap.Add(simplifiedCommand, value);
                        }

                        foreach (var response in attr.AdditionalResponses.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                        {
                            var trimmedResponse = response.Trim();
                            commandToValueMap.Add(trimmedResponse, value);

                            var simplifiedResponse = SimplifyCommandIfScpiCompliant(trimmedResponse);

                            if (simplifiedResponse != trimmedResponse)
                            {
                                commandToValueMap.Add(simplifiedResponse, value);
                            }
                        }
                    }
                }

                this.EnumValueToCommandMaps.Add(enumType, valueToCommandMap);
                this.CommandToEnumValuesMaps.Add(enumType, commandToValueMap);
            }

            private void LoadCommandsForExternalEnum(Type enumType, Assembly driverAsm)
            {
                // The command attributes are on the assembly, so we load them all at once.
                //
                foreach (EnumCommandAttribute attr in driverAsm.GetCustomAttributes(typeof(EnumCommandAttribute), false))
                {
                    if (attr.EnumType != enumType)
                    {
                        // This is not the enum we're after.
                        //
                        continue;
                    }

                    Dictionary<int /*value*/, Dictionary<string /*model*/, string /*command*/>> valueToCommandMap;

                    if (!this.EnumValueToCommandMaps.TryGetValue(enumType, out valueToCommandMap))
                    {
                        // No attributes have yet been found for this enum.
                        //
                        valueToCommandMap = new Dictionary<int, Dictionary<string, string>>();

                        this.EnumValueToCommandMaps.Add(enumType, valueToCommandMap);
                    }

                    Dictionary<string /*command*/, int /*value*/> commandToValueMap;

                    if (!this.CommandToEnumValuesMaps.TryGetValue(enumType, out commandToValueMap))
                    {
                        commandToValueMap = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

                        this.CommandToEnumValuesMaps.Add(enumType, commandToValueMap);
                    }

                    Dictionary<string, string> modelMap;

                    if (!valueToCommandMap.TryGetValue(attr.MemberValue, out modelMap))
                    {
                        // No attributes have yet been found for this member value.
                        //
                        modelMap = new Dictionary<string, string>();

                        valueToCommandMap.Add(attr.MemberValue, modelMap);
                    }

                    if (attr.Models.Length > 0)
                    {
                        foreach (var model in attr.Models)
                        {
                            modelMap.Add(model, attr.Command);
                        }
                    }
                    else
                    {
                        modelMap.Add(String.Empty, attr.Command);
                    }

                    commandToValueMap.Add(attr.Command, attr.MemberValue);

                    var simplifiedCommand = SimplifyCommandIfScpiCompliant(attr.Command);

                    if (simplifiedCommand != attr.Command)
                    {
                        commandToValueMap.Add(simplifiedCommand, attr.MemberValue);
                    }

                    foreach (var response in attr.AdditionalResponses.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        commandToValueMap.Add(response, attr.MemberValue);

                        var simplifiedResponse = SimplifyCommandIfScpiCompliant(response);

                        if (simplifiedResponse != response)
                        {
                            commandToValueMap.Add(simplifiedResponse, attr.MemberValue);
                        }
                    }
                }
            }

            private void LoadBooleanCommands()
            {
                var driverAsm = Assembly.GetExecutingAssembly();
                var attrs = driverAsm.GetCustomAttributes(typeof(BooleanCommandAttribute), false);
                Debug.Assert(attrs.Length <= 1);

                if (attrs.Length == 0)
                {
                    return;
                }

                var attr = (BooleanCommandAttribute)attrs[0];
                this.IgnoreBooleanCommandCase = attr.IgnoreCase;

                // Note that we add the SCPI-simplified version of the command first to ensure the short form is 
                // always used as the command.
                //
                foreach (var command in attr.TrueCommands)
                {
                    var simplifiedCommand = SimplifyCommandIfScpiCompliant(command);
                    this.BooleanTrueCommands.Add(simplifiedCommand);

                    if (command != simplifiedCommand)
                    {
                        this.BooleanTrueCommands.Add(command);
                    }
                }

                foreach (var command in attr.FalseCommands)
                {
                    var simplifiedCommand = SimplifyCommandIfScpiCompliant(command);
                    this.BooleanFalseCommands.Add(simplifiedCommand);

                    if (command != simplifiedCommand)
                    {
                        this.BooleanFalseCommands.Add(command);
                    }
                }
            }

            private string SimplifyCommandIfScpiCompliant(string rawCommand)
            {
                return this.SCPICompliant ? PreProcessScpiInstrumentCommand(rawCommand) : rawCommand;
            }

            private static string PreProcessScpiInstrumentCommand(string rawCommand)
            {
                var command = new StringBuilder();

                // Remove lowercase characters and characters inside square brackets
                //
                var insideReplacementTag = false;		// must keep lowercase characters inside replacement tags
                var insideSquareBrackets = false;		// throw away characters inside square brackets
                var escapePending = false;				// need to preserve lowercase characters that are escaped (ex: "\n")
                var prevChar = '\0';					// need to preserve contents of charset string specifies (ex: "%[^,]")

                foreach (var c in rawCommand)
                {
                    if (c == '[' && prevChar != '%')
                    {
                        insideSquareBrackets = true;
                    }
                    else if (c == ']' && insideSquareBrackets)
                    {
                        insideSquareBrackets = false;
                    }
                    else if (c == '{')
                    {
                        insideReplacementTag = true;

                        if (!insideSquareBrackets)
                        {
                            command.Append(c);
                        }
                    }
                    else if (c == '}')
                    {
                        insideReplacementTag = false;

                        if (!insideSquareBrackets)
                        {
                            command.Append(c);
                        }
                    }
                    else if (!insideSquareBrackets)
                    {
                        if (insideReplacementTag || !Char.IsLetter(c) || Char.IsUpper(c) || escapePending)
                        {
                            command.Append(c);
                        }
                    }

                    if (escapePending)
                    {
                        escapePending = false;
                    }
                    else
                    {
                        escapePending = c == '\\';
                    }

                    if (!Char.IsWhiteSpace(c))
                    {
                        prevChar = c;
                    }
                }

                return command.ToString();
            }

            #endregion
        }

        #endregion

#endif  // NCL_VISANET

    }
}
