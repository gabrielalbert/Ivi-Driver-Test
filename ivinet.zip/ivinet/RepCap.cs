///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.Driver;
using System;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Represents the repeated capability object in the driver object model hierarchy.
    /// </summary>
	internal class RepCap : DriverNode, IIviRepeatedCapabilityIdentification
    {
        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal static TRepCap CreateInstance<TRepCap>(RepCapCollection parent, int index, string physicalName)
            where TRepCap : RepCap, new()
        {
            var repCap = CreateInstance<TRepCap>(parent);

            repCap.Index = index;
            var parentNode = parent.Parent as IDriverNode;
            var parentCacheKeyPrefix = parentNode != null ? parentNode.CacheKeyPrefix : String.Empty;

            repCap._cacheKeyPrefix = $"{parentCacheKeyPrefix}{parent.RepCapName}[{physicalName}].";

            //  Must supply the full physical name to the PhysicalName ctor, as in:
            //
            //  "a1:b2:c3"
            //
            var fullPhysicalName = physicalName;

            if (parentNode is RepCap parentRepCap)
            {
                fullPhysicalName = $"{parentRepCap.PhysicalNameObject.FullName}:{fullPhysicalName}";
            }

            repCap.PhysicalNameObject = new PhysicalName(fullPhysicalName, parent);

            return repCap;
        }

        new public RepCapCollection Parent => (RepCapCollection)base.Parent;

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from driver
        /// developer code.
        /// </summary>
        protected override string CacheKeyPrefix => _cacheKeyPrefix;

        private string _cacheKeyPrefix;

        /// <summary>
        /// Gets the 0-based numeric index of the current repeated capability instance.
        /// </summary>
        internal int Index { get; set; }

        /// <summary>
        /// Gets the unqualified physical name of the current repeated capability instance.  Note that the unqualified 
        /// name is returned even if the repeated capability instance name in the IVI Configuration Store is a 
        /// qualified physical name.
        /// </summary>
        internal string PhysicalName => this.PhysicalNameObject.Name;

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from
        /// driver developer code.
        /// </summary>
        internal PhysicalName PhysicalNameObject { get; private set; }

        /// <summary>
        /// Gets the virtual name mapped to the physical name of the current repeated capability instance.  If the IVI 
        /// Configuration Store contains no virtual name mapped to this instance's physical name, then this property 
        /// returns the physical name.
        /// </summary>
        internal string VirtualName => Root.Session.TranslatePhysicalName(this.PhysicalName);

        #region IIviRepeatedCapabilityIdentification Members

        public string Name
            => this.Parent.UseQualifiedPhysicalNames
                ? $"{this.Parent.RepCapName}!!{this.PhysicalName}"
                : this.PhysicalName;

        #endregion
    }
}
