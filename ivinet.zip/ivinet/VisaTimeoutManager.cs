﻿#if NCL_VISANET

using System;
using Ivi.Driver;

namespace MindWorks.Nimbus
{
    internal sealed class VisaTimeoutManager : IDisposable
    {
        private Ivi.Visa.IVisaSession Session { get; set; }
        private int PrevTimeout { get; set; }

        internal VisaTimeoutManager(Ivi.Visa.IVisaSession session, int timeout)
        {
            if (session == null) throw new ArgumentNullException(nameof(session));

            this.Session = session;
            this.PrevTimeout = IOConstants.CurrentTimeout;

            if (timeout > IOConstants.CurrentTimeout)
            {
                // User specified a desired timeout or an infinite timeout.
                //
                this.PrevTimeout = session.TimeoutMilliseconds;
                session.TimeoutMilliseconds = timeout;
            }
        }

        internal VisaTimeoutManager(Ivi.Visa.IVisaSession session, PrecisionTimeSpan timeout)
            : this(session, checked((int)timeout.TotalMilliseconds))
        {
        }

        internal VisaTimeoutManager(Ivi.Visa.IVisaSession session, TimeSpan timeout)
            : this(session, checked((int)timeout.TotalMilliseconds))
        {
        }

        #region IDisposable Members

        public void Dispose()
        {
            // If necessary, restore the timeout.
            //
            if (this.PrevTimeout != IOConstants.CurrentTimeout)
            {
                // A new timeout was not specified.
                //
                this.Session.TimeoutMilliseconds = this.PrevTimeout;
            }
        }

        #endregion
    }
}

#endif  // NCL_VISANET

