///////////////////////////////////////////////////////////////////////////////
//
//	LEGAL NOTICE
//
//	This software file in any form is licensed, not sold, to you for use only 
//	under the terms of a license from Pacific MindWorks, Inc. available at 
//	http://www.pacificmindworks.com/legal/nimbus/buildtools/eula plus other 
//	licenses from licensees and licensors to Pacific MindWorks, Inc. who retains 
//	ownership of this software. Removal of this notice in any copy is a violation 
//	of your license to use this software.
//
//	� 2011-2019 Pacific MindWorks, Inc. 
//
///////////////////////////////////////////////////////////////////////////////

using Ivi.Driver;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reflection;

namespace MindWorks.Nimbus
{
    /// <summary>
    /// Represents a node in the driver object model hierarchy.
    /// </summary>
    public abstract class DriverNode : IDriverNode
    {
        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        protected DriverNode()
            : this(parent: null)
        {
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        protected DriverNode(DriverNode parent)
        {
            this.Parent = parent;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        protected static TNode CreateInstance<TNode>(DriverNode parent)
            where TNode : DriverNode, new()
        {
            return new TNode { Parent = parent };
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal virtual void InitNode()
        {
            // Create all of the child repeated capabilities.
            //
            this.CreateChildRepCapCollections();

            this.CreateChildParameterStyleRepCapManagers();

            this.CreateChildSelectorStyleRepCapManagers();
        }

        /// <summary>
        /// Dictionary of collection-style repeated capability instances that are children of the current driver node.
        /// <para>
        /// key = repcap class type, value = collection of repcap class instances
        /// </para>
        /// </summary>
        protected internal ReadOnlyDictionary<Type, RepCapCollection> CollectionStyleRepCaps { get; private set; }

        /// <summary>
        /// Dictionary of selector-style repeated capability instances that are children of the current driver node.
        /// <para>
        /// key = repcap name, value = collection of user-defined repcap data objects
        /// </para>
        /// </summary>
        protected internal ReadOnlyDictionary<string, SelectorStyleRepCapManager> SelectorStyleRepCaps { get; private set; }

        /// <summary>
        /// Dictionary of parameter-style repeated capability instances that are children of the current driver node.
        /// <para>
        /// key = repcap name, value = collection of user-defined repcap data objects
        /// </para>
        /// </summary>
        protected internal ReadOnlyDictionary<string, ParameterStyleRepCapManager> ParameterStyleRepCaps { get; private set; }

        private void CreateChildRepCapCollections()
        {
            var repCapCollections = new Dictionary<Type, RepCapCollection>();

            // Look for a property with the following characteristics:
            //		- Is read-only
            //		- Returns a reference to an interface that derives from IIviRepeatedCapabilityCollection<T>
            //
            foreach (var pi in this.GetType().GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly))
            {
                if (!pi.CanRead || pi.CanWrite || !pi.PropertyType.IsInterface)
                {
                    // This is not an interface reference property
                    //
                    continue;
                }

                var repCapCollBaseIntfType = GetRepCapCollectionInterfaceImplementedByType(pi.PropertyType);

                if (repCapCollBaseIntfType == null)
                {
                    // The property points to an interface that is not a repcap collection interface.
                    //
                    continue;
                }

                // We found a repcap collection interface.
                //
                var repCapCollIntfType = pi.PropertyType;

                // Since it derives from IIviRepeatedCapabilityCollection<T>, where T is the repcap  interface, we can
                // obtain the repcap interface by grabbing the first generic argument from the base interface.
                //
                var repCapIntfType = repCapCollBaseIntfType.GetGenericArguments()[0];

                var repCapClassType = GetRepCapClassFromRepCapInterface(repCapIntfType)
                    ?? throw new InvalidOperationException(NclStrings.CouldNotFindRepCapClass(repCapIntfType.Name));

                // We may have already processed this repcap, since we will encounter interface reference properties 
                // for both the instrument-specific and class-compliant collection interfaces.
                //
                if (repCapCollections.ContainsKey(repCapClassType))
                {
                    continue;
                }

                var repCapName = repCapClassType.Name.Substring(this.GetDriverBaseName().Length);

                // The repcap collection class *should* have a name in the following format:
                //
                //		AcmeSpecAnTraceCollection
                //
                var repCapCollClassName = $"{repCapClassType.Namespace}.{repCapClassType.Name}Collection";

                var repCapCollClassType = this.GetType().Assembly.GetType(repCapCollClassName);

                if (repCapCollClassType == null)
                {
                    // Looking up based on the name failed, so we fall-back to going through all of the types in the 
                    // assembly.
                    //
                    repCapCollClassType = this.GetClassImplementingInterface(repCapCollIntfType)
                        ?? throw new InvalidOperationException(NclStrings.CouldNotFindRepCapCollectionClass(repCapCollIntfType.Name));
                }

                // Constructor of repcap collection class is as follows:
                //
                //		RepCapCollection(DriverNode parent, string repCapName)
                //
                var repCapColl = Activator.CreateInstance(repCapCollClassType, this, repCapName) as RepCapCollection;

                repCapColl.InitNode();

                repCapCollections.Add(repCapClassType, repCapColl);
            }

            this.CollectionStyleRepCaps = new ReadOnlyDictionary<Type, RepCapCollection>(repCapCollections);
        }

        private Type GetRepCapClassFromRepCapInterface(Type repCapIntfType)
        {
            // Deducing the name of the repcap class depends upon whether the interface is an instrument-specific interface or a 
            // class-compliant interface.
            //
            string repCapClassName;

            var isInstrSpecific = repCapIntfType.Assembly == this.GetType().Assembly;

            if (isInstrSpecific)
            {
                // This is an instrument-specific repcap interface and should be of the form:
                //
                //		IAcmeSpecAnTrace
                //
                repCapClassName = $"{this.GetType().Namespace}.{repCapIntfType.Name.Substring(1)}";
            }
            else
            {
                // This is a class-compliant repcap interface.  
                // The name of the interface is in the form:
                //
                //		Ivi.SpecAn.IIviSpecAnTrace
                // 
                // The assembly name is in the form:
                //		Ivi.SpecAn
                // 
                Debug.Assert(repCapIntfType.Name.StartsWith("IIvi"));

                if (!repCapIntfType.Name.StartsWith("IIvi"))
                {
                    throw new InvalidOperationException(NclStrings.CouldNotFindRepCapClass(repCapIntfType.Name));
                }

                Debug.Assert(repCapIntfType.Namespace.StartsWith("Ivi."));

                if (!repCapIntfType.Namespace.StartsWith("Ivi."))
                {
                    throw new InvalidOperationException(NclStrings.CouldNotFindRepCapClass(repCapIntfType.Name));
                }

                // Remove the '.' from the namespace in order to get the base name for types in the assembly.  
                // This should be of the form:
                //
                //		IviSpecAn
                //
                var baseName = $"Ivi{repCapIntfType.Namespace.Substring("Ivi.".Length)}";

                // This should be of the form:
                //
                //		IIviSpecAnTrace
                //
                var intfPrefix = 'I' + baseName;
                Debug.Assert(repCapIntfType.Name.StartsWith(intfPrefix));

                repCapClassName = $"{this.GetType().Namespace}.{this.GetDriverBaseName()}{repCapIntfType.Name.Substring(intfPrefix.Length)}";
            }

            var repCapClassType = this.GetType().Assembly.GetType(repCapClassName);

            if (repCapClassType == null)
            {
                // Looking up based on the name failed, so we fall-back to going through all of the types in the 
                // assembly.
                //
                repCapClassType = this.GetClassImplementingInterface(repCapIntfType);
            }

            return repCapClassType;
        }

        private Type GetClassImplementingInterface(Type intfType)
        {
            foreach (var type in GetDriverDefinedTypes(this.GetType().Assembly))
            {
                if (type.IsClass)
                {
                    if (Utility.TypeImplementsInterface(type, intfType))
                    {
                        return type;
                    }
                }
            }

            return null;
        }

        private void CreateChildParameterStyleRepCapManagers()
        {
            var managers = new Dictionary<string, ParameterStyleRepCapManager>();

            foreach (RepeatedCapabilityAttribute attr in this.GetType().GetCustomAttributes(typeof(RepeatedCapabilityAttribute), false))
            {
                if (attr.Style != RepeatedCapabilityStyle.Parameter)
                {
                    continue;
                }

                if (managers.ContainsKey(attr.RepCapName))
                {
                    continue;
                }

                this.CreateParameterStyleRepCapManager(managers, attr);
            }

            this.ParameterStyleRepCaps = new ReadOnlyDictionary<string, ParameterStyleRepCapManager>(managers);
        }

        private void CreateParameterStyleRepCapManager(Dictionary<string, ParameterStyleRepCapManager> managers, RepeatedCapabilityAttribute attr)
        {
            var physicalNames = new List<string>();
            IRepCapManager parentManager = null;

            // Get the physical names specified in the attribute
            //
            var selector = RepCapSelector.Parse(attr.PhysicalNames);
            var attrPhysicalNames = RepCapSelector.ExpandToPhysicalNames(selector, sessionInfo: null);

            if (attr.Parent == null)
            {
                // This is a non-nested repcap, so simply add the expanded physical names specified in the attribute.
                //
                physicalNames.AddRange(attrPhysicalNames);
            }
            else
            {
                // This is a nested repcap, but the parent could be either the current collection-style repcap or a
                // parameter-style repcap.
                //
                var repCap = this as RepCap;

                if (repCap != null && repCap.Parent.RepCapName == attr.Parent)
                {
                    // The parent repcap is this collection-style repcap, so we only need to prepend the full name of
                    // the single parent instance, as this method will be called for each parent repcap instance.
                    //
                    parentManager = repCap.Parent;

                    foreach (var physicalName in attrPhysicalNames)
                    {
                        physicalNames.Add($"{repCap.PhysicalNameObject.FullName}:{physicalName}");
                    }
                }
                else
                {
                    // We know that either the current class is the main driver class OR the current class is a repcap
                    // class that is NOT our parent repcap.  In either case, we know that our parent repcap is a 
                    // parameter-style repcap.
                    //
                    parentManager = this.GetOrCreateChildParameterStyleRepCapManager(managers, attr.Parent)
                        ?? throw new InvalidOperationException(NclStrings.ParentRepeatedCapabilityNotFound(attr.RepCapName, attr.Parent));

                    // This is a nested repcap, but the physical names specified in the attribute may either be nested 
                    // or non-nested.  If they are nested, then we only want to create those specific instances.  If 
                    // they are non-nested, then that means we need to create one physical name for EACH physical name 
                    // in the parent repcap.
                    //
                    if (selector.IsNested)
                    {
                        // The nested physical names have been explicitly specified 
                        // (e.g. "Channel1:Trace2,Channel3:Trace4"), so we simply use the expanded physical names 
                        // specified in the attribute.  If we have an ancestor collection-style repcap, then we STILL
                        // need to prepend the explicitly specified names with the full name of ancestor instance.
                        //
                        if (repCap != null)
                        {
                            foreach (var physicalName in attrPhysicalNames)
                            {
                                physicalNames.Add($"{repCap.PhysicalNameObject.FullName}:{physicalName}");
                            }
                        }
                        else
                        {
                            physicalNames.AddRange(attrPhysicalNames);
                        }
                    }
                    else
                    {
                        // Create the set of physical names specified in the attribute, for EACH physical name in the 
                        // parent repcap.
                        //
                        foreach (var parentPhysicalName in (this.GetOrCreateChildParameterStyleRepCapManager(managers, attr.Parent)
                        ?? throw new InvalidOperationException(NclStrings.ParentRepeatedCapabilityNotFound(attr.RepCapName, attr.Parent))).PhysicalNames)
                        {
                            foreach (var physicalName in attrPhysicalNames)
                            {
                                physicalNames.Add($"{parentPhysicalName.FullName}:{physicalName}");
                            }
                        }
                    }
                }
            }

            // Get the dynamic repcap names
            //
            this.GetDynamicRepCapNames(attr.RepCapName, physicalNames);

            var manager = new ParameterStyleRepCapManager(attr.RepCapName, this.Session, attr.UseQualifiedNames, parentManager);

            foreach (var physicalName in physicalNames)
            {
                manager.AddPhysicalName(physicalName);
            }

            managers.Add(attr.RepCapName, manager);
        }

        private ParameterStyleRepCapManager GetOrCreateChildParameterStyleRepCapManager(Dictionary<string, ParameterStyleRepCapManager> managers, string repCapName)
        {
            if (managers.TryGetValue(repCapName, out var manager))
            {
                return manager;
            }

            foreach (RepeatedCapabilityAttribute attr in this.GetType().GetCustomAttributes(typeof(RepeatedCapabilityAttribute), inherit: false))
            {
                if (attr.Style != RepeatedCapabilityStyle.Parameter || attr.RepCapName != repCapName)
                {
                    continue;
                }

                this.CreateParameterStyleRepCapManager(managers, attr);

                managers.TryGetValue(repCapName, out manager);

                break;
            }

            return manager;
        }

        private void CreateChildSelectorStyleRepCapManagers()
        {
            var managers = new Dictionary<string, SelectorStyleRepCapManager>();

            foreach (RepeatedCapabilityAttribute attr in this.GetType().GetCustomAttributes(typeof(RepeatedCapabilityAttribute), inherit: false))
            {
                if (attr.Style != RepeatedCapabilityStyle.Selector)
                {
                    continue;
                }

                var physicalNames = new List<string>();

                // Get the physical names specified in the attribute.
                //
                var selector = RepCapSelector.Parse(attr.PhysicalNames);

                physicalNames.AddRange(RepCapSelector.ExpandToPhysicalNames(selector, sessionInfo: null));

                // Get the dynamic repcap names.
                //
                this.GetDynamicRepCapNames(attr.RepCapName, physicalNames);

                var manager = new SelectorStyleRepCapManager(attr.RepCapName, this.Session, attr.UseQualifiedNames);

                foreach (var physicalName in physicalNames)
                {
                    manager.AddPhysicalName(physicalName);
                }

                managers.Add(attr.RepCapName, manager);
            }

            this.SelectorStyleRepCaps = new ReadOnlyDictionary<string, SelectorStyleRepCapManager>(managers);
        }

        private static IEnumerable<Type> GetDriverDefinedTypes(Assembly asm)
        {
            // We just need to exclude NCL types.
            //
            foreach (var type in asm.GetTypes())
            {
                if (!IsNclType(type))
                {
                    yield return type;
                }
            }
        }

        private static bool IsNclType(Type type)
        {
            return type.Namespace == typeof(Driver).Namespace;
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal static Type GetRepCapCollectionInterfaceImplementedByType(Type type)
        {
            foreach (var baseIntfType in type.GetInterfaces())
            {
                return baseIntfType.IsGenericType && baseIntfType.GetGenericTypeDefinition() == typeof(IIviRepeatedCapabilityCollection<>)
                    ? baseIntfType
                    : GetRepCapCollectionInterfaceImplementedByType(baseIntfType);
            }

            return null;
        }

        private string GetDriverBaseName()
        {
            return this.Root.GetType().Name;
        }

        /// <summary>
        ///	Override this method to initialize member variables and any cached data. This method is automatically 
        ///	called in the following circumstances:
        ///	<para>
        ///		1) After the instrument connection has been created during instantiation of the main driver class.
        ///	</para>
        ///	<para>
        ///		2) After IIviDriverUtility.Reset.
        ///	</para>
        ///	<para>
        ///		3) After IIviDriverUtility.ResetWithDefaults
        ///	</para>
        /// </summary>
        protected virtual void ResetObjectState()
        {
        }

        /// <summary>
        /// Override this method to implement support for dynamic repeated capabilities.
        /// </summary>
        /// <param name="repCapName">The repeated capability name.</param>
        /// <param name="physicalNames">The collection into which physical names should be placed.</param>
        protected virtual void GetDynamicRepCapNames(string repCapName, IList<string> physicalNames)
        {
        }

        /// <summary>
        /// Adds a physical name to the specified parameter-style or selector-style repeated capability. For nested 
        /// repeated capabilities, the name must be in the standard IVI-defined format for a nested physical name 
        /// (e.g. "a1:b2:c3").  Note that all parent repeated capability physical names referenced must be added before
        /// adding the child physical name, else this method will throw an exception.
        /// </summary>
        /// <param name="repCapName">Name of the repeated capability (e.g. "Channel") to which the specified physical 
        /// name should be added.</param>
        /// <param name="fullPhysicalName">
        /// The full physical name of the repeated capability instance, including all parent instance identifiers.  If 
        /// the number of levels of hierarchy in the physical name specified does not match the level of nesting for 
        /// this repeated capability, then this method throws an exception.
        /// </param>
        internal virtual PhysicalName AddPhysicalName(string repCapName, string fullPhysicalName)
        {
            return this.GetRepCapManager(repCapName).AddPhysicalName(fullPhysicalName);
        }

        /// <summary>
        /// Removes a physical name from the specified parameter-style or selector-style repeated capability.  
        /// For nested repeated capabilities, the name must be in the standard IVI-defined format for a nested 
        /// physical name (e.g. "a1:b2:c3").
        /// </summary>
        /// <param name="repCapName">Name of the repeated capability (e.g. "Channel") from which the specified physical
        /// name should be removed.</param>
        /// <param name="fullPhysicalName">
        /// The full physical name of the repeated capability instance, including all parent instance identifiers. If 
        /// the number of levels of hierarchy in the physical name specified does not match the level of nesting for 
        /// this repeated capability, then this method throws an exception.
        /// </param>
        internal virtual void RemovePhysicalName(string repCapName, string fullPhysicalName)
        {
            this.GetRepCapManager(repCapName).RemovePhysicalName(fullPhysicalName);
        }

        /// <summary>
        /// Expands the parameter-style or selector-style repeated capability selector into a list of PhysicalName 
        /// objects. Virtual name substitution is performed and repeated capability ranges are expanded.  If each 
        /// resulting physical name is not defined for the specified repeated capability, then an SelectorNameException
        /// is thrown.
        /// </summary>
        /// <param name="repCapName">Name of the repeated capability against which the resulting physical names should 
        /// be verified.</param>
        /// <param name="selector">The repeated capability selector to expand.</param>
        /// <returns>The list of validated repeated capability physical name objects.</returns>
        internal virtual IList<PhysicalName> ExpandSelector(string repCapName, string selector)
        {
            return this.GetRepCapManager(repCapName).ExpandSelector(selector);
        }

        /// <summary>
        /// Expands the parameter-style or selector-style repeated capability selector into a single PhysicalName 
        /// object. Virtual name substitution is performed. If the resulting physical name is not defined for the 
        /// specified repeated capability, then an UnknownPhysicalNameException is thrown.  If the selector expands to 
        /// more than one repeated capability physical name, then an InvalidOperationException is thrown.
        /// </summary>
        /// <param name="repCapName">Name of the repeated capability against which the resulting physical names should 
        /// be verified.</param>
        /// <param name="selector">The repeated capability selector to expand.</param>
        /// <returns>A validated repeated capability physical name object.</returns>
        internal virtual PhysicalName ExpandSingleSelector(string repCapName, string selector)
        {
            var physicalNames = ExpandSelector(repCapName, selector);

            if (physicalNames.Count > 1)
            {
                throw new InvalidOperationException(NclStrings.SingleRepeatedCapbilityIdentifierRequired);
            }

            return physicalNames[0];
        }

        internal virtual PhysicalName GetActivePhysicalName(string repCapName)
        {
            return this.GetRepCapManager<SelectorStyleRepCapManager>(repCapName).GetActivePhysicalName();
        }

        internal virtual IList<PhysicalName> GetActivePhysicalNames(string repCapName)
        {
            return this.GetRepCapManager<SelectorStyleRepCapManager>(repCapName).ActivePhysicalNames;
        }

        /// <summary>
        /// Returns the repeated capability manager object for the specified parameter-style or selector-style repeated 
        /// capability name (e.g. "Channel").  This method cannot be used to retrieve information about collection-style
        /// repeated capabilities.
        /// </summary>
        /// <param name="repCapName">Name of the repaeted capability.</param>
        /// <returns>The repeated capability manager object for the specified repeated capability.</returns>
        internal virtual RepCapManager GetRepCapManager(string repCapName)
        {
            return this.GetRepCapManager<RepCapManager>(repCapName);
        }

        /// <summary>
        /// Returns the repeated capability manager object for the specified parameter-style or selector-style repeated 
        /// capability name (e.g. "Channel").  This method cannot be used to retrieve information about collection-style
        /// repeated capabilities.
        /// </summary>
        /// <param name="repCapName">Name of the repaeted capability.</param>
        /// <returns>The repeated capability manager object for the specified repeated capability.</returns>
        internal virtual T GetRepCapManager<T>(string repCapName)
            where T : RepCapManager
        {
            if (repCapName == null) throw new ArgumentNullException(nameof(repCapName));

            if (this.ParameterStyleRepCaps.TryGetValue(repCapName, out var paramStyleManager))
            {
                if (typeof(T) == typeof(SelectorStyleRepCapManager))
                {
                    throw new InvalidOperationException(NclStrings.RepeatedCapabilityNotDefinedAsSelectorStyle(repCapName));
                }

                return paramStyleManager as T;
            }
            else if (this.SelectorStyleRepCaps.TryGetValue(repCapName, out var selectorStyleManager))
            {
                if (typeof(T) == typeof(ParameterStyleRepCapManager))
                {
                    throw new InvalidOperationException(NclStrings.RepeatedCapabilityNotDefinedAsParameterStyle(repCapName));
                }

                return selectorStyleManager as T;
            }

            throw new InvalidOperationException(NclStrings.RepeatedCapabilityNotDefined(repCapName));
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        internal static bool TypeOverridesGetDynamicRepCapNames(Type targetType)
        {
            var bindingFlags = BindingFlags.Instance | BindingFlags.NonPublic;
            var argTypes = new[] { typeof(string), typeof(IList<string>) };
            var getDynamicRepCapNamesMethod = typeof(DriverNode).GetMethod("GetDynamicRepCapNames", bindingFlags, null, argTypes, null);

            return Utility.TypeOverridesMethod(targetType, getDynamicRepCapNamesMethod);
        }

        internal static bool AlmostEqual(double value1, double value2)
        {
            const double virtuallyZero = 1e-20;

            var abs1 = Math.Abs(value1);
            var abs2 = Math.Abs(value2);
            var delta = Math.Abs(value1 - value2);
            var closeEnough = Math.Max(virtuallyZero, Math.Max(abs1, abs2) * 5 * 10e-15);

            return delta < closeEnough;
        }

        internal DriverNode Parent { get; private set; }

        internal Driver Root => this.Parent == null ? (Driver)this : this.Parent.Root;

        /// <summary>
        /// Gets a reference to static information that describes the identity and capabilities of the driver.  This 
        /// information is independent of the I/O connection and does not change after the driver is created.
        /// </summary>
        protected virtual DriverInfo DriverInfo => this.Root.DriverInfo;

#if NCL_VISANET

        /// <summary>
        /// Gets a reference to the current I/O session.  If the current session is message based, a reference to an 
        /// IMessageBasedSession is returned. If the current session is register based, an IRegisterBasedSession is 
        /// returned.  This property returns null in simulation mode.
        /// </summary>
        protected virtual Ivi.Visa.IVisaSession VisaSession => this.Root.VisaSession;

        /// <summary>
        /// Provides access to message-based operations on the current I/O session. For register-based instruments, 
        /// this property may return null.  Also, in simulation mode, this property returns null.
        /// </summary>
        protected virtual Ivi.Visa.IMessageBasedSession IO => this.Root.IO;

        /// <summary>
        /// Provides access to register-based operations on the current I/O session. For message-based instruments, 
        /// this property may return null. Also, in simulation mode, this property returns null.
        /// </summary>
        protected virtual Ivi.Visa.IRegisterBasedSession RegisterIO => this.Root.RegisterIO;


        /// <summary>
        /// Gets a value that indicates if the current I/O session is message based.  This property returns false in 
        /// simulation mode.
        /// </summary>
        protected bool IsMessageBasedIOSession => this.IO != null;

        /// <summary>
        /// Gets a value that indicates if the current I/O session is register based.  This property returns false in
        /// simulation mode.
        /// </summary>
        protected bool IsRegisterBasedIOSession => this.RegisterIO != null;

#endif  // NCL_VISANET

        /// <summary>
        /// Polls the instrument for errors. By default, this method performs a standard IEEE 488.2 *ESR query. If an 
        /// error is detected, an InstrumentStatusException is thrown.  In simulation mode, this method performs no 
        /// action.  Override this method in the main driver class to customize behavior.  This method must be 
        /// overridden for instruments that are not message-based.
        /// </summary>
        protected virtual void PollInstrumentErrors()
        {
            this.Root.PollInstrumentErrors();
        }

        /// <summary>
        /// Sends a warning event to all registered event listeners.
        /// </summary>
        /// <param name="args">Information specific about the warning event.</param>
        protected virtual void SendWarningEvent(WarningEventArgs args)
        {
            this.Root.SendWarningEvent(args);
        }

        /// <summary>
        /// Sends a coercion event to all registered event listeners.
        /// </summary>
        /// <param name="originalValue">The original value specified by the caller of a method or property.</param>
        /// <param name="coercedValue">The value to which the driver coerced <paramref name="originalValue"/>.</param>
        protected virtual void SendCoercionEvent(object originalValue, object coercedValue)
        {
            this.Root.SendCoercionEvent(originalValue, coercedValue);
        }

        /// <summary>
        /// Sends a coercion event to all registered event listeners.
        /// </summary>
        /// <param name="args">Information specific about the coercion event.</param>
        protected virtual void SendInterchangeEvent(InterchangeCheckWarningEventArgs args)
        {
            this.Root.SendInterchangeEvent(args);
        }

#if NCL_VISANET

        /// <summary>
        /// Gets the string that has been associated with the specified enum member via either the Command attribute 
        /// (in the case of  driver-defined enums) or the EnumCommand attribute (in the case of externally-defined 
        /// enum types, such as class-compliant enums).  Note that this method is unrelated to the .NET framework 
        /// Enum.Parse method.
        /// <para>
        /// If model-specific commands have been associated with the enum member, then the current model is used in 
        /// determining the value returned.
        /// </para>
        /// <para>
        /// An exception is thrown if no string has been associated with the specified member via either the Command 
        /// attribute or the EnumCommand 
        /// attribute.
        /// </para>
        /// </summary>
        /// <param name="member">The enum member to convert to a string.</param>
        /// <returns>The string value associated with the specified enum member.</returns>
        internal virtual string ConvertEnumToString(Enum member)
        {
            return this.Root.ConvertEnumToString(member);
        }

        /// <summary>
        /// Gets the string that has been associated with the specified enum member via either the Command attribute 
        /// (in the case of  driver-defined enums) or the EnumCommand attribute (in the case of externally-defined enum
        /// types, such as class-compliant enums).  Note that this method is unrelated to the .NET framework Enum.Parse 
        /// method.
        /// <para>
        /// If model-specific commands have been associated with the enum member, then the current model is used in 
        /// determining the value returned.
        /// </para>
        /// <para>
        /// This method does not throw an exception if no string has been associated with the specified member via 
        /// either the Command attribute or the EnumCommand 
        /// attribute.
        /// </para>
        /// </summary>
        /// <param name="member">The enum member to convert to a string.</param>
        /// <param name="result">The string value associated with the specified enum member.</param>
        /// <returns>A value indicating if a string mapping for the enum member was found.</returns>
        internal virtual bool TryConvertEnumToString(Enum member, out string result)
        {
            result = String.Empty;

            try
            {
                result = ConvertEnumToString(member);
                return true;
            }
            catch (Ivi.Visa.TypeFormatterException)
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the enum member that has been associated with the specified string via either the Command attribute 
        /// (in the case of  driver-defined enums) or the EnumCommand attribute (in the case of externally-defined enum
        /// types, such as class-compliant enums).  Note that this method is unrelated to the .NET framework 
        /// Enum.ToString method.
        /// <para>
        /// If model-specific commands have been associated with the enum member, then the current model is used in 
        /// determining the value returned.
        /// </para>
        /// <para>
        /// An exception is thrown if no string has been associated with the specified member via either the Command 
        /// attribute or the EnumCommand 
        /// attribute.
        /// </para>
        /// </summary>
        /// <param name="data">The string data to convert to an enum member.</param>
        /// <returns>The enum member associated with the specified string.</returns>
        internal virtual Enum ConvertStringToEnum<TEnum>(string data)
        {
            return this.Root.ConvertStringToEnum<TEnum>(data);
        }

        /// <summary>
        /// Gets the enum member that has been associated with the specified string via either the Command attribute 
        /// (in the case of  driver-defined enums) or the EnumCommand attribute (in the case of externally-defined enum
        /// types, such as class-compliant enums).  Note that this method is unrelated to the .NET framework 
        /// Enum.ToString method.
        /// <para>
        /// If model-specific commands have been associated with the enum member, then the current model is used in 
        /// determining the value returned.
        /// </para>
        /// <para>
        /// An exception is thrown if no string has been associated with the specified member via either the Command 
        /// attribute or the EnumCommand 
        /// attribute.
        /// </para>
        /// </summary>
        /// <param name="data">The string data to convert to an enum member.</param>
        /// <param name="member">If successful, the enum member value corresponding to the given 
        /// <paramref name="data"/> value.</param>
        /// <returns>The enum member associated with the specified string.</returns>
        internal bool TryConvertStringToEnum<TEnum>(string data, out Enum member)
        {
            member = (Enum)Enum.ToObject(typeof(TEnum), default(TEnum));

            try
            {
                member = ConvertStringToEnum<TEnum>(data);
                return true;
            }
            catch (Ivi.Visa.TypeFormatterException)
            {
                return false;
            }
        }

#endif  // NCL_VISANET

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        protected virtual string CacheKeyPrefix => $"0x{this.GetHashCode():x8}.";

        /// <summary>
        /// Indicates if the driver's internal state caching engine contains the specified value for the calling 
        /// property.  Each cached value is maintained on a per-property basis. This method MUST be called directly 
        /// from the driver method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected virtual bool CacheContainsValue(object value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            return this.Root.CacheContainsValue(meth, this, value);
        }

        /// <summary>
        /// Returns the value cached for the calling property.  Each cached value is maintained on a per-property 
        /// basis. This method MUST be called directly from the driver method implementation (and not a helper method)
        /// in order to function properly.  
        /// </summary>
        protected virtual bool GetCacheValue<T>(out T value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            return this.Root.GetCacheValue<T>(meth, this, out value);
        }

        /// <summary>
        /// Returns the value cached for the calling property.  Each cached value is maintained on a per-property 
        /// basis.  This method MUST be called directly from the driver method implementation (and not a helper method)
        /// in order to function properly.  
        /// </summary>
        protected virtual bool GetCacheValue(out object value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            return this.Root.GetCacheValue(meth, this, out value);
        }

        /// <summary>
        /// Gets the value cached for the specified property. This method MUST be called directly from the driver 
        /// method implementation (and not a helper method) in order to function properly.  
        /// </summary>
        protected virtual bool GetCacheValue<T>(string key, out T value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            return this.Root.GetCacheValue(key, meth, this, out value);
        }

        /// <summary>
        /// Gets the default value that should be returned from a property when the driver is operating in simulation 
        /// mode.  For properties configured to use a simulation mode of LastValueSet, this method is called by Nimbus
        /// whenever a property getter is called before the setter is called for that same property.  For properties 
        /// configured to use a simulation mode of ConstantValue, this method is called to retrieve the constant value 
        /// returned for all calls to the property getter.  Override this method to provide default simulation values 
        /// for types not covered by the default implementation.
        /// </summary>
        protected virtual object GetDefaultValueForSimulation(Type targetType, string defaultValue)
        {
            return this.Root.GetDefaultValueForSimulation(targetType, defaultValue);
        }

        /// <summary>
        /// This member is for internal use of the Nimbus Class Library and is not intended to be called directly from 
        /// driver developer code.
        /// </summary>
        protected virtual void UpdateCacheValue(object value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            this.Root.UpdateCacheValue(meth, this, value);
        }

        /// <summary>
        /// Updates the value cached for the specified property.
        /// This method MUST be called directly from the driver method implementation (and not a helper method) in 
        /// order to function properly.  
        /// </summary>
        protected virtual void UpdateCacheValue(string key, object value)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            this.Root.UpdateCacheValue(key, meth, this, value);
        }

        /// <summary>
        /// Invalidates the value cached for the specified property.  This causes the very next property access to 
        /// communicate with the instrument to get or set the property value.  Each cached value is maintained on a 
        /// per-property basis. This method MUST be called directly from the driver method implementation (and not a
        /// helper method) in order to function properly.  
        /// </summary>
        protected virtual void InvalidateCacheEntry(string key)
        {
            var meth = new StackTrace().GetFrame(1).GetMethod() as MethodInfo;

            this.Root.InvalidateCacheEntry(meth, this, key);
        }

        /// <summary>
        /// Invalidates all cached values in the state caching engine.  
        /// </summary>
        protected virtual void InvalidateAllCacheEntries()
        {
            this.Root.InvalidateAllCacheEntries();
        }

        /// <summary>
        /// Acquires a driver-wide thread synchronization lock.  This method blocks the caller indefinitely until the
        /// driver lock is available.
        /// <para>
        /// Note that this lock is unrelated to I/O locking, such as VISA-based session locking.
        /// </para>
        /// </summary>
        /// <returns>A reference to the lock object for the driver.  This reference must be used to release the lock.
        /// </returns>
        protected virtual IIviDriverLock AcquireLock()
        {
            return this.Root.AcquireLock();
        }

        /// <summary>
        /// Acquires a driver-wide thread synchronization lock.  This method blocks the caller for a maximum duration 
        /// of <paramref name="maxTime"/> while waiting for the lock to become available.  An exception is thrown if 
        /// the lock cannot be acquired within <paramref name="maxTime"/>
        /// </summary>
        /// <para>
        /// Note that this lock is unrelated to I/O locking, such as VISA-based session locking.
        /// </para>
        /// <param name="maxTime">The maximum amount of time to wait to acquire the lock.  An exception is thrown if 
        /// the lock cannot be acquired 
        /// within the duration specified.</param>
        /// <returns>A reference to the lock object for the driver.  This reference must be used to release the lock.
        /// </returns>
        protected virtual IIviDriverLock AcquireLock(PrecisionTimeSpan maxTime)
        {
            return this.Root.AcquireLock(maxTime);
        }

        /// <summary>
        /// Checks to see if the driver's IDisposable.Dispose method has been called, and, if so, throws an 
        /// ObjectDisposedException.
        /// </summary>
        protected virtual void CheckDisposed()
        {
            this.Root.CheckDisposed();
        }

        /// <summary>
        /// Gets a value indicating if the driver is currently connected to the specified instrument model.
        /// </summary>
        /// <param name="family">The family to test against.</param>
        /// <returns>True if the driver is currently connected to a model in <paramref name="family"/>.</returns>
        protected virtual bool InstrumentInFamily(string family)
        {
            return this.Root.InstrumentInFamily(family);
        }

        /// <summary>
        /// Gets a value indicating if the driver is currently connected to the specified instrument model.
        /// </summary>
        /// <param name="model">The model to test against.</param>
        /// <returns>True if the driver is currently connected to <paramref name="model"/>.</returns>
        protected virtual bool InstrumentIsModel(string model)
        {
            return this.Root.InstrumentIsModel(model);
        }

        /// <summary>
        /// Gets a reference to information about the current driver session.  This data includes driver options 
        /// specified in the IVI Configuration  Store as well as options passed to the driver constructor.  After 
        /// instantiating the driver, the user can modify these settings via the inherent capabilities properties 
        /// under DriverOperation.
        /// </summary>
        internal virtual SessionInfo Session => this.Root.Session;

        #region RangeCheckDiscreteAttribute operations: Sbyte
        internal virtual sbyte CoerceUp(MethodBase member, sbyte value, sbyte[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual sbyte CoerceDown(MethodBase member, sbyte value, sbyte[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (value == allowedValue)
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, sbyte value, sbyte[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Byte
        internal virtual byte CoerceUp(MethodBase member, byte value, byte[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual byte CoerceDown(MethodBase member, byte value, byte[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (value == allowedValue)
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, byte value, byte[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int16
        internal virtual short CoerceUp(MethodBase member, short value, short[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual short CoerceDown(MethodBase member, short value, short[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (value == allowedValue)
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, short value, short[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: UInt16
        internal virtual ushort CoerceUp(MethodBase member, ushort value, ushort[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual ushort CoerceDown(MethodBase member, ushort value, ushort[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (value == allowedValue)
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, ushort value, ushort[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int32
        internal virtual int CoerceUp(MethodBase member, int value, int[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual int CoerceDown(MethodBase member, int value, int[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (value == allowedValue)
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, int value, int[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: UInt32
        internal virtual uint CoerceUp(MethodBase member, uint value, uint[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual uint CoerceDown(MethodBase member, uint value, uint[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (value == allowedValue)
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, uint value, uint[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int64
        internal virtual long CoerceUp(MethodBase member, long value, long[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual long CoerceDown(MethodBase member, long value, long[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (value == allowedValue)
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, long value, long[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: ulong
        internal virtual ulong CoerceUp(MethodBase member, ulong value, ulong[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual ulong CoerceDown(MethodBase member, ulong value, ulong[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (value == allowedValue)
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, ulong value, ulong[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Single
        internal virtual float CoerceUp(MethodBase member, float value, float[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (AlmostEqual(value, allowedValue))
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual float CoerceDown(MethodBase member, float value, float[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (AlmostEqual(value, allowedValue))
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, float value, float[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (AlmostEqual(value, allowedValue))
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Double
        internal virtual double CoerceUp(MethodBase member, double value, double[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            foreach (var allowedValue in allowedValues)
            {
                if (AlmostEqual(value, allowedValue))
                {
                    return value;
                }

                if (value < allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual double CoerceDown(MethodBase member, double value, double[] allowedValues)
        {
            if (member == null) throw new ArgumentNullException(nameof(member));
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            // This method assumes the allowedValues array is already sorted.
            //
            if (allowedValues.Length == 0)
            {
                return value;
            }

            for (int i = allowedValues.Length - 1; i >= 0; i--)
            {
                var allowedValue = allowedValues[i];

                if (AlmostEqual(value, allowedValue))
                {
                    return value;
                }

                if (value > allowedValue)
                {
                    return allowedValue;
                }
            }

            throw ErrorService.OutOfRange(member.Name, value.ToString(CultureInfo.CurrentCulture), allowedValues);
        }

        internal virtual bool IsOneOf(MethodBase member, double value, double[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (AlmostEqual(value, allowedValue))
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: String
        internal virtual bool IsOneOf(MethodBase member, string value, string[] allowedValues)
        {
            if (allowedValues == null) throw new ArgumentNullException(nameof(allowedValues));

            foreach (var allowedValue in allowedValues)
            {
                if (value == allowedValue)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region IDriverNode

        DriverNode IDriverNode.Parent => this.Parent;

        Driver IDriverNode.Root => this.Root;

        DriverInfo IDriverNode.DriverInfo => this.DriverInfo;

#if NCL_VISANET

        Ivi.Visa.IVisaSession IDriverNode.VisaSession => this.VisaSession;

        Ivi.Visa.IMessageBasedSession IDriverNode.IO => this.IO;

        Ivi.Visa.IRegisterBasedSession IDriverNode.RegisterIO => this.RegisterIO;

        bool IDriverNode.IsMessageBasedIOSession => this.IsMessageBasedIOSession;

        bool IDriverNode.IsRegisterBasedIOSession => this.IsRegisterBasedIOSession;

#endif  // NCL_VISANET

        void IDriverNode.PollInstrumentErrors()
        {
            this.PollInstrumentErrors();
        }

        void IDriverNode.SendWarningEvent(WarningEventArgs args)
        {
            this.SendWarningEvent(args);
        }

        void IDriverNode.SendCoercionEvent(object originalValue, object coercedValue)
        {
            this.SendCoercionEvent(originalValue, coercedValue);
        }

        void IDriverNode.SendInterchangeEvent(InterchangeCheckWarningEventArgs args)
        {
            this.SendInterchangeEvent(args);
        }

#if NCL_VISANET

        string IDriverNode.ConvertEnumToString(Enum member)
        {
            return this.ConvertEnumToString(member);
        }

        bool IDriverNode.TryConvertEnumToString(Enum member, out string result)
        {
            return this.TryConvertEnumToString(member, out result);
        }

        Enum IDriverNode.ConvertStringToEnum<TEnum>(string data)
        {
            return this.ConvertStringToEnum<TEnum>(data);
        }

        bool IDriverNode.TryConvertStringToEnum<TEnum>(string data, out Enum member)
        {
            return this.TryConvertStringToEnum<TEnum>(data, out member);
        }

#endif  // NCL_VISANET

        string IDriverNode.CacheKeyPrefix => this.CacheKeyPrefix;

        bool IDriverNode.CacheContainsValue(object value)
        {
            return this.CacheContainsValue(value);
        }

        bool IDriverNode.GetCacheValue<T>(out T value)
        {
            return this.GetCacheValue(out value);
        }

        bool IDriverNode.GetCacheValue<T>(string key, out T value)
        {
            return this.GetCacheValue(key, out value);
        }

        object IDriverNode.GetDefaultValueForSimulation(Type targetType, string defaultValue)
        {
            return this.GetDefaultValueForSimulation(targetType, defaultValue);
        }

        bool IDriverNode.GetCacheValue(out object value)
        {
            return this.GetCacheValue(out value);
        }

        void IDriverNode.UpdateCacheValue(object value)
        {
            this.UpdateCacheValue(value);
        }

        void IDriverNode.UpdateCacheValue(string key, object value)
        {
            this.UpdateCacheValue(key, value);
        }

        void IDriverNode.InvalidateCacheEntry(string key)
        {
            this.InvalidateCacheEntry(key);
        }

        void IDriverNode.InvalidateAllCacheEntries()
        {
            this.InvalidateAllCacheEntries();
        }

        IIviDriverLock IDriverNode.AcquireLock()
        {
            return this.AcquireLock();
        }

        IIviDriverLock IDriverNode.AcquireLock(PrecisionTimeSpan maxTime)
        {
            return this.AcquireLock(maxTime);
        }

        void IDriverNode.CheckDisposed()
        {
            this.CheckDisposed();
        }

        bool IDriverNode.InstrumentInFamily(string family)
        {
            return this.InstrumentInFamily(family);
        }

        bool IDriverNode.InstrumentIsModel(string model)
        {
            return this.InstrumentIsModel(model);
        }

        SessionInfo IDriverNode.Session => this.Session;

        #region RangeCheckDiscreteAttribute operations: SByte
        sbyte IDriverNode.CoerceUp(MethodBase member, sbyte value, sbyte[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        sbyte IDriverNode.CoerceDown(MethodBase member, sbyte value, sbyte[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, sbyte value, sbyte[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Byte
        byte IDriverNode.CoerceUp(MethodBase member, byte value, byte[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        byte IDriverNode.CoerceDown(MethodBase member, byte value, byte[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, byte value, byte[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int16
        short IDriverNode.CoerceUp(MethodBase member, short value, short[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        short IDriverNode.CoerceDown(MethodBase member, short value, short[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, short value, short[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: UInt16
        ushort IDriverNode.CoerceUp(MethodBase member, ushort value, ushort[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        ushort IDriverNode.CoerceDown(MethodBase member, ushort value, ushort[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, ushort value, ushort[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int32
        int IDriverNode.CoerceUp(MethodBase member, int value, int[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        int IDriverNode.CoerceDown(MethodBase member, int value, int[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, int value, int[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: UInt32
        uint IDriverNode.CoerceUp(MethodBase member, uint value, uint[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        uint IDriverNode.CoerceDown(MethodBase member, uint value, uint[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, uint value, uint[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Int64
        long IDriverNode.CoerceUp(MethodBase member, long value, long[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        long IDriverNode.CoerceDown(MethodBase member, long value, long[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, long value, long[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: ulong
        ulong IDriverNode.CoerceUp(MethodBase member, ulong value, ulong[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        ulong IDriverNode.CoerceDown(MethodBase member, ulong value, ulong[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, ulong value, ulong[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Single
        float IDriverNode.CoerceUp(MethodBase member, float value, float[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        float IDriverNode.CoerceDown(MethodBase member, float value, float[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, float value, float[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: Double
        double IDriverNode.CoerceUp(MethodBase member, double value, double[] allowedValues)
        {
            return this.CoerceUp(member, value, allowedValues);
        }

        double IDriverNode.CoerceDown(MethodBase member, double value, double[] allowedValues)
        {
            return this.CoerceDown(member, value, allowedValues);
        }

        bool IDriverNode.IsOneOf(MethodBase member, double value, double[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #region RangeCheckDiscreteAttribute operations: string
        bool IDriverNode.IsOneOf(MethodBase member, string value, string[] allowedValues)
        {
            return this.IsOneOf(member, value, allowedValues);
        }
        #endregion

        #endregion
    }
}
